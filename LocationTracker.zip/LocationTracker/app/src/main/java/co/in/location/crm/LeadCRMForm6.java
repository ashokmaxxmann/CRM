package co.in.location.crm;

import android.app.DatePickerDialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AppCompatDialog;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListPopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.Calendar;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import co.in.location.GifImageView;
import co.in.location.Helper;
import co.in.location.MainActivity;
import co.in.location.R;
import co.in.location.Remote.ApiUtils;
import co.in.location.data.UserListData;
import co.in.location.response.CRMResponce;
import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LeadCRMForm6 extends Fragment implements View.OnClickListener {
    View view;
    EditText edt_proposal_sent_for, edt_proposal_sent_on, edt_expected_closure_date, edt_total_value, edt_proposal_not_sent_for, edt_reason, edt_status, edt_user;
    TextView txt_save, txt1, txt2, txt3, txt4, txt5, txt6;
    AppCompatDialog progressDialog;
    TextView prog_message;

    EditText edt_other_proposal_sent_for, edt_other_proposal_not_sent_for, edt_other_reason, edt_other_status;


    private String[] list_proposal_sent_for = new String[]{"SEO", "SMM", "SEM", "SMO", "Website Designing", "Website Revamp", "App Making", "Content Marketing", "Email Marketing", "Affiliate Marketing", "Pay Per click", "Market Segmentation", "Video Advertising", "Display Advertising", "Others"};
    private String[] list_proposal_not_sent_for = new String[]{"SEO", "SMM", "SEM", "SMO", "Website Designing", "Website Revamp", "App Making", "Content Marketing", "Email Marketing", "Affiliate Marketing", "Pay Per click", "Market Segmentation", "Video Advertising", "Display Advertising", "Others"};
    private String[] list_status = new String[]{"Won", "Failure", "Closed", "Others"};
    private String[] list_reason = new String[]{"Not interested in other services", "Budget Issue", "Have their own Team", "Already gave order to other", "Need some time to think", "Others"};


    private ListPopupWindow pw_proposal_sent_for;
    private ListPopupWindow pw_proposal_not_sent_for;
    private ListPopupWindow pw_status;
    private ListPopupWindow pw_reason;
    private ListPopupWindow pw_user;
    private int mYear, mMonth, mDay;
    DatePickerDialog datePickerDialog;
    Calendar c;
    CircleImageView profile_image;
    ImageView img_option;
    String selected_user_id, realPath = "";
    int clickable = 0;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.sales_crm6, container, false);
        LeadCRMList.page6 = true;
        edt_proposal_sent_for = (EditText) view.findViewById(R.id.edt_proposal_sent_for);
        edt_proposal_sent_on = (EditText) view.findViewById(R.id.edt_proposal_sent_on);
        edt_expected_closure_date = (EditText) view.findViewById(R.id.edt_expected_closure_date);
        edt_total_value = (EditText) view.findViewById(R.id.edt_total_value);
        edt_proposal_not_sent_for = (EditText) view.findViewById(R.id.edt_proposal_not_sent_for);
        edt_reason = (EditText) view.findViewById(R.id.edt_reason);
        edt_status = (EditText) view.findViewById(R.id.edt_status);

        edt_other_proposal_sent_for = (EditText) view.findViewById(R.id.edt_other_proposal_sent_for);
        edt_other_proposal_not_sent_for = (EditText) view.findViewById(R.id.edt_other_proposal_not_sent_for);
        edt_other_reason = (EditText) view.findViewById(R.id.edt_other_reason);
        edt_other_status = (EditText) view.findViewById(R.id.edt_other_status);


        edt_user = (EditText) view.findViewById(R.id.edt_user);
        txt_save = (TextView) view.findViewById(R.id.txt_save);
        txt1 = (TextView) view.findViewById(R.id.txt1);
        txt2 = (TextView) view.findViewById(R.id.txt2);
        txt3 = (TextView) view.findViewById(R.id.txt3);
        txt4 = (TextView) view.findViewById(R.id.txt4);
        txt5 = (TextView) view.findViewById(R.id.txt5);
        txt6 = (TextView) view.findViewById(R.id.txt6);
        progressDialog = new AppCompatDialog(getActivity());
        progressDialog.setCancelable(false);
        progressDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progressDialog.setContentView(R.layout.progress_loading);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        prog_message = progressDialog.findViewById(R.id.tv_progress_message);
        prog_message.setText("Please wait..");
        GifImageView gifImageView = (GifImageView) progressDialog.findViewById(R.id.GifImageView);
        gifImageView.setGifImageResource(R.drawable.loadinggif);

        pw_proposal_sent_for = new ListPopupWindow(getActivity());
        pw_proposal_sent_for.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_proposal_sent_for));
        pw_proposal_sent_for.setAnchorView(edt_proposal_sent_for);
        pw_proposal_sent_for.setModal(true);
        pw_proposal_sent_for.setHeight(500);
        pw_proposal_sent_for.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_proposal_sent_for.setText(list_proposal_sent_for[position]);
                pw_proposal_sent_for.dismiss();
                edt_other_proposal_sent_for.setText("");
                if (list_proposal_sent_for[position].equalsIgnoreCase("Others")) {

                    edt_other_proposal_sent_for.setVisibility(View.VISIBLE);
                } else {
                    edt_other_proposal_sent_for.setVisibility(View.GONE);
                }
            }
        });
        pw_proposal_not_sent_for = new ListPopupWindow(getActivity());
        pw_proposal_not_sent_for.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_proposal_not_sent_for));
        pw_proposal_not_sent_for.setAnchorView(edt_proposal_not_sent_for);
        pw_proposal_not_sent_for.setModal(true);
        pw_proposal_not_sent_for.setHeight(500);
        pw_proposal_not_sent_for.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_proposal_not_sent_for.setText(list_proposal_not_sent_for[position]);
                pw_proposal_not_sent_for.dismiss();
                edt_other_proposal_not_sent_for.setText("");
                if (list_proposal_not_sent_for[position].equalsIgnoreCase("Others")) {

                    edt_other_proposal_not_sent_for.setVisibility(View.VISIBLE);
                } else {
                    edt_other_proposal_not_sent_for.setVisibility(View.GONE);
                }
            }
        });
        pw_status = new ListPopupWindow(getActivity());
        pw_status.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_status));
        pw_status.setAnchorView(edt_status);
        pw_status.setModal(true);
        pw_status.setHeight(500);
        pw_status.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_status.setText(list_status[position]);
                pw_status.dismiss();
                edt_other_status.setText("");
                if (list_status[position].equalsIgnoreCase("Others")) {

                    edt_other_status.setVisibility(View.VISIBLE);
                } else {
                    edt_other_status.setVisibility(View.GONE);
                }
            }
        });
        pw_reason = new ListPopupWindow(getActivity());
        pw_reason.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_reason));
        pw_reason.setAnchorView(edt_reason);
        pw_reason.setModal(true);
        pw_reason.setHeight(500);
        pw_reason.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_reason.setText(list_reason[position]);
                pw_reason.dismiss();
                edt_other_reason.setText("");
                if (list_reason[position].equalsIgnoreCase("Others")) {

                    edt_other_reason.setVisibility(View.VISIBLE);
                } else {
                    edt_other_reason.setVisibility(View.GONE);
                }
            }
        });

        edt_proposal_sent_for.setOnClickListener(this);
        edt_proposal_sent_on.setOnClickListener(this);
        edt_expected_closure_date.setOnClickListener(this);
        edt_proposal_not_sent_for.setOnClickListener(this);
        edt_status.setOnClickListener(this);
        edt_reason.setOnClickListener(this);
        edt_user.setOnClickListener(this);
        txt_save.setOnClickListener(this);
        txt1.setOnClickListener(this);
        txt2.setOnClickListener(this);
        txt3.setOnClickListener(this);
        txt4.setOnClickListener(this);
        txt5.setOnClickListener(this);
        txt6.setOnClickListener(this);
        if (LeadCRMForm1.from.equalsIgnoreCase("from_update")) {
            LeadCRMFormUpdate.update_page2 = true;
        } else {
            MainActivity.add_page2 = true;
        }
        executeMethode();
        /*if (Helper.getLocalValue(getActivity(), "user_designation").equalsIgnoreCase("admin")) {
            pw_user = new ListPopupWindow(getActivity());
            pw_user.setAdapter(new UserRoleAdapter(getActivity(), UserList.responce.userListData));
            pw_user.setAnchorView(edt_user);
            pw_user.setModal(true);
            edt_user.setVisibility(View.VISIBLE);
        } else {
            edt_user.setVisibility(View.GONE);
        }*/
        edt_user.setVisibility(View.GONE);


        return view;
    }

    class UserRoleAdapter extends BaseAdapter {

        LayoutInflater inflater;
        List<UserListData> list;

        public UserRoleAdapter(FragmentActivity fragmentActivity, List<UserListData> list) {
            inflater = LayoutInflater.from(fragmentActivity);
            this.list = list;
        }

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int paramInt) {
            return paramInt;
        }

        class ViewHolder {
            TextView txt_role;
        }

        @Override
        public long getItemId(int paramInt) {
            return paramInt;
        }

        @Override
        public View getView(final int paramInt, View itemView, ViewGroup paramViewGroup) {

            UserRoleAdapter.ViewHolder holder;
            if (itemView == null) {
                itemView = inflater.inflate(R.layout.user_role_list, paramViewGroup, false);
                holder = new UserRoleAdapter.ViewHolder();

                holder.txt_role = (TextView) itemView.findViewById(R.id.txt_role);

                itemView.setTag(holder);
            } else {
                holder = (UserRoleAdapter.ViewHolder) itemView.getTag();
            }
            final UserListData roleData = list.get(paramInt);
            holder.txt_role.setText(capitalize(roleData.name));

            holder.txt_role.setTag(paramInt);
            holder.txt_role.setOnClickListener(new View.OnClickListener() {

                @SuppressWarnings("deprecation")
                @Override
                public void onClick(View vv) {
                    // TODO Auto-generated method stub
                    int pos1 = (Integer) vv.getTag();
                    UserListData roleData = list.get(pos1);
                    selected_user_id = roleData.id;
                    edt_user.setText(roleData.name);
                    pw_user.dismiss();
                }
            });
            return itemView;
        }
    }

    private String capitalize(String capString) {
        StringBuffer capBuffer = new StringBuffer();
        Matcher capMatcher = Pattern.compile("([a-z])([a-z]*)", Pattern.CASE_INSENSITIVE).matcher(capString);
        while (capMatcher.find()) {
            capMatcher.appendReplacement(capBuffer, capMatcher.group(1).toUpperCase() + capMatcher.group(2).toLowerCase());
        }
        return capMatcher.appendTail(capBuffer).toString();
    }

    @Override
    public void onClick(View v) {
        InputMethodManager inputManager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);

        inputManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        switch (v.getId()) {
            case R.id.txt_save:
                if (validation()) {
                    data_post();
                }
                break;


            case R.id.edt_proposal_sent_for:
                pw_proposal_sent_for.show();
                break;
            case R.id.edt_proposal_not_sent_for:
                pw_proposal_not_sent_for.show();
                break;
            case R.id.edt_status:
                pw_status.show();
                break;
            case R.id.edt_reason:
                pw_reason.show();
                break;
            case R.id.edt_user:
                pw_user.show();
                break;
            case R.id.edt_proposal_sent_on:
                c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);


                datePickerDialog = new DatePickerDialog(getActivity(),
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {

                                edt_proposal_sent_on.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.show();

                break;
            case R.id.edt_expected_closure_date:
                c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);


                datePickerDialog = new DatePickerDialog(getActivity(),
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {

                                edt_expected_closure_date.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.show();
                break;
            case R.id.txt1:
                if (LeadCRMList.page1) {
                    clickable = 1;
                    data_save();
                }
                break;
            case R.id.txt2:
                if (LeadCRMList.page2) {
                    clickable = 2;
                    data_save();
                }
                break;
            case R.id.txt3:
                if (LeadCRMList.page3) {
                    clickable = 3;
                    data_save();
                }
                break;
            case R.id.txt4:
                if (LeadCRMList.page4) {
                    clickable = 4;
                    data_save();
                }
                break;
            case R.id.txt5:
                if (LeadCRMList.page5) {
                    clickable = 5;
                    data_save();
                }
                break;
            case R.id.txt6:
                if (LeadCRMList.page6) {
                    clickable = 6;
                    data_save();
                }
                break;
        }
    }

    public void data_save() {
        Helper.storeLocally(getActivity(), "Proposal_Sent_For", edt_proposal_sent_for.getText().toString());
        Helper.storeLocally(getActivity(), "proposal_sent_for_other", edt_other_proposal_sent_for.getText().toString());
        Helper.storeLocally(getActivity(), "Proposal_Sent_On", edt_proposal_sent_on.getText().toString());
        Helper.storeLocally(getActivity(), "Total_value", edt_total_value.getText().toString());
        Helper.storeLocally(getActivity(), "Expected_Closure_Date", edt_expected_closure_date.getText().toString());
        Helper.storeLocally(getActivity(), "Proposal_not_sent_for", edt_proposal_not_sent_for.getText().toString());
        Helper.storeLocally(getActivity(), "proposal_not_sent_for_other", edt_other_proposal_not_sent_for.getText().toString());
        Helper.storeLocally(getActivity(), "Reason", edt_reason.getText().toString());
        Helper.storeLocally(getActivity(), "reason_other", edt_other_reason.getText().toString());
        Helper.storeLocally(getActivity(), "Status", edt_status.getText().toString());
        Helper.storeLocally(getActivity(), "status_other", edt_other_status.getText().toString());

        if (clickable == 1) {
            Fragment fragment = new LeadCRMForm1();
            Bundle bundle = new Bundle();
            if (LeadCRMForm1.from.equalsIgnoreCase("from_update")) {
                bundle.putString("from", "from_update");
            } else {
                bundle.putString("from", "from_add");
            }
            fragment.setArguments(bundle);
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page1");
            ft.commit();
        } else if (clickable == 2) {
            Fragment fragment = new LeadCRMForm2();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page2");
            ft.commit();
        } else if (clickable == 3) {
            Fragment fragment = new LeadCRMForm3();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page3");
            ft.commit();
        } else if (clickable == 4) {
            Fragment fragment = new LeadCRMForm4();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page4");
            ft.commit();
        } else if (clickable == 5) {
            Fragment fragment = new LeadCRMForm5();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page5");
            ft.commit();
        } else if (clickable == 6) {
        }
    }

    public boolean validation() {
        /*if (TextUtils.isEmpty(selected_user_id)) {
            Toast.makeText(getActivity(), "Please select user", Toast.LENGTH_SHORT).show();
            return false;
        }*/
        return true;
    }

    private void data_post() {
        InputMethodManager inputManager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);

        inputManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        if (progressDialog != null) progressDialog.show();
        MultipartBody.Builder builder = new MultipartBody.Builder();
        builder.setType(MultipartBody.FORM);
        MultipartBody requestBody;
        CRMResponce crm = new CRMResponce();
        Call<CRMResponce> call;
        //page 1
        if (Helper.getLocalValue(getActivity(), "user_designation").equalsIgnoreCase("admin")) {
            /* builder.addFormDataPart("user_id", selected_user_id);*/
            builder.addFormDataPart("user_id", Helper.getLocalValue(getActivity(), "user_id"));
        } else {
            builder.addFormDataPart("user_id", Helper.getLocalValue(getActivity(), "user_id"));
        }

        builder.addFormDataPart("type", LeadCRMList.type);
        builder.addFormDataPart("number", Helper.getLocalValue(getActivity(), "number"));
        builder.addFormDataPart("f_name", Helper.getLocalValue(getActivity(), "first_name"));
        builder.addFormDataPart("l_name", Helper.getLocalValue(getActivity(), "last_name"));
        builder.addFormDataPart("company", Helper.getLocalValue(getActivity(), "company_name"));
        builder.addFormDataPart("title", Helper.getLocalValue(getActivity(), "title"));
        builder.addFormDataPart("city", Helper.getLocalValue(getActivity(), "city_name"));
        builder.addFormDataPart("address", Helper.getLocalValue(getActivity(), "address"));
        builder.addFormDataPart("loction_name", Helper.getLocalValue(getActivity(), "loction_name"));
        builder.addFormDataPart("state", Helper.getLocalValue(getActivity(), "state"));
        builder.addFormDataPart("pincode", Helper.getLocalValue(getActivity(), "pincode"));
        builder.addFormDataPart("phone", Helper.getLocalValue(getActivity(), "phone"));
        builder.addFormDataPart("mobile", Helper.getLocalValue(getActivity(), "mobile"));
        builder.addFormDataPart("additonal_contact", Helper.getLocalValue(getActivity(), "additonal_contact"));
        builder.addFormDataPart("email", Helper.getLocalValue(getActivity(), "email"));
        builder.addFormDataPart("lead_source", Helper.getLocalValue(getActivity(), "lead_source"));

        builder.addFormDataPart("lead_source_other", Helper.getLocalValue(getActivity(), "lead_source_other"));

        builder.addFormDataPart("no_employee", Helper.getLocalValue(getActivity(), "no_employee"));
        builder.addFormDataPart("annual_revenue", Helper.getLocalValue(getActivity(), "annual_revenue"));
        builder.addFormDataPart("industry", Helper.getLocalValue(getActivity(), "industry"));

        builder.addFormDataPart("industry_other", Helper.getLocalValue(getActivity(), "industry_other"));

        builder.addFormDataPart("lead_owner", Helper.getLocalValue(getActivity(), "lead_owner"));
        builder.addFormDataPart("sales_person", Helper.getLocalValue(getActivity(), "sales_person"));
        if (!TextUtils.isEmpty(realPath)) {
            File file = new File(realPath);
            builder.addFormDataPart("imageUpload", file.getName(), RequestBody.create(MediaType.parse("multipart/form-data"), file));
        }

//page 2
        builder.addFormDataPart("google_reviews", Helper.getLocalValue(getActivity(), "google_reviews"));
        builder.addFormDataPart("google_review_other", Helper.getLocalValue(getActivity(), "google_review_other"));
        builder.addFormDataPart("Just_Dial_Reviews", Helper.getLocalValue(getActivity(), "Just_Dial_Reviews"));
        builder.addFormDataPart("just_dial_reviews_other", Helper.getLocalValue(getActivity(), "just_dial_reviews_other"));
        builder.addFormDataPart("facebook_reviews", Helper.getLocalValue(getActivity(), "facebook_reviews"));
        builder.addFormDataPart("facebook_review_other", Helper.getLocalValue(getActivity(), "facebook_review_other"));
        builder.addFormDataPart("Other_Social_Channel_Reviews", Helper.getLocalValue(getActivity(), "Other_Social_Channel_Reviews"));
        builder.addFormDataPart("other_social_channel_review", Helper.getLocalValue(getActivity(), "other_social_channel_review"));
        builder.addFormDataPart("Fb_likes", Helper.getLocalValue(getActivity(), "Fb_likes"));
        builder.addFormDataPart("facebook_likes_other", Helper.getLocalValue(getActivity(), "facebook_likes_other"));
        builder.addFormDataPart("FB_Followers", Helper.getLocalValue(getActivity(), "FB_Followers"));
        builder.addFormDataPart("facebook_follwers_other", Helper.getLocalValue(getActivity(), "facebook_follwers_other"));
        builder.addFormDataPart("Response_Rate", Helper.getLocalValue(getActivity(), "Response_Rate"));
        builder.addFormDataPart("response_rate_other", Helper.getLocalValue(getActivity(), "response_rate_other"));
        builder.addFormDataPart("Engagement_Rate", Helper.getLocalValue(getActivity(), "Engagement_Rate"));
        builder.addFormDataPart("engagement_rate_other", Helper.getLocalValue(getActivity(), "engagement_rate_other"));
        builder.addFormDataPart("Linkedin_Followers", Helper.getLocalValue(getActivity(), "Linkedin_Followers"));


        //page 3
        builder.addFormDataPart("Website", Helper.getLocalValue(getActivity(), "Website"));
        builder.addFormDataPart("website_other", Helper.getLocalValue(getActivity(), "website_other"));
        builder.addFormDataPart("Website_Technology", Helper.getLocalValue(getActivity(), "Website_Technology"));
        builder.addFormDataPart("website_technology_other", Helper.getLocalValue(getActivity(), "website_technology_other"));
        builder.addFormDataPart("Website_information", Helper.getLocalValue(getActivity(), "Website_information"));
        builder.addFormDataPart("Website_Type", Helper.getLocalValue(getActivity(), "Website_Type"));
        builder.addFormDataPart("website_type_other", Helper.getLocalValue(getActivity(), "website_type_other"));
        builder.addFormDataPart("Overlook_and_Feels", Helper.getLocalValue(getActivity(), "Overlook_and_Feels"));
        builder.addFormDataPart("overlook_and_feel_other", Helper.getLocalValue(getActivity(), "overlook_and_feel_other"));
        builder.addFormDataPart("Website_Language", Helper.getLocalValue(getActivity(), "Website_Language"));
        builder.addFormDataPart("website_language_other", Helper.getLocalValue(getActivity(), "website_language_other"));
        builder.addFormDataPart("Content_Quality", Helper.getLocalValue(getActivity(), "Content_Quality"));
        builder.addFormDataPart("content_quality_other", Helper.getLocalValue(getActivity(), "content_quality_other"));
        builder.addFormDataPart("Graphic_Quality", Helper.getLocalValue(getActivity(), "Graphic_Quality"));
        builder.addFormDataPart("graphic_quality_other", Helper.getLocalValue(getActivity(), "graphic_quality_other"));
        builder.addFormDataPart("Global_Rank", Helper.getLocalValue(getActivity(), "Global_Rank"));
        builder.addFormDataPart("global_rank_other", Helper.getLocalValue(getActivity(), "global_rank_other"));
        builder.addFormDataPart("total_score", Helper.getLocalValue(getActivity(), "total_score"));


//page 4
        builder.addFormDataPart("Ranking_Keyword_1", Helper.getLocalValue(getActivity(), "Ranking_Keyword_1"));
        builder.addFormDataPart("Global_Rank_Keyword_1", Helper.getLocalValue(getActivity(), "Global_Rank_Keyword_1"));
        builder.addFormDataPart("Ranking_Keyword_2", Helper.getLocalValue(getActivity(), "Ranking_Keyword_2"));
        builder.addFormDataPart("Global_Rank_Keyword_2", Helper.getLocalValue(getActivity(), "Global_Rank_Keyword_2"));
        builder.addFormDataPart("Ranking_Keyword_3", Helper.getLocalValue(getActivity(), "Ranking_Keyword_3"));
        builder.addFormDataPart("Global_Rank_Keyword_3", Helper.getLocalValue(getActivity(), "Global_Rank_Keyword_3"));
        builder.addFormDataPart("Ranking_Keyword_4", Helper.getLocalValue(getActivity(), "Ranking_Keyword_4"));
        builder.addFormDataPart("Global_Rank_Keyword_4", Helper.getLocalValue(getActivity(), "Global_Rank_Keyword_4"));
        builder.addFormDataPart("Ranking_Keyword_5", Helper.getLocalValue(getActivity(), "Ranking_Keyword_5"));
        builder.addFormDataPart("Global_Rank_Keyword_5", Helper.getLocalValue(getActivity(), "Global_Rank_Keyword_5"));
        builder.addFormDataPart("Ranking_Keyword_6", Helper.getLocalValue(getActivity(), "Ranking_Keyword_6"));
        builder.addFormDataPart("Global_Rank_Keyword_6", Helper.getLocalValue(getActivity(), "Global_Rank_Keyword_6"));
        builder.addFormDataPart("Ranking_Keyword_7", Helper.getLocalValue(getActivity(), "Ranking_Keyword_7"));
        builder.addFormDataPart("Global_Rank_Keyword_7", Helper.getLocalValue(getActivity(), "Global_Rank_Keyword_7"));


        //page 5
        builder.addFormDataPart("First_Actions", Helper.getLocalValue(getActivity(), "First_Actions"));
        builder.addFormDataPart("first_action_other", Helper.getLocalValue(getActivity(), "first_action_other"));
        builder.addFormDataPart("First_Action_Remarks", Helper.getLocalValue(getActivity(), "First_Action_Remarks"));
        builder.addFormDataPart("first_action_remarks_other", Helper.getLocalValue(getActivity(), "first_action_remarks_other"));
        builder.addFormDataPart("Second_Actions", Helper.getLocalValue(getActivity(), "Second_Actions"));
        builder.addFormDataPart("second_action_other", Helper.getLocalValue(getActivity(), "second_action_other"));
        builder.addFormDataPart("Second_Action_Remarks", Helper.getLocalValue(getActivity(), "Second_Action_Remarks"));
        builder.addFormDataPart("second_action_remarks_other", Helper.getLocalValue(getActivity(), "second_action_remarks_other"));
        builder.addFormDataPart("Third_Actions", Helper.getLocalValue(getActivity(), "Third_Actions"));
        builder.addFormDataPart("third_action_other", Helper.getLocalValue(getActivity(), "third_action_other"));
        builder.addFormDataPart("Third_Action_Remarks", Helper.getLocalValue(getActivity(), "Third_Action_Remarks"));
        builder.addFormDataPart("third_action_remarks_other", Helper.getLocalValue(getActivity(), "third_action_remarks_other"));
        builder.addFormDataPart("Fourth_Actions", Helper.getLocalValue(getActivity(), "Fourth_Actions"));
        builder.addFormDataPart("fourth_action_other", Helper.getLocalValue(getActivity(), "fourth_action_other"));
        builder.addFormDataPart("Fouth_Action_Remarks", Helper.getLocalValue(getActivity(), "Fouth_Action_Remarks"));
        builder.addFormDataPart("fourth_action_remarks_other", Helper.getLocalValue(getActivity(), "fourth_action_remarks_other"));
        builder.addFormDataPart("Fifth_Actions", Helper.getLocalValue(getActivity(), "Fifth_Actions"));
        builder.addFormDataPart("fifth_action_other", Helper.getLocalValue(getActivity(), "fifth_action_other"));
        builder.addFormDataPart("Fifth_Action_Remarks", Helper.getLocalValue(getActivity(), "Fifth_Action_Remarks"));
        builder.addFormDataPart("fifth_action_remarks_other", Helper.getLocalValue(getActivity(), "fifth_action_remarks_other"));
        builder.addFormDataPart("Final_Actions", Helper.getLocalValue(getActivity(), "Final_Actions"));
        builder.addFormDataPart("final_action_other", Helper.getLocalValue(getActivity(), "final_action_other"));
        builder.addFormDataPart("Final_Action_Remarks", Helper.getLocalValue(getActivity(), "Final_Action_Remarks"));
        builder.addFormDataPart("final_action_remarks_other", Helper.getLocalValue(getActivity(), "final_action_remarks_other"));


// page 6
        builder.addFormDataPart("Proposal_Sent_For", edt_proposal_sent_for.getText().toString());
        builder.addFormDataPart("proposal_sent_for_other", edt_other_proposal_sent_for.getText().toString());
        builder.addFormDataPart("Proposal_Sent_On", edt_proposal_sent_on.getText().toString());
        builder.addFormDataPart("Total_value", edt_total_value.getText().toString());
        builder.addFormDataPart("Expected_Closure_Date", edt_expected_closure_date.getText().toString());
        builder.addFormDataPart("Proposal_not_sent_for", edt_proposal_not_sent_for.getText().toString());
        builder.addFormDataPart("proposal_not_sent_for_other", edt_other_proposal_not_sent_for.getText().toString());
        builder.addFormDataPart("Reason", edt_reason.getText().toString());
        builder.addFormDataPart("reason_other", edt_other_reason.getText().toString());
        builder.addFormDataPart("Status", edt_status.getText().toString());
        builder.addFormDataPart("status_other", edt_other_status.getText().toString());

        if (LeadCRMForm1.from.equalsIgnoreCase("from_update")) {
            builder.addFormDataPart("id", LeadCRMDetails.respose.crmListData.get(0).id);
            requestBody = builder.build();
            call = ApiUtils.getAlterationService().sales_form_update(requestBody);
        } else {
            requestBody = builder.build();
            call = ApiUtils.getAlterationService().sales_form(requestBody);
        }
        call.enqueue(new Callback<CRMResponce>() {
            @Override
            public void onResponse(Call<CRMResponce> call, Response<CRMResponce> response) {
                try {
                    if (response.code() == 200) {
                        if (response.body().statusCode == 1) {
                            Method_execute();

                            Toast.makeText(getActivity(), response.body().message, Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getActivity(), response.body().message, Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getActivity(), response.body().message, Toast.LENGTH_SHORT).show();
                    }
                    progressDialog.dismiss();
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<CRMResponce> call, Throwable t) {
                Toast.makeText(getActivity(), t.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        });
    }

    public void Method_execute() {
        Helper.storeLocally(getActivity(), "number", "");
        Helper.storeLocally(getActivity(), "first_name", "");
        Helper.storeLocally(getActivity(), "last_name", "");
        Helper.storeLocally(getActivity(), "company_name", "");
        Helper.storeLocally(getActivity(), "title", "");
        Helper.storeLocally(getActivity(), "city_name", "");
        Helper.storeLocally(getActivity(), "address", "");
        Helper.storeLocally(getActivity(), "loction_name", "");
        Helper.storeLocally(getActivity(), "state", "");
        Helper.storeLocally(getActivity(), "pincode", "");
        Helper.storeLocally(getActivity(), "phone", "");
        Helper.storeLocally(getActivity(), "mobile", "");
        Helper.storeLocally(getActivity(), "additonal_contact", "");
        Helper.storeLocally(getActivity(), "email", "");
        Helper.storeLocally(getActivity(), "lead_source", "");
        Helper.storeLocally(getActivity(), "lead_source_other", "");
        Helper.storeLocally(getActivity(), "no_employee", "");
        Helper.storeLocally(getActivity(), "annual_revenue", "");
        Helper.storeLocally(getActivity(), "industry", "");
        Helper.storeLocally(getActivity(), "industry_other", "");
        Helper.storeLocally(getActivity(), "lead_owner", "");
        Helper.storeLocally(getActivity(), "sales_person", "");


        Helper.storeLocally(getActivity(), "google_reviews", "");
        Helper.storeLocally(getActivity(), "google_review_other", "");
        Helper.storeLocally(getActivity(), "Just_Dial_Reviews", "");
        Helper.storeLocally(getActivity(), "just_dial_reviews_other", "");
        Helper.storeLocally(getActivity(), "facebook_reviews", "");
        Helper.storeLocally(getActivity(), "facebook_review_other", "");
        Helper.storeLocally(getActivity(), "Other_Social_Channel_Reviews", "");
        Helper.storeLocally(getActivity(), "other_social_channel_review", "");
        Helper.storeLocally(getActivity(), "Fb_likes", "");
        Helper.storeLocally(getActivity(), "facebook_likes_other", "");
        Helper.storeLocally(getActivity(), "FB_Followers", "");
        Helper.storeLocally(getActivity(), "facebook_follwers_other", "");
        Helper.storeLocally(getActivity(), "Response_Rate", "");
        Helper.storeLocally(getActivity(), "response_rate_other", "");
        Helper.storeLocally(getActivity(), "Engagement_Rate", "");
        Helper.storeLocally(getActivity(), "engagement_rate_other", "");
        Helper.storeLocally(getActivity(), "Linkedin_Followers", "");

        Helper.storeLocally(getActivity(), "Website", "");
        Helper.storeLocally(getActivity(), "website_other", "");
        Helper.storeLocally(getActivity(), "Website_Technology", "");
        Helper.storeLocally(getActivity(), "website_technology_other", "");
        Helper.storeLocally(getActivity(), "Website_information", "");
        Helper.storeLocally(getActivity(), "Website_Type", "");
        Helper.storeLocally(getActivity(), "website_type_other", "");
        Helper.storeLocally(getActivity(), "Overlook_and_Feels", "");
        Helper.storeLocally(getActivity(), "overlook_and_feel_other", "");
        Helper.storeLocally(getActivity(), "Website_Language", "");
        Helper.storeLocally(getActivity(), "website_language_other", "");
        Helper.storeLocally(getActivity(), "Content_Quality", "");
        Helper.storeLocally(getActivity(), "content_quality_other", "");
        Helper.storeLocally(getActivity(), "Graphic_Quality", "");
        Helper.storeLocally(getActivity(), "graphic_quality_other", "");
        Helper.storeLocally(getActivity(), "Global_Rank", "");
        Helper.storeLocally(getActivity(), "global_rank_other", "");
        Helper.storeLocally(getActivity(), "total_score", "");


        Helper.storeLocally(getActivity(), "Ranking_Keyword_1", "");
        Helper.storeLocally(getActivity(), "Global_Rank_Keyword_1", "");
        Helper.storeLocally(getActivity(), "Ranking_Keyword_2", "");
        Helper.storeLocally(getActivity(), "Global_Rank_Keyword_2", "");
        Helper.storeLocally(getActivity(), "Ranking_Keyword_3", "");
        Helper.storeLocally(getActivity(), "Global_Rank_Keyword_3", "");
        Helper.storeLocally(getActivity(), "Ranking_Keyword_4", "");
        Helper.storeLocally(getActivity(), "Global_Rank_Keyword_4", "");
        Helper.storeLocally(getActivity(), "Ranking_Keyword_5", "");
        Helper.storeLocally(getActivity(), "Global_Rank_Keyword_5", "");
        Helper.storeLocally(getActivity(), "Ranking_Keyword_6", "");
        Helper.storeLocally(getActivity(), "Global_Rank_Keyword_6", "");
        Helper.storeLocally(getActivity(), "Ranking_Keyword_7", "");
        Helper.storeLocally(getActivity(), "Global_Rank_Keyword_7", "");


        Helper.storeLocally(getActivity(), "First_Actions", "");
        Helper.storeLocally(getActivity(), "first_action_other", "");
        Helper.storeLocally(getActivity(), "First_Action_Remarks", "");
        Helper.storeLocally(getActivity(), "first_action_remarks_other", "");
        Helper.storeLocally(getActivity(), "Second_Actions", "");
        Helper.storeLocally(getActivity(), "second_action_other", "");
        Helper.storeLocally(getActivity(), "Second_Action_Remarks", "");
        Helper.storeLocally(getActivity(), "second_action_remarks_other", "");
        Helper.storeLocally(getActivity(), "Third_Actions", "");
        Helper.storeLocally(getActivity(), "third_action_other", "");
        Helper.storeLocally(getActivity(), "Third_Action_Remarks", "");
        Helper.storeLocally(getActivity(), "third_action_remarks_other", "");
        Helper.storeLocally(getActivity(), "Fourth_Actions", "");
        Helper.storeLocally(getActivity(), "fourth_action_other", "");
        Helper.storeLocally(getActivity(), "Fouth_Action_Remarks", "");
        Helper.storeLocally(getActivity(), "fourth_action_remarks_other", "");
        Helper.storeLocally(getActivity(), "Fifth_Actions", "");
        Helper.storeLocally(getActivity(), "fifth_action_other", "");
        Helper.storeLocally(getActivity(), "Fifth_Action_Remarks", "");
        Helper.storeLocally(getActivity(), "fifth_action_remarks_other", "");
        Helper.storeLocally(getActivity(), "Final_Actions", "");
        Helper.storeLocally(getActivity(), "final_action_other", "");
        Helper.storeLocally(getActivity(), "Final_Action_Remarks", "");
        Helper.storeLocally(getActivity(), "final_action_remarks_other", "");


        Helper.storeLocally(getActivity(), "Proposal_Sent_For","");
        Helper.storeLocally(getActivity(), "proposal_sent_for_other","");
        Helper.storeLocally(getActivity(), "Proposal_Sent_On", "");
        Helper.storeLocally(getActivity(), "Total_value", "");
        Helper.storeLocally(getActivity(), "Expected_Closure_Date", "");
        Helper.storeLocally(getActivity(), "Proposal_not_sent_for", "");
        Helper.storeLocally(getActivity(), "proposal_not_sent_for_other", "");
        Helper.storeLocally(getActivity(), "Reason", "");
        Helper.storeLocally(getActivity(), "reason_other", "");
        Helper.storeLocally(getActivity(), "Status", "");
        Helper.storeLocally(getActivity(), "status_other", "");


        MainActivity.drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);

        // Remove back button
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        // Show hamburger
        MainActivity.actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
        // Remove the/any drawer toggle listener
        MainActivity.mToolBarNavigationListenerIsRegistered = false;

        FragmentManager fm = getFragmentManager();
        int size = fm.getBackStackEntryCount();
        if (size > 0) {
            for (int i = 0; i < size; i++) {
                getFragmentManager().popBackStack();
            }
        }
        if (LeadCRMForm1.from.equalsIgnoreCase("from_update")) {
            LeadCRMFormUpdate.update_page2 = true;
            LeadCRMFormUpdate.leadCRMFormUpdate.finish();
            LeadCRMDetails.leadCRMDetails.finish();
            LeadCRMList.updateLead = true;
        } else {
            MainActivity.menu_value.getItem(0).setVisible(false);
            Fragment fragment = new LeadCRMList();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.commit();
            MainActivity.selected_groupPosition = 1;
            MainActivity.expListView.setAdapter(MainActivity.expandableListAdapter);
        }
    }

    public void executeMethode() {
        edt_proposal_sent_for.setText(Helper.getLocalValue(getActivity(), "Proposal_Sent_For"));
        if (Helper.getLocalValue(getActivity(), "Proposal_Sent_For").equalsIgnoreCase("Others")) {
            edt_other_proposal_sent_for.setVisibility(View.VISIBLE);
        }
        edt_other_proposal_sent_for.setText(Helper.getLocalValue(getActivity(), "proposal_sent_for_other"));
        edt_proposal_sent_on.setText(Helper.getLocalValue(getActivity(), "Proposal_Sent_On"));
        edt_total_value.setText(Helper.getLocalValue(getActivity(), "Total_value"));
        edt_expected_closure_date.setText(Helper.getLocalValue(getActivity(), "Expected_Closure_Date"));
        edt_proposal_not_sent_for.setText(Helper.getLocalValue(getActivity(), "Proposal_not_sent_for"));
        if (Helper.getLocalValue(getActivity(), "Proposal_not_sent_for").equalsIgnoreCase("Others")) {
            edt_other_proposal_not_sent_for.setVisibility(View.VISIBLE);
        }
        edt_other_proposal_not_sent_for.setText(Helper.getLocalValue(getActivity(), "proposal_not_sent_for_other"));
        edt_reason.setText(Helper.getLocalValue(getActivity(), "Reason"));
        if (Helper.getLocalValue(getActivity(), "Reason").equalsIgnoreCase("Others")) {
            edt_other_reason.setVisibility(View.VISIBLE);
        }
        edt_other_reason.setText(Helper.getLocalValue(getActivity(), "reason_other"));
        edt_status.setText(Helper.getLocalValue(getActivity(), "Status"));
        if (Helper.getLocalValue(getActivity(), "Status").equalsIgnoreCase("Others")) {
            edt_other_status.setVisibility(View.VISIBLE);
        }
        edt_other_status.setText(Helper.getLocalValue(getActivity(), "status_other"));
    }
}

