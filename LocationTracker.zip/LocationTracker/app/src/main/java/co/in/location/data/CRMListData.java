package co.in.location.data;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CRMListData {
    @SerializedName("id")
    @Expose
    public String id;
    @SerializedName("number")
    @Expose
    public String number;
    @SerializedName("f_name")
    @Expose
    public String f_name;
    @SerializedName("l_name")
    @Expose
    public String l_name;
    @SerializedName("profile_image")
    @Expose
    public String profile_image;
    @SerializedName("company")
    @Expose
    public String company;
    @SerializedName("title")
    @Expose
    public String title;
    @SerializedName("address")
    @Expose
    public String address;
    @SerializedName("location")
    @Expose
    public String location;
    @SerializedName("city")
    @Expose
    public String city;
    @SerializedName("state")
    @Expose
    public String state;
    @SerializedName("pincode")
    @Expose
    public String pincode;
    @SerializedName("phone")
    @Expose
    public String phone;
    @SerializedName("mobile")
    @Expose
    public String mobile;
    @SerializedName("additonal_contact")
    @Expose
    public String additonal_contact;
    @SerializedName("email")
    @Expose
    public String email;
    @SerializedName("lead_source")
    @Expose
    public String lead_source;
    @SerializedName("lead_source_other")
    @Expose
    public String lead_source_other;
    @SerializedName("sales_person")
    @Expose
    public String sales_person;
    @SerializedName("no_employee")
    @Expose
    public String no_employee;
    @SerializedName("annual_revenue")
    @Expose
    public String annual_revenue;
    @SerializedName("total_score")
    @Expose
    public String total_score;
    @SerializedName("industry")
    @Expose
    public String industry;
    @SerializedName("industry_other")
    @Expose
    public String industry_other;
    @SerializedName("lead_owner")
    @Expose
    public String lead_owner;
    @SerializedName("google_reviews")
    @Expose
    public String google_reviews;
    @SerializedName("google_review_other")
    @Expose
    public String google_review_other;
    @SerializedName("facebook_reviews")
    @Expose
    public String facebook_reviews;
    @SerializedName("facebook_review_other")
    @Expose
    public String facebook_review_other;
    @SerializedName("Just_Dial_Reviews")
    @Expose
    public String Just_Dial_Reviews;
    @SerializedName("just_dial_reviews_other")
    @Expose
    public String just_dial_reviews_other;
    @SerializedName("Other_Social_Channel_Reviews")
    @Expose
    public String Other_Social_Channel_Reviews;
    @SerializedName("other_social_channel_review")
    @Expose
    public String other_social_channel_review;
    @SerializedName("Fb_likes")
    @Expose
    public String Fb_likes;
    @SerializedName("facebook_likes_other")
    @Expose
    public String facebook_likes_other;
    @SerializedName("FB_Followers")
    @Expose
    public String FB_Followers;
    @SerializedName("facebook_follwers_other")
    @Expose
    public String facebook_follwers_other;
    @SerializedName("Response_Rate")
    @Expose
    public String Response_Rate;
    @SerializedName("response_rate_other")
    @Expose
    public String response_rate_other;
    @SerializedName("Engagement_Rate")
    @Expose
    public String Engagement_Rate;
    @SerializedName("engagement_rate_other")
    @Expose
    public String engagement_rate_other;
    @SerializedName("Linkedin_Followers")
    @Expose
    public String Linkedin_Followers;
    @SerializedName("Website")
    @Expose
    public String Website;
    @SerializedName("website_other")
    @Expose
    public String website_other;
    @SerializedName("Website_Technology")
    @Expose
    public String Website_Technology;
    @SerializedName("website_technology_other")
    @Expose
    public String website_technology_other;
    @SerializedName("Website_information")
    @Expose
    public String Website_information;
    @SerializedName("Website_Type")
    @Expose
    public String Website_Type;
    @SerializedName("website_type_other")
    @Expose
    public String website_type_other;
    @SerializedName("Overlook_and_Feels")
    @Expose
    public String Overlook_and_Feels;
    @SerializedName("overlook_and_feel_other")
    @Expose
    public String overlook_and_feel_other;
    @SerializedName("Website_Language")
    @Expose
    public String Website_Language;
    @SerializedName("website_language_other")
    @Expose
    public String website_language_other;
    @SerializedName("Content_Quality")
    @Expose
    public String Content_Quality;
    @SerializedName("content_quality_other")
    @Expose
    public String content_quality_other;
    @SerializedName("Graphic_Quality")
    @Expose
    public String Graphic_Quality;
    @SerializedName("graphic_quality_other")
    @Expose
    public String graphic_quality_other;
    @SerializedName("Global_Rank")
    @Expose
    public String Global_Rank;
    @SerializedName("global_rank_other")
    @Expose
    public String global_rank_other;
    @SerializedName("Ranking_Keyword_1")
    @Expose
    public String Ranking_Keyword_1;
    @SerializedName("Ranking_Keyword_2")
    @Expose
    public String Ranking_Keyword_2;
    @SerializedName("Ranking_Keyword_3")
    @Expose
    public String Ranking_Keyword_3;
    @SerializedName("Ranking_Keyword_4")
    @Expose
    public String Ranking_Keyword_4;
    @SerializedName("Ranking_Keyword_5")
    @Expose
    public String Ranking_Keyword_5;
    @SerializedName("Ranking_Keyword_6")
    @Expose
    public String Ranking_Keyword_6;
    @SerializedName("Ranking_Keyword_7")
    @Expose
    public String Ranking_Keyword_7;
    @SerializedName("Global_Rank_Keyword_1")
    @Expose
    public String Global_Rank_Keyword_1;
    @SerializedName("Global_Rank_Keyword_2")
    @Expose
    public String Global_Rank_Keyword_2;
    @SerializedName("Global_Rank_Keyword_3")
    @Expose
    public String Global_Rank_Keyword_3;
    @SerializedName("Global_Rank_Keyword_4")
    @Expose
    public String Global_Rank_Keyword_4;
    @SerializedName("Global_Rank_Keyword_5")
    @Expose
    public String Global_Rank_Keyword_5;
    @SerializedName("Global_Rank_Keyword_6")
    @Expose
    public String Global_Rank_Keyword_6;
    @SerializedName("Global_Rank_Keyword_7")
    @Expose
    public String Global_Rank_Keyword_7;
    @SerializedName("First_Actions")
    @Expose
    public String First_Actions;
    @SerializedName("first_action_other")
    @Expose
    public String first_action_other;
    @SerializedName("Second_Actions")
    @Expose
    public String Second_Actions;
    @SerializedName("second_action_other")
    @Expose
    public String second_action_other;
    @SerializedName("Third_Actions")
    @Expose
    public String Third_Actions;
    @SerializedName("third_action_other")
    @Expose
    public String third_action_other;
    @SerializedName("Fourth_Actions")
    @Expose
    public String Fourth_Actions;
    @SerializedName("fourth_action_other")
    @Expose
    public String fourth_action_other;
    @SerializedName("Fifth_Actions")
    @Expose
    public String Fifth_Actions;
    @SerializedName("fifth_action_other")
    @Expose
    public String fifth_action_other;
    @SerializedName("Final_Actions")
    @Expose
    public String Final_Actions;
    @SerializedName("final_action_other")
    @Expose
    public String final_action_other;
    @SerializedName("First_Action_Remarks")
    @Expose
    public String First_Action_Remarks;
    @SerializedName("first_action_remarks_other")
    @Expose
    public String first_action_remarks_other;
    @SerializedName("Second_Action_Remarks")
    @Expose
    public String Second_Action_Remarks;
    @SerializedName("second_action_remarks_other")
    @Expose
    public String second_action_remarks_other;
    @SerializedName("Third_Action_Remarks")
    @Expose
    public String Third_Action_Remarks;
    @SerializedName("third_action_remarks_other")
    @Expose
    public String third_action_remarks_other;
    @SerializedName("Fouth_Action_Remarks")
    @Expose
    public String Fouth_Action_Remarks;
    @SerializedName("fourth_action_remarks_other")
    @Expose
    public String fourth_action_remarks_other;
    @SerializedName("Fifth_Action_Remarks")
    @Expose
    public String Fifth_Action_Remarks;
    @SerializedName("fifth_action_remarks_other")
    @Expose
    public String fifth_action_remarks_other;
    @SerializedName("Final_Action_Remarks")
    @Expose
    public String Final_Action_Remarks;
    @SerializedName("final_action_remarks_other")
    @Expose
    public String final_action_remarks_other;
    @SerializedName("Proposal_Sent_For")
    @Expose
    public String Proposal_Sent_For;
    @SerializedName("proposal_sent_for_other")
    @Expose
    public String proposal_sent_for_other;
    @SerializedName("Total_value")
    @Expose
    public String Total_value;
    @SerializedName("Proposal_not_sent_for")
    @Expose
    public String Proposal_not_sent_for;
    @SerializedName("proposal_not_sent_for_other")
    @Expose
    public String proposal_not_sent_for_other;
    @SerializedName("Status")
    @Expose
    public String Status;
    @SerializedName("status_other")
    @Expose
    public String status_other;
    @SerializedName("Proposal_Sent_On")
    @Expose
    public String Proposal_Sent_On;
    @SerializedName("Expected_Closure_Date")
    @Expose
    public String Expected_Closure_Date;
    @SerializedName("Reason")
    @Expose
    public String Reason;
    @SerializedName("reason_other")
    @Expose
    public String reason_other;
}
