package co.in.location.crm;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.util.TextUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import co.in.location.R;
import co.in.location.data.CRMListData;
import co.in.location.response.CRMListResponse;
import de.hdodenhof.circleimageview.CircleImageView;

public class LeadCRMListSearch extends AppCompatActivity {
    RecyclerView recyclerView;
    String name, email, phone, address, profile_pic;
    TextView txt_message;
    CRMListResponse respose;
    MyCustomAdapter adapter;
    public static boolean deleteLead = false;
    public static boolean updateLead = false;
    private int lastPosition = -1;
    EditText edt;
    //    public List<MessageData> message_list_data_search = new ArrayList<MessageData>();
    ImageView img_back;
    View edt_view;
    public List<CRMListData> crm_list_data_search = new ArrayList<CRMListData>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_crmlist_new);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        recyclerView = (RecyclerView) findViewById(R.id.crm_list);
        txt_message = (TextView) findViewById(R.id.txt_message);
        recyclerView.setLayoutManager(new LinearLayoutManager(LeadCRMListSearch.this));
        recyclerView.setNestedScrollingEnabled(true);
        recyclerView.addItemDecoration(new DividerItemDecoration(LeadCRMListSearch.this, DividerItemDecoration.VERTICAL));
        img_back = (ImageView) findViewById(R.id.img_back);
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LeadCRMListSearch.this.finish();
            }
        });
        edt = (EditText) findViewById(R.id.edt);
        edt_view = (View) findViewById(R.id.edt_view);
        edt.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.clear, 0);

        edt.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                final int DRAWABLE_LEFT = 0;
                final int DRAWABLE_TOP = 1;
                final int DRAWABLE_RIGHT = 2;
                final int DRAWABLE_BOTTOM = 3;

                if (event.getAction() == MotionEvent.ACTION_UP) {
                    if (event.getRawX() >= (edt.getRight() - edt.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {
                        edt.setText("");
                        edt.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.clear_white, 0);
//                        adapter = new MyCustomAdapter(SearchUser.this, responce.userdata);
//                        user_ListView.setAdapter(adapter);
                        return true;
                    }
                }
                return false;
            }
        });

        //
        edt.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {
                // put the code of save Database here
                edt.setError(null);
                if (s.toString().length() > 0) {
                    edt_view.setBackgroundColor(getResources().getColor(R.color.white));
                    edt.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.clear_white, 0);
                } else {
                    edt_view.setBackgroundColor(getResources().getColor(R.color.white_lite));
                    edt.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.clear, 0);
                }
                crm_list_data_search = new ArrayList<CRMListData>();
                for (int i = 0; i < respose.crmListData.size(); i++) {
                    if ((respose.crmListData.get(i).company.toLowerCase().contains(edt.getText().toString().toLowerCase())) || (respose.crmListData.get(i).email.toLowerCase().contains(edt.getText().toString().toLowerCase()))) {
                        crm_list_data_search.add(respose.crmListData.get(i));
                    }
                }
                if (crm_list_data_search.size() > 0) {
                    txt_message.setVisibility(View.GONE);
                } else {
                    txt_message.setVisibility(View.VISIBLE);
                    txt_message.setText("Empty! Record not found");
                }
                adapter = new MyCustomAdapter(crm_list_data_search);
                recyclerView.setAdapter(adapter);
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
        });
        //
        edt.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
//                    InputMethodManager inputManager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
//
//                    inputManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);

                    InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
                    inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
                    edt.setSelectAllOnFocus(false);
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(edt.getWindowToken(), 0);
//                    performSearch();
                    crm_list_data_search = new ArrayList<CRMListData>();
                    for (int i = 0; i < respose.crmListData.size(); i++) {
                        if (respose.crmListData.get(i).company.toLowerCase().contains(edt.getText().toString())) {
                            crm_list_data_search.add(respose.crmListData.get(i));
                        }
                    }
                    if (crm_list_data_search.size() > 0) {
                        txt_message.setVisibility(View.GONE);
                    } else {
                        txt_message.setVisibility(View.VISIBLE);
                        txt_message.setText("Empty! Record not found");
                    }
                    adapter = new MyCustomAdapter(crm_list_data_search);
                    recyclerView.setAdapter(adapter);
                    return true;
                }
                return false;
            }
        });
        getCRMList();
    }

    private void getCRMList() {
        try {
            if (LeadCRMList.respose.statusCode == 1) {
                if (LeadCRMList.respose != null) {
                    crm_list_data_search = LeadCRMList.respose.crmListData;
                    respose = LeadCRMList.respose;

                    adapter = null;
                    adapter = new MyCustomAdapter(respose.crmListData);
                    recyclerView.setAdapter(adapter);
                    if (respose.crmListData.size() > 0) {
                        txt_message.setVisibility(View.GONE);
                    } else {
                        txt_message.setVisibility(View.VISIBLE);
                    }
                } else {
                    Toast.makeText(LeadCRMListSearch.this, respose.message, Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(LeadCRMListSearch.this, respose.message, Toast.LENGTH_SHORT).show();

            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(LeadCRMListSearch.this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public class MyCustomAdapter extends RecyclerView.Adapter<MyCustomAdapter.ItemViewHolder> {

        List<CRMListData> list;

        public MyCustomAdapter(List<CRMListData> list) {
            this.list = list;
        }


        @Override
        public MyCustomAdapter.ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

            return new MyCustomAdapter.ItemViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.crm_list_item_new, parent, false));
        }

        public void onBindViewHolder(final MyCustomAdapter.ItemViewHolder holder, final int position) {

            try {

                final CRMListData crmListData = list.get(position);
                holder.txt_name.setText(capitalize(crmListData.company));
                String searchString = edt.getText().toString();
                if ((!TextUtils.isEmpty(searchString)) && (crmListData.company.toLowerCase().contains(searchString.toLowerCase()))) {
                    holder.txt_name.setText(highlightSearchKey(searchString, crmListData.company));
                }
                holder.txt_email.setText(crmListData.email);
                holder.txt_email.setText(crmListData.email);
                if ((!TextUtils.isEmpty(searchString)) && (crmListData.email.toLowerCase().contains(searchString.toLowerCase()))) {
                    holder.txt_email.setText(highlightSearchKey(searchString, crmListData.email));
                }

                /*if (position > lastPosition) {

                    Animation animation = AnimationUtils.loadAnimation(LeadCRMListSearch.this, R.anim.up_from_bottom);
                    holder.itemView.startAnimation(animation);
                    lastPosition = position;
                } else {
                    Animation animation = AnimationUtils.loadAnimation(LeadCRMListSearch.this, R.anim.bottom_from_up);
                    holder.itemView.startAnimation(animation);
                    lastPosition = position;
                }*/
                holder.card_view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                       /* selected_id = userListData.id;
                        name = userListData.name;
                        email = userListData.email;
                        phone = userListData.phone;
                        address = userListData.address;
                        designation = userListData.designation;
                        profile_pic = userListData.profile_image;*/

                        Intent in = new Intent(LeadCRMListSearch.this, LeadCRMDetails.class);
                        in.putExtra("id", crmListData.id);
                        startActivity(in);
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public int getItemCount() {
            return list != null ? list.size() : 0;
        }

        class ItemViewHolder extends RecyclerView.ViewHolder {
            TextView txt_name, txt_email;
            CircleImageView img_profile_image;
            CardView card_view;

            public ItemViewHolder(View itemView) {
                super(itemView);
                txt_name = (TextView) itemView.findViewById(R.id.txt_name);
                txt_email = (TextView) itemView.findViewById(R.id.txt_email);
                img_profile_image = (CircleImageView) itemView.findViewById(R.id.img_profile_image);
                card_view = (CardView) itemView.findViewById(R.id.card_view);
            }
        }
    }
    private Spannable highlightSearchKey(String s, String text) {
        SpannableString spannableString = new SpannableString(text);
        ForegroundColorSpan[] backgroundColorSpan = spannableString.getSpans(0, spannableString.length(), ForegroundColorSpan.class);
        for (ForegroundColorSpan bgSpan : backgroundColorSpan) {
            spannableString.removeSpan(bgSpan);
        }
        int indexOfKeyWord = spannableString.toString().toLowerCase().indexOf(s.toLowerCase());
        while (indexOfKeyWord > -1) {
            spannableString.setSpan(new ForegroundColorSpan(Color.BLUE), indexOfKeyWord, indexOfKeyWord + s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            indexOfKeyWord = spannableString.toString().toLowerCase().indexOf(s.toLowerCase(), indexOfKeyWord + s.length());
        }
        return spannableString;
    }
    private String capitalize(String capString) {
        StringBuffer capBuffer = new StringBuffer();
        Matcher capMatcher = Pattern.compile("([a-z])([a-z]*)", Pattern.CASE_INSENSITIVE).matcher(capString);
        while (capMatcher.find()) {
            capMatcher.appendReplacement(capBuffer, capMatcher.group(1).toUpperCase() + capMatcher.group(2).toLowerCase());
        }
        return capMatcher.appendTail(capBuffer).toString();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (deleteLead || updateLead) {
            deleteLead = false;
            updateLead = false;
            adapter = null;
            getCRMList();
        }
    }


}