package co.in.location;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import co.in.location.slider.Tab_AllFestival;
import co.in.location.slider.Tab_Edit_Update;
import co.in.location.slider.Tab_Holidays;

public class ViewPagerAdapter extends FragmentStatePagerAdapter {

	CharSequence Titles[];
	int NumbOfTabs;

	public ViewPagerAdapter(FragmentManager fm, CharSequence mTitles[],
                            int mNumbOfTabsumb) {
		super(fm);
		this.Titles = mTitles;
		this.NumbOfTabs = mNumbOfTabsumb;
	}
	// This method return the fragment for the every position in the View Pager
	@Override
	public Fragment getItem(int position) {
		switch (position) {
			case 0:
				Tab_Holidays tabholidays = new Tab_Holidays();
				return tabholidays;
			case 1:
				Tab_AllFestival tab_festival = new Tab_AllFestival();
				return tab_festival;
			case 2:
				Tab_Edit_Update tab_edit = new Tab_Edit_Update();
				return tab_edit;
			default:
				return null;
		}
	}
	// This method return the titles for the Tabs in the Tab Strip
	@Override
	public CharSequence getPageTitle(int position) {
		return Titles[position];
	}
	// This method return the Number of tabs for the tabs Strip
	@Override
	public int getCount() {
		return NumbOfTabs;
	}
}