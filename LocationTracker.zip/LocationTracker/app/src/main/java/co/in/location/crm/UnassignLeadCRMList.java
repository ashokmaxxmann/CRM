package co.in.location.crm;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AppCompatDialog;
import android.support.v7.widget.AppCompatCheckBox;
import android.support.v7.widget.CardView;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListPopupWindow;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.futuremind.recyclerviewfastscroll.FastScroller;
import com.futuremind.recyclerviewfastscroll.SectionTitleProvider;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import co.in.location.GifImageView;
import co.in.location.Helper;
import co.in.location.MainActivity;
import co.in.location.R;
import co.in.location.Remote.ApiUtils;
import co.in.location.admin.UserList;
import co.in.location.data.CRMListData;
import co.in.location.data.UserListData;
import co.in.location.response.CRMListResponse;
import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UnassignLeadCRMList extends Fragment implements View.OnClickListener {
    View view;
    RecyclerView recyclerView;
    String name, email, phone, address, profile_pic;
    TextView txt_message, prog_message, txt_assign;
    public static CRMListResponse respose;
    //    MyCustomAdapter adapter;
    public static boolean deleteLead = false;
    public static boolean updateLead = false;
    AppCompatDialog progressDialog;
    String user_id = "", assigntoId;
    private int lastPosition = -1;
    ImageView img_add_lead;
    LinearLayoutManager linearLayoutManager;
    int Totalcount = 0, currentpage = 1, number_of_page = 0, selected_button = 1;
    TextView txt_back, txt_next, txt_1, txt_2, txt_3, txt_4;
    public static boolean page1 = true, page2 = false, page3 = false, page4 = false, page5 = false, page6 = false;
    private FastScroller fastScroller;
    int clickposition = -1;
    RelativeLayout rl_pagination, rl_assign;
    LinearLayout ll_pagination;
    private ListPopupWindow pw_user;
    List<CRMListData> list;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        setHasOptionsMenu(true);
        view = inflater.inflate(R.layout.crm_list, container, false);
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        recyclerView = (RecyclerView) view.findViewById(R.id.crm_list);
        fastScroller = (FastScroller) view.findViewById(R.id.fastscroll);
        fastScroller.setRecyclerView(recyclerView);
        txt_message = (TextView) view.findViewById(R.id.txt_message);
        rl_pagination = (RelativeLayout) view.findViewById(R.id.rl_pagination);
        ll_pagination = (LinearLayout) view.findViewById(R.id.ll_pagination);
        rl_assign = (RelativeLayout) view.findViewById(R.id.rl_assign);
        txt_assign = view.findViewById(R.id.txt_assign);
        /*recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));*/

        linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);

        recyclerView.setNestedScrollingEnabled(true);
        recyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL));
        progressDialog = new AppCompatDialog(getActivity());
        progressDialog.setCancelable(false);
        progressDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progressDialog.setContentView(R.layout.progress_loading);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        prog_message = progressDialog.findViewById(R.id.tv_progress_message);
        prog_message.setText("Please wait..");
        GifImageView gifImageView = (GifImageView) progressDialog.findViewById(R.id.GifImageView);
        gifImageView.setGifImageResource(R.drawable.loadinggif);
        img_add_lead = (ImageView) view.findViewById(R.id.img_add_lead);

        txt_back = (TextView) view.findViewById(R.id.txt_back);
        txt_next = (TextView) view.findViewById(R.id.txt_next);
        txt_1 = (TextView) view.findViewById(R.id.txt_1);
        txt_2 = (TextView) view.findViewById(R.id.txt_2);
        txt_3 = (TextView) view.findViewById(R.id.txt_3);
        txt_4 = (TextView) view.findViewById(R.id.txt_4);
        img_add_lead.setOnClickListener(this);
        txt_back.setOnClickListener(this);
        txt_next.setOnClickListener(this);
        txt_1.setOnClickListener(this);
        txt_2.setOnClickListener(this);
        txt_3.setOnClickListener(this);
        txt_4.setOnClickListener(this);
        txt_assign.setOnClickListener(this);

        if (Helper.getLocalValue(getActivity(), "user_designation").equalsIgnoreCase("admin")) {
            user_id = "0";
            ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Unassign Leads");
        } else {
            user_id = Helper.getLocalValue(getActivity(), "user_id");
            ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("My Unassign Leads");
        }
        MainActivity.all_lead = true;
        txt_1.setBackgroundResource(R.drawable.select_circle_background);
        getCRMList(currentpage);
        FragmentManager fm = getFragmentManager();
        int size = fm.getBackStackEntryCount();
        if (size == 1) {
            getFragmentManager().popBackStack();
        }
        MainActivity.long_press = false;
        clickposition = -1;
        return view;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_add_lead:
                MainActivity.add_lead = true;
                page1 = false;
                page2 = false;
                page3 = false;
                page4 = false;
                page5 = false;
                page6 = false;
                Method_execute();
                ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Create Lead");
                enableViews(true);
                Fragment fragment = new LeadCRMForm1();
                Bundle bundle = new Bundle();
                bundle.putString("from", "from_add");
                fragment.setArguments(bundle);
                FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.frame, fragment);
                ft.addToBackStack("page1");
                ft.commit();
                break;
            case R.id.txt_back:
                if (selected_button == 4) {
                    selectthree();
                } else if (selected_button == 3) {
                    selecttwo();
                } else if (selected_button == 2) {
                    selectone();
                } else {
                    txt_4.setText(txt_3.getText().toString());
                    txt_3.setText(txt_2.getText().toString());
                    txt_2.setText(txt_1.getText().toString());
                    txt_1.setText("" + (Integer.parseInt(txt_1.getText().toString()) - 1));
                }

                currentpage = currentpage - 1;
                if (currentpage == 1) {
                    txt_back.setVisibility(View.GONE);
                }
                getCRMList(currentpage);
                break;
            case R.id.txt_next:
                if (selected_button == 1) {
                    selecttwo();
                } else if (selected_button == 2) {
                    selectthree();
                } else if (selected_button == 3) {
                    selectfour();
                } else {
                    txt_1.setText(txt_2.getText().toString());
                    txt_2.setText(txt_3.getText().toString());
                    txt_3.setText(txt_4.getText().toString());
                    txt_4.setText("" + (Integer.parseInt(txt_4.getText().toString()) + 1));
                }
                if (currentpage == number_of_page) {
                    txt_next.setVisibility(View.GONE);
                }
                currentpage = currentpage + 1;
                getCRMList(currentpage);
                break;
            case R.id.txt_1:
                selectone();
                currentpage = Integer.parseInt(txt_1.getText().toString());
                selected_button = 1;
                getCRMList(currentpage);
                break;
            case R.id.txt_2:
                selecttwo();
                currentpage = Integer.parseInt(txt_2.getText().toString());
                selected_button = 2;
                getCRMList(currentpage);
                break;
            case R.id.txt_3:
                selectthree();
                currentpage = Integer.parseInt(txt_3.getText().toString());
                selected_button = 3;
                getCRMList(currentpage);
                break;
            case R.id.txt_4:
                selectfour();
                currentpage = Integer.parseInt(txt_4.getText().toString());
                selected_button = 4;
                getCRMList(currentpage);
                break;
            case R.id.txt_assign:

                final Dialog dialog = new Dialog(getActivity());
                dialog.setContentView(R.layout.custom_dialog);
                dialog.setTitle("Title...");
                dialog.setCancelable(false);
                ListView myNames = (ListView) dialog.findViewById(R.id.List);
                TextView txt_submit = (TextView) dialog.findViewById(R.id.txt_submit);
                myNames.setAdapter(new UserRoleAdapter(getActivity(), UserList.responce.userListData));
                dialog.show();

                txt_submit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                        assign();
                    }
                });
                break;
        }
    }

    public void selectone() {
        selected_button = 1;
        txt_1.setBackgroundResource(R.drawable.select_circle_background);
        txt_2.setBackgroundResource(R.drawable.unselect_circle_background);
        txt_3.setBackgroundResource(R.drawable.unselect_circle_background);
        txt_4.setBackgroundResource(R.drawable.unselect_circle_background);
    }

    public void selecttwo() {
        selected_button = 2;
        txt_1.setBackgroundResource(R.drawable.unselect_circle_background);
        txt_2.setBackgroundResource(R.drawable.select_circle_background);
        txt_3.setBackgroundResource(R.drawable.unselect_circle_background);
        txt_4.setBackgroundResource(R.drawable.unselect_circle_background);
    }

    public void selectthree() {
        selected_button = 3;
        txt_1.setBackgroundResource(R.drawable.unselect_circle_background);
        txt_2.setBackgroundResource(R.drawable.unselect_circle_background);
        txt_3.setBackgroundResource(R.drawable.select_circle_background);
        txt_4.setBackgroundResource(R.drawable.unselect_circle_background);
    }

    public void selectfour() {
        selected_button = 4;
        txt_1.setBackgroundResource(R.drawable.unselect_circle_background);
        txt_2.setBackgroundResource(R.drawable.unselect_circle_background);
        txt_3.setBackgroundResource(R.drawable.unselect_circle_background);
        txt_4.setBackgroundResource(R.drawable.select_circle_background);
    }

    private void getCRMList(int currentpage) {
        clickposition = -1;
        MainActivity.checked_id.clear();
        if (progressDialog != null) progressDialog.show();
        ApiUtils.getAlterationService().getCRMList("leads-list", user_id,"", Integer.toString(currentpage)).enqueue(new Callback<CRMListResponse>() {
            @Override
            public void onResponse(Call<CRMListResponse> call, Response<CRMListResponse> response) {
                try {
                    if (response.code() == 200) {
                        if (response.body().statusCode == 1) {
                            if (response.body() != null) {
                                for (int i = 0; i < response.body().crmListData.size(); i++) {
                                    HashMap<String, Boolean> innerHash = new HashMap<String, Boolean>();
                                    innerHash.put(response.body().crmListData.get(i).id, false);
                                    MainActivity.checked_id.put(i, innerHash);
                                }
                                respose = response.body();
                                Totalcount = response.body().Totalcount;
                                int remainder = Totalcount % 15;
                                int quotient = Totalcount / 15;
                                if (remainder > 0) {
                                    number_of_page = quotient + 1;
                                } else {
                                    number_of_page = quotient;
                                }
                                if (number_of_page > 4) {
                                    txt_1.setVisibility(View.VISIBLE);
                                    txt_2.setVisibility(View.VISIBLE);
                                    txt_3.setVisibility(View.VISIBLE);
                                    txt_4.setVisibility(View.VISIBLE);
                                    txt_next.setVisibility(View.VISIBLE);
                                    txt_back.setVisibility(View.VISIBLE);
                                    if (Integer.parseInt(txt_1.getText().toString()) == 1) {
                                        txt_back.setVisibility(View.GONE);
                                    }
                                    if (Integer.parseInt(txt_4.getText().toString()) == number_of_page) {
                                        txt_next.setVisibility(View.GONE);
                                    }
                                } else if (number_of_page == 4) {
                                    txt_1.setVisibility(View.VISIBLE);
                                    txt_2.setVisibility(View.VISIBLE);
                                    txt_3.setVisibility(View.VISIBLE);
                                    txt_4.setVisibility(View.VISIBLE);
                                    txt_next.setVisibility(View.GONE);
                                    txt_back.setVisibility(View.GONE);
                                } else if (number_of_page == 3) {
                                    txt_1.setVisibility(View.VISIBLE);
                                    txt_2.setVisibility(View.VISIBLE);
                                    txt_3.setVisibility(View.VISIBLE);
                                    txt_4.setVisibility(View.GONE);
                                    txt_next.setVisibility(View.GONE);
                                    txt_back.setVisibility(View.GONE);
                                } else if (number_of_page == 2) {
                                    txt_1.setVisibility(View.VISIBLE);
                                    txt_2.setVisibility(View.VISIBLE);
                                    txt_3.setVisibility(View.GONE);
                                    txt_4.setVisibility(View.GONE);
                                    txt_next.setVisibility(View.GONE);
                                    txt_back.setVisibility(View.GONE);
                                } else if (number_of_page == 1) {
                                    txt_1.setVisibility(View.VISIBLE);
                                    txt_2.setVisibility(View.GONE);
                                    txt_3.setVisibility(View.GONE);
                                    txt_4.setVisibility(View.GONE);
                                    txt_next.setVisibility(View.GONE);
                                    txt_back.setVisibility(View.GONE);
                                }
                                MainActivity.unassign_adapter = null;
                                MainActivity.unassign_adapter = new MyCustomAdapter(response.body().crmListData);// new MyCustomAdapter(SocialAccount.this, response.body().socialdata);
                                recyclerView.setAdapter(MainActivity.unassign_adapter);
                                fastScroller.setRecyclerView(recyclerView);
                                if (response.body().crmListData.size() > 0) {
                                    txt_message.setVisibility(View.GONE);
                                } else {
                                    txt_message.setVisibility(View.VISIBLE);
                                }
                            } else {

                                Toast.makeText(getActivity(), response.body().message, Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(getActivity(), response.body().message, Toast.LENGTH_SHORT).show();
                        }
                    }
                    progressDialog.dismiss();
                } catch (Exception e) {
                    progressDialog.dismiss();
                    e.printStackTrace();
                    Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<CRMListResponse> call, Throwable t) {
                progressDialog.dismiss();
                t.printStackTrace();
                Toast.makeText(getActivity(), call.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

/*
    private void getCRMListnew(String currentpage) {
        if (progressDialog != null) progressDialog.show();
        ApiUtils.getAlterationService().getCRMList("crmapi/sales-lead-list.php", user_id, currentpage).enqueue(new Callback<CRMListResponse>() {
            @Override
            public void onResponse(Call<CRMListResponse> call, Response<CRMListResponse> response) {
                try {
                    if (response.code() == 200) {
                        if (response.body().statusCode == 1) {
                            if (response.body() != null) {
                                respose = response.body();
                                Totalcount = response.body().Totalcount;
                                for (int i = 0; i < response.body().crmListData.size(); i++) {
                                    crmListData_complete.add((CRMListData) response.body().crmListData.get(i));
                                }
//                                adapter = null;
//                                adapter = new MyCustomAdapter(crmListData_complete);// new MyCustomAdapter(SocialAccount.this, response.body().socialdata);
//                                recyclerView.setAdapter(adapter);
                                adapter.notifyDataSetChanged();
                                if (crmListData_complete.size() > 0) {
                                    txt_message.setVisibility(View.GONE);
                                } else {
                                    txt_message.setVisibility(View.VISIBLE);
                                }
                            } else {

                                Toast.makeText(getActivity(), response.body().message, Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(getActivity(), response.body().message, Toast.LENGTH_SHORT).show();
                        }
                    }
                    progressDialog.dismiss();
                } catch (Exception e) {
                    progressDialog.dismiss();
                    e.printStackTrace();
                    Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<CRMListResponse> call, Throwable t) {
                progressDialog.dismiss();
                t.printStackTrace();
                Toast.makeText(getActivity(), call.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }
*/

    public class MyCustomAdapter extends RecyclerView.Adapter<MyCustomAdapter.ItemViewHolder> implements SectionTitleProvider {
        List<CRMListData> list;
        private HashMap<Integer, Boolean> checkBoxStates = new HashMap<>();

        public MyCustomAdapter(List<CRMListData> list) {
            this.list = list;
        }


        @Override
        public MyCustomAdapter.ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

            return new MyCustomAdapter.ItemViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.crm_list_item_new, parent, false));
        }

        public void onBindViewHolder(final MyCustomAdapter.ItemViewHolder holder, final int position) {

            try {

                final CRMListData crmListData = list.get(position);
                holder.txt_name.setText(capitalize(crmListData.company));
                holder.txt_email.setText(crmListData.email);

                if (MainActivity.long_press) {
                    holder.checkBox.setVisibility(View.VISIBLE);
                } else {
                    holder.checkBox.setVisibility(View.GONE);
                }
//                holder.checkBox.setVisibility(checkBoxStates.get(position) != null && !checkBoxStates.get(position) ? View.GONE : View.VISIBLE);
                /*if (position == clickposition) {
//                    Toast.makeText(getActivity(), "click "+clickposition, Toast.LENGTH_SHORT).show();
                    holder.checkBox.setChecked(true);
                } else {
                    holder.checkBox.setChecked(false);
                }*/
                if (MainActivity.checked_id.size() > 0) {
                    if (MainActivity.checked_id.get(position).get(list.get(position).id)) {
//                    Toast.makeText(getActivity(), "click "+clickposition, Toast.LENGTH_SHORT).show();
                        holder.checkBox.setChecked(true);
                    } else {
                        holder.checkBox.setChecked(false);
                    }
                } else {
                    holder.checkBox.setChecked(false);
                }
                if (position > lastPosition) {

                    Animation animation = AnimationUtils.loadAnimation(getActivity(), R.anim.up_from_bottom);
                    holder.itemView.startAnimation(animation);
                    lastPosition = position;
                } else {
                    Animation animation = AnimationUtils.loadAnimation(getActivity(), R.anim.bottom_from_up);
                    holder.itemView.startAnimation(animation);
                    lastPosition = position;
                }
                holder.card_view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                       /* selected_id = userListData.id;
                        name = userListData.name;
                        email = userListData.email;
                        phone = userListData.phone;
                        address = userListData.address;
                        designation = userListData.designation;
                        profile_pic = userListData.profile_image;*/
                        if (MainActivity.long_press) {
                            if (holder.checkBox.isChecked()) {
                                holder.checkBox.setChecked(false);
                                HashMap<String, Boolean> innerHash = new HashMap<String, Boolean>();
                                innerHash.put(crmListData.id, false);
                                MainActivity.checked_id.replace(position, innerHash);
                            } else {
                                holder.checkBox.setChecked(true);
                                HashMap<String, Boolean> innerHash = new HashMap<String, Boolean>();
                                innerHash.put(crmListData.id, true);
                                MainActivity.checked_id.replace(position, innerHash);
                            }


                        } else {
                            Intent in = new Intent(getActivity(), LeadCRMDetails.class);
                            in.putExtra("id", crmListData.id);
                            in.putExtra("currentpage", currentpage);
                            startActivity(in);
                        }

                    }
                });
                holder.card_view.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        MainActivity.long_press = true;
                        rl_assign.setVisibility(View.VISIBLE);
                        ll_pagination.setVisibility(View.GONE);
                        clickposition = list.indexOf(crmListData);
                        HashMap<String, Boolean> innerHash = new HashMap<String, Boolean>();
                        innerHash.put(crmListData.id, true);
                        MainActivity.checked_id.replace(position, innerHash);

//                        holder.checkBox.setVisibility(View.VISIBLE);
                        for (int i = 0; i < list.size(); i++) {
//                            checkBoxStates.put(i, true);
                            notifyItemChanged(i);
                        }

                        return false;
                    }
                });
                holder.checkBox.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        HashMap<String, Boolean> innerHash = new HashMap<String, Boolean>();
                        if (holder.checkBox.isChecked()) {
                            innerHash.put(crmListData.id, true);
                            MainActivity.checked_id.replace(position, innerHash);

//                            holder.checkBox.setChecked(false);
                        } else {
                            innerHash.put(crmListData.id, false);
                            MainActivity.checked_id.replace(position, innerHash);

//                            holder.checkBox.setChecked(true);
                        }
                    }
                });


                // Pagination auto load
               /* if (position == list.size() - 1) {
                    if (Totalcount - 1 > position) {
                        getCRMListnew("2");
                    }
                }*/
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public int getItemCount() {
            return list != null ? list.size() : 0;
        }

        class ItemViewHolder extends RecyclerView.ViewHolder {
            TextView txt_name, txt_email;
            CircleImageView img_profile_image;
            CardView card_view;
            AppCompatCheckBox checkBox;

            public ItemViewHolder(View itemView) {
                super(itemView);
                txt_name = (TextView) itemView.findViewById(R.id.txt_name);
                txt_email = (TextView) itemView.findViewById(R.id.txt_email);
                img_profile_image = (CircleImageView) itemView.findViewById(R.id.img_profile_image);
                card_view = (CardView) itemView.findViewById(R.id.card_view);
                checkBox = (AppCompatCheckBox) itemView.findViewById(R.id.checkBox);
                if (!MainActivity.long_press) {
                    rl_assign.setVisibility(View.GONE);
                    ll_pagination.setVisibility(View.VISIBLE);
                }
            }
        }

        @Override
        public String getSectionTitle(int position) {
            return list.get(position).company.substring(0, 1);
        }
    }

    private String capitalize(String capString) {
        StringBuffer capBuffer = new StringBuffer();
        Matcher capMatcher = Pattern.compile("([a-z])([a-z]*)", Pattern.CASE_INSENSITIVE).matcher(capString);
        while (capMatcher.find()) {
            capMatcher.appendReplacement(capBuffer, capMatcher.group(1).toUpperCase() + capMatcher.group(2).toLowerCase());
        }
        return capMatcher.appendTail(capBuffer).toString();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (deleteLead || updateLead) {
            deleteLead = false;
            updateLead = false;
            MainActivity.unassign_adapter = null;
            getCRMList(currentpage);
        }
    }

    private void enableViews(boolean enable) {

        // To keep states of ActionBar and ActionBarDrawerToggle synchronized,
        // when you enable on one, you disable on the other.
        // And as you may notice, the order for this operation is disable first, then enable - VERY VERY IMPORTANT.
        if (enable) {
            //You may not want to open the drawer on swipe from the left in this case
            MainActivity.drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
            // Remove hamburger
            MainActivity.actionBarDrawerToggle.setDrawerIndicatorEnabled(false);
            // Show back button
            ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            // when DrawerToggle is disabled i.e. setDrawerIndicatorEnabled(false), navigation icon
            // clicks are disabled i.e. the UP button will not work.
            // We need to add a listener, as in below, so DrawerToggle will forward
            // click events to this listener.
            if (!MainActivity.mToolBarNavigationListenerIsRegistered) {
                MainActivity.actionBarDrawerToggle.setToolbarNavigationClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Doesn't have to be onBackPressed
//                        onBackPressed();
                        FragmentManager fm = getFragmentManager();
                        int size = fm.getBackStackEntryCount();
                        if (size == 1) {
                            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());
                            alertDialogBuilder.setTitle("Are you sure,You want to cancel?");
                            alertDialogBuilder.setMessage("All data will be erased.");
                            alertDialogBuilder.setCancelable(false);
                            alertDialogBuilder.setPositiveButton("yes",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface arg0, int arg1) {
                                            Method_execute();
                                        }
                                    });

                            alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                }
                            });

                            AlertDialog alertDialog = alertDialogBuilder.create();
                            alertDialog.show();

                        } else {
                            getFragmentManager().popBackStack();
                        }


                    }
                });

                MainActivity.mToolBarNavigationListenerIsRegistered = true;
            }

        } else {
            //You must regain the power of swipe for the drawer.
            MainActivity.drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);

            // Remove back button
            ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            // Show hamburger
            MainActivity.actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
            // Remove the/any drawer toggle listener
            MainActivity.actionBarDrawerToggle.setToolbarNavigationClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Doesn't have to be onBackPressed
//                        onBackPressed();
                    getFragmentManager().popBackStack();
                }
            });
            MainActivity.mToolBarNavigationListenerIsRegistered = false;
        }
    }

    public void Method_execute() {
        Helper.storeLocally(getActivity(), "number", "");
        Helper.storeLocally(getActivity(), "first_name", "");
        Helper.storeLocally(getActivity(), "last_name", "");
        Helper.storeLocally(getActivity(), "company_name", "");
        Helper.storeLocally(getActivity(), "title", "");
        Helper.storeLocally(getActivity(), "city_name", "");
        Helper.storeLocally(getActivity(), "address", "");
        Helper.storeLocally(getActivity(), "loction_name", "");
        Helper.storeLocally(getActivity(), "state", "");
        Helper.storeLocally(getActivity(), "pincode", "");
        Helper.storeLocally(getActivity(), "phone", "");
        Helper.storeLocally(getActivity(), "mobile", "");
        Helper.storeLocally(getActivity(), "additonal_contact", "");
        Helper.storeLocally(getActivity(), "email", "");
        Helper.storeLocally(getActivity(), "lead_source", "");
        Helper.storeLocally(getActivity(), "no_employee", "");
        Helper.storeLocally(getActivity(), "annual_revenue", "");
        Helper.storeLocally(getActivity(), "industry", "");
        Helper.storeLocally(getActivity(), "lead_owner", "");
        Helper.storeLocally(getActivity(), "sales_person", "");


        Helper.storeLocally(getActivity(), "google_reviews", "");
        Helper.storeLocally(getActivity(), "Just_Dial_Reviews", "");
        Helper.storeLocally(getActivity(), "facebook_reviews", "");
        Helper.storeLocally(getActivity(), "Other_Social_Channel_Reviews", "");
        Helper.storeLocally(getActivity(), "Fb_likes", "");
        Helper.storeLocally(getActivity(), "FB_Followers", "");
        Helper.storeLocally(getActivity(), "Response_Rate", "");
        Helper.storeLocally(getActivity(), "Engagement_Rate", "");
        Helper.storeLocally(getActivity(), "Linkedin_Followers", "");

        Helper.storeLocally(getActivity(), "Website", "");
        Helper.storeLocally(getActivity(), "Website_Technology", "");
        Helper.storeLocally(getActivity(), "Website_information", "");
        Helper.storeLocally(getActivity(), "Website_Type", "");
        Helper.storeLocally(getActivity(), "Overlook_and_Feels", "");
        Helper.storeLocally(getActivity(), "Website_Language", "");
        Helper.storeLocally(getActivity(), "Content_Quality", "");
        Helper.storeLocally(getActivity(), "Graphic_Quality", "");
        Helper.storeLocally(getActivity(), "Global_Rank", "");
        Helper.storeLocally(getActivity(), "total_score", "");


        Helper.storeLocally(getActivity(), "Ranking_Keyword_1", "");
        Helper.storeLocally(getActivity(), "Global_Rank_Keyword_1", "");
        Helper.storeLocally(getActivity(), "Ranking_Keyword_2", "");
        Helper.storeLocally(getActivity(), "Global_Rank_Keyword_2", "");
        Helper.storeLocally(getActivity(), "Ranking_Keyword_3", "");
        Helper.storeLocally(getActivity(), "Global_Rank_Keyword_3", "");
        Helper.storeLocally(getActivity(), "Ranking_Keyword_4", "");
        Helper.storeLocally(getActivity(), "Global_Rank_Keyword_4", "");
        Helper.storeLocally(getActivity(), "Ranking_Keyword_5", "");
        Helper.storeLocally(getActivity(), "Global_Rank_Keyword_5", "");
        Helper.storeLocally(getActivity(), "Ranking_Keyword_6", "");
        Helper.storeLocally(getActivity(), "Global_Rank_Keyword_6", "");
        Helper.storeLocally(getActivity(), "Ranking_Keyword_7", "");
        Helper.storeLocally(getActivity(), "Global_Rank_Keyword_7", "");


        Helper.storeLocally(getActivity(), "First_Actions", "");
        Helper.storeLocally(getActivity(), "First_Action_Remarks", "");
        Helper.storeLocally(getActivity(), "Second_Actions", "");
        Helper.storeLocally(getActivity(), "Second_Action_Remarks", "");
        Helper.storeLocally(getActivity(), "Third_Actions", "");
        Helper.storeLocally(getActivity(), "Third_Action_Remarks", "");
        Helper.storeLocally(getActivity(), "Fourth_Actions", "");
        Helper.storeLocally(getActivity(), "Fouth_Action_Remarks", "");
        Helper.storeLocally(getActivity(), "Fifth_Actions", "");
        Helper.storeLocally(getActivity(), "Fifth_Action_Remarks", "");
        Helper.storeLocally(getActivity(), "Final_Actions", "");
        Helper.storeLocally(getActivity(), "Final_Action_Remarks", "");

        Helper.storeLocally(getActivity(), "Proposal_Sent_For", "");
        Helper.storeLocally(getActivity(), "Proposal_Sent_On", "");
        Helper.storeLocally(getActivity(), "Total_value", "");
        Helper.storeLocally(getActivity(), "Expected_Closure_Date", "");
        Helper.storeLocally(getActivity(), "Proposal_not_sent_for", "");
        Helper.storeLocally(getActivity(), "Reason", "");
        Helper.storeLocally(getActivity(), "Status", "");


        getFragmentManager().popBackStack();
        enableViews(false);
    }

    public void ok(Activity activity) {
        for (int i = 0; i < respose.crmListData.size(); i++) {
            HashMap<String, Boolean> innerHash = new HashMap<String, Boolean>();
            innerHash.put(respose.crmListData.get(i).id, false);
            MainActivity.checked_id.put(i, innerHash);
        }
        MainActivity.unassign_adapter.notifyDataSetChanged();
    }

    class UserRoleAdapter extends BaseAdapter {

        LayoutInflater inflater;
        List<UserListData> list;
        int selectedPosition = 0;

        public UserRoleAdapter(FragmentActivity fragmentActivity, List<UserListData> list) {
            inflater = LayoutInflater.from(fragmentActivity);
            this.list = list;
        }

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int paramInt) {
            return paramInt;
        }

        class ViewHolder {
            TextView txt_role;
            RadioButton btn_radio;
        }

        @Override
        public long getItemId(int paramInt) {
            return paramInt;
        }

        @Override
        public View getView(final int paramInt, View itemView, ViewGroup paramViewGroup) {

            UserRoleAdapter.ViewHolder holder;
            if (itemView == null) {
                itemView = inflater.inflate(R.layout.user_role_list_selected, paramViewGroup, false);
                holder = new UserRoleAdapter.ViewHolder();

                holder.txt_role = (TextView) itemView.findViewById(R.id.txt_role);
                holder.btn_radio = (RadioButton) itemView.findViewById(R.id.btn_radio);

                itemView.setTag(holder);
            } else {
                holder = (UserRoleAdapter.ViewHolder) itemView.getTag();
            }
            final UserListData roleData = list.get(paramInt);
            holder.txt_role.setText(capitalize(roleData.name));

            holder.txt_role.setTag(paramInt);
            holder.txt_role.setOnClickListener(new View.OnClickListener() {

                @SuppressWarnings("deprecation")
                @Override
                public void onClick(View vv) {
                    // TODO Auto-generated method stub
                    int pos1 = (Integer) vv.getTag();
                    UserListData roleData = list.get(pos1);
                    String selected_user_id = roleData.id;
                    txt_assign.setText(roleData.name);
//                    pw_user.dismiss();
                }
            });
            holder.btn_radio.setChecked(paramInt == selectedPosition);
            holder.btn_radio.setTag(paramInt);
            holder.btn_radio.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    selectedPosition = (Integer) view.getTag();
                    assigntoId = roleData.id;
                    notifyDataSetChanged();

                }
            });

            return itemView;
        }
    }

    private void assign() {
        ArrayList<String> aList = new ArrayList<String>();
        for (int i = 0; i < MainActivity.checked_id.size(); i++) {
            if (MainActivity.checked_id.get(i).get(respose.crmListData.get(i).id)) {
                aList.add(respose.crmListData.get(i).id);
            }

        }
        StringBuilder sb = new StringBuilder();
        for (String s : aList) {
            sb.append(s);
            sb.append(",");
        }

        if (progressDialog != null) progressDialog.show();
        ApiUtils.getAlterationService().assign_to("leads-assign", Helper.getLocalValue(getActivity(), "user_id"), assigntoId, sb.toString(),"").enqueue(new Callback<CRMListResponse>() {
            @Override
            public void onResponse(Call<CRMListResponse> call, Response<CRMListResponse> response) {
                try {
                    if (response.code() == 200) {
                        if (response.body().statusCode == 1) {
                            if (response.body() != null) {

                            } else {

                                Toast.makeText(getActivity(), response.body().message, Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(getActivity(), response.body().message, Toast.LENGTH_SHORT).show();
                        }
                    }
                    progressDialog.dismiss();
                } catch (Exception e) {
                    progressDialog.dismiss();
                    e.printStackTrace();
                    Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<CRMListResponse> call, Throwable t) {
                progressDialog.dismiss();
                t.printStackTrace();
                Toast.makeText(getActivity(), call.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }


}