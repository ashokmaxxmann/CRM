package co.in.location.deals;

import android.os.Bundle;
import android.support.percent.PercentRelativeLayout;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import co.in.location.R;
import co.in.location.response.CRMListResponse;

public class Address_Tab extends Fragment {
    TextView txt_billing_street, txt_billing_city, txt_billing_state, txt_billing_zip, txt_billing_country, txt_shipping_street, txt_shipping_city, txt_shipping_state, txt_shipping_zip, txt_shipping_country;
    PercentRelativeLayout prl40, prl41, prl42, prl43, prl44, prl45, prl46, prl47, prl48, prl49;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.deals_address, container, false);
        txt_billing_street = (TextView) view.findViewById(R.id.txt_billing_street);
        txt_billing_city = (TextView) view.findViewById(R.id.txt_billing_city);
        txt_billing_state = (TextView) view.findViewById(R.id.txt_billing_state);
        txt_billing_zip = (TextView) view.findViewById(R.id.txt_billing_zip);
        txt_billing_country = (TextView) view.findViewById(R.id.txt_billing_country);
        txt_shipping_street = (TextView) view.findViewById(R.id.txt_shipping_street);
        txt_shipping_city = (TextView) view.findViewById(R.id.txt_shipping_city);
        txt_shipping_state = (TextView) view.findViewById(R.id.txt_shipping_state);
        txt_shipping_zip = (TextView) view.findViewById(R.id.txt_shipping_zip);
        txt_shipping_country = (TextView) view.findViewById(R.id.txt_shipping_country);


        prl40 = (PercentRelativeLayout) view.findViewById(R.id.prl40);
        prl41 = (PercentRelativeLayout) view.findViewById(R.id.prl41);
        prl42 = (PercentRelativeLayout) view.findViewById(R.id.prl42);
        prl43 = (PercentRelativeLayout) view.findViewById(R.id.prl43);
        prl44 = (PercentRelativeLayout) view.findViewById(R.id.prl44);
        prl45 = (PercentRelativeLayout) view.findViewById(R.id.prl45);
        prl46 = (PercentRelativeLayout) view.findViewById(R.id.prl46);
        prl47 = (PercentRelativeLayout) view.findViewById(R.id.prl47);
        prl48 = (PercentRelativeLayout) view.findViewById(R.id.prl48);
        prl49 = (PercentRelativeLayout) view.findViewById(R.id.prl49);


//        id = getIntent().getStringExtra("id");
//        currentpage = getIntent().getIntExtra("currentpage", 0);
//        txt_mobile.setOnClickListener(this);
//        getDetails();
//        dealCRMDetails = this;
        executeMethode();
        return view;
    }
    public void executeMethode() {

        txt_billing_street.setText(DealsDetails.respose.crmListData.get(0).Ranking_Keyword_1);
        txt_billing_city.setText(DealsDetails.respose.crmListData.get(0).Global_Rank_Keyword_1);
        txt_billing_state.setText(DealsDetails.respose.crmListData.get(0).Ranking_Keyword_2);
        txt_billing_zip.setText(DealsDetails.respose.crmListData.get(0).Global_Rank_Keyword_2);
        txt_billing_country.setText(DealsDetails.respose.crmListData.get(0).Ranking_Keyword_3);
        txt_shipping_street.setText(DealsDetails.respose.crmListData.get(0).Global_Rank_Keyword_3);
        txt_shipping_city.setText(DealsDetails.respose.crmListData.get(0).Ranking_Keyword_4);
        txt_shipping_state.setText(DealsDetails.respose.crmListData.get(0).Global_Rank_Keyword_4);
        txt_shipping_zip.setText(DealsDetails.respose.crmListData.get(0).Ranking_Keyword_5);
        txt_shipping_country.setText(DealsDetails.respose.crmListData.get(0).Global_Rank_Keyword_5);
    }

}
