package co.in.location.admin;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AppCompatDelegate;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import co.in.location.R;

public class UserDetailsActivity extends AppCompatActivity {
    String Designation, Department, Designation_id, Department_id, user_id, name, email, personal_number, address, image_path;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        setContentView(R.layout.user_details_activity);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getUserDetails();
    }

    private void getUserDetails() {
        Intent in = getIntent();
        user_id = in.getStringExtra("user_id");
        name = in.getStringExtra("name");
        email = in.getStringExtra("email");
        personal_number = in.getStringExtra("personal_number");
        address = in.getStringExtra("address");
        Designation = in.getStringExtra("designation");
        Department = in.getStringExtra("departments");
        Designation_id = in.getStringExtra("designation_id");
        Department_id = in.getStringExtra("departments_id");
        image_path = in.getStringExtra("image_path");

        Fragment fragment = new UserDetailsFragment();
        Bundle bundle = new Bundle();
        bundle.putString("user_id", user_id);
        bundle.putString("name", name);
        bundle.putString("email", email);
        bundle.putString("personal_number", personal_number);
        bundle.putString("address", address);
        bundle.putString("Designation", Designation);
        bundle.putString("Department", Department);
        bundle.putString("Designation_id", Designation_id);
        bundle.putString("Department_id", Department_id);
        bundle.putString("image_path", image_path);
        fragment.setArguments(bundle);
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.frame, fragment);
        ft.commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.edit_menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        menu.getItem(0).setVisible(true);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // todo: goto back activity from here
                UserDetailsActivity.this.finish();
                return true;
            case R.id.edit_menu:
                Intent in = new Intent(UserDetailsActivity.this, Edit_Account.class);
                in.putExtra("user_id", user_id);
                in.putExtra("name", name);
                in.putExtra("email", email);
                in.putExtra("personal_number", personal_number);
                in.putExtra("address", address);
                in.putExtra("designation", Designation);
                in.putExtra("departments", Department);
                in.putExtra("designation_id", Designation_id);
                in.putExtra("departments_id", Department_id);
                in.putExtra("image_path", image_path);
                startActivity(in);
                return true;
            default:
                break;
        }
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (UserList.update_user_profile) {
            UserDetailsActivity.this.finish();
        }
    }
}
