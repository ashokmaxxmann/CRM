package co.in.location.admin;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import co.in.location.R;
import co.in.location.Remote.ApiUtils;
import co.in.location.UserTravelRoute;
import co.in.location.data.LocationData;
import co.in.location.response.Location_history_Response;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LocationHistory extends AppCompatActivity implements View.OnClickListener {
    RecyclerView recyclerView;
    String user_id;
    ImageView img_back, img_calendar, img_back_arrow, img_next_arrow;
    TextView txt_message, txt_calendar, txt_route;
    MyCustomAdapter adapter;
    private int mYear, mMonth, mDay;
    public List<LocationData> locationData_datewise = new ArrayList<LocationData>();
    public static Location_history_Response history_response;
    int date_position = 0;
    int start_position = 0;
    boolean match = false;
    RelativeLayout rl_calender;
    SimpleDateFormat sdf, sdf2, sdf1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_history);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        recyclerView = (RecyclerView) findViewById(R.id.location_history_list);
        txt_message = (TextView) findViewById(R.id.txt_message);
        txt_calendar = (TextView) findViewById(R.id.txt_calendar);
        txt_route = (TextView) findViewById(R.id.txt_route);
        recyclerView.setLayoutManager(new LinearLayoutManager(LocationHistory.this));
        recyclerView.setNestedScrollingEnabled(true);
        img_back = (ImageView) findViewById(R.id.img_back);
        img_calendar = (ImageView) findViewById(R.id.img_calendar);
        img_back_arrow = (ImageView) findViewById(R.id.img_back_arrow);
        img_next_arrow = (ImageView) findViewById(R.id.img_next_arrow);
        rl_calender = (RelativeLayout) findViewById(R.id.rl_calender);
        img_back.setOnClickListener(this);
        img_calendar.setOnClickListener(this);
        img_back_arrow.setOnClickListener(this);
        img_next_arrow.setOnClickListener(this);
        txt_calendar.setOnClickListener(this);
        txt_route.setOnClickListener(this);
        user_id = getIntent().getStringExtra("user_id");
        getlocation_history();
        Calendar c = Calendar.getInstance();
        sdf = new SimpleDateFormat("dd-MM-yyyy");
        sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        sdf1 = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
//        txt_calendar.setText(sdf.format(c.getTime()));
        txt_route.setVisibility(View.GONE);
    }

    @Override
    public void onClick(View v) {
        String dt;
        Calendar c;
        switch (v.getId()) {
            case R.id.img_back:
                LocationHistory.this.finish();
                break;
            case R.id.txt_calendar:
                date();
                break;
            case R.id.txt_route:
                Intent in = new Intent(LocationHistory.this, UserTravelRoute.class);
                startActivity(in);

                break;
            case R.id.img_calendar:
                date();
                break;
            case R.id.img_back_arrow:
                date_position = 0;
                try {
                    for (int j = 0; j < history_response.locationData.size(); j++) {
                        Date date1 = sdf.parse(txt_calendar.getText().toString());//2018-06-09 12:12:24
//                        Date date2 = sdf.format(sdf2.parse(history_response.locationData.get(j).date));

                        Date date2 = (sdf.parse(sdf.format(sdf2.parse(history_response.locationData.get(j).date))));

                        if (date1.compareTo(date2) == 0) {
                            match = true;
                            date_position--;
                        } else {
                            if (match) {
                                date_position = j;
                                match = false;
                                break;
                            }
                        }
                    }
                    if (date_position > 0) {
                        dt = txt_calendar.getText().toString();  // Start date
                        c = Calendar.getInstance();
                        try {
                            c.setTime(sdf.parse(dt));
                            locationData_datewise.clear();
                            for (int i = 0; i < history_response.locationData.size(); i++) {
                                Date date1 = (sdf.parse(sdf.format(sdf2.parse(history_response.locationData.get(date_position).date))));//2018-06-09 12:12:24
                                Date date2 = (sdf.parse(sdf.format(sdf2.parse(history_response.locationData.get(i).date))));

                                if (date1.compareTo(date2) == 0) {
                                    locationData_datewise.add(history_response.locationData.get(i));
                                }
                            }

                            adapter = new MyCustomAdapter(locationData_datewise);// new MyCustomAdapter(SocialAccount.this, response.body().socialdata);
                            recyclerView.setAdapter(adapter);
                            txt_calendar.setText(sdf.format(sdf2.parse(locationData_datewise.get(0).date)));

                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        c.add(Calendar.DATE, -1);  // number of days to add, can also use Calendar.DAY_OF_MONTH in place of Calendar.DATE

                    } else {
                        Toast.makeText(LocationHistory.this, "No record exist on previous date", Toast.LENGTH_SHORT).show();
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }


                break;
            case R.id.img_next_arrow:
                date_position = 0;
                match = false;
                try {
                    for (int j = 0; j < history_response.locationData.size(); j++) {
                        Date date1 = sdf.parse(txt_calendar.getText().toString());//2018-06-09 12:12:24
                        Date date2 = (sdf.parse(sdf.format(sdf2.parse(history_response.locationData.get(j).date))));
                        if (date1.compareTo(date2) == 0) {
                            date_position = j - 1;
                            break;
                        }
                        /*if (date1.compareTo(date2) == 0) {
                            match = true;
                            date_position--;
                        } else {
                            if (match) {
                                date_position = j;
                                match = false;
                                break;
                            }
                        }*/

                    }
                    if (date_position > 0) {
                        dt = txt_calendar.getText().toString();  // Start date
                        c = Calendar.getInstance();
                        try {
                            c.setTime(sdf.parse(dt));

                            locationData_datewise.clear();
                            for (int i = 0; i < history_response.locationData.size(); i++) {
//                            Date date1 = sdf.parse(history_response.locationData.get(date_position).date);//2018-06-09 12:12:24
//                            Date date2 = sdf.parse(history_response.locationData.get(i).date);

                                Date date1 = (sdf.parse(sdf.format(sdf2.parse(history_response.locationData.get(date_position).date))));//2018-06-09 12:12:24
                                Date date2 = (sdf.parse(sdf.format(sdf2.parse(history_response.locationData.get(i).date))));


                                if (date1.compareTo(date2) == 0) {
                                    locationData_datewise.add(history_response.locationData.get(i));
                                }
                            }

                            adapter = new MyCustomAdapter(locationData_datewise);// new MyCustomAdapter(SocialAccount.this, response.body().socialdata);
                            recyclerView.setAdapter(adapter);
                            txt_calendar.setText(sdf.format(sdf2.parse(locationData_datewise.get(0).date)));

                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        c.add(Calendar.DATE, 1);  // number of days to add, can also use Calendar.DAY_OF_MONTH in place of Calendar.DATE

                    } else {
                        date_position = start_position;
                        Toast.makeText(LocationHistory.this, "No record exist on next date", Toast.LENGTH_SHORT).show();
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                break;
        }
    }

    public void date() {
        long timeInMilliseconds = 0;
        String date = txt_calendar.getText().toString();
        mYear = Integer.parseInt(date.substring(6, 10));
        mMonth = Integer.parseInt(date.substring(3, 5));
        mDay = Integer.parseInt(date.substring(0, 2));

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, mYear);
        calendar.set(Calendar.MONTH, mMonth);
        calendar.set(Calendar.DAY_OF_YEAR, mDay);


        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                String dt;
                dt = ((dayOfMonth) < 10 ? ("0" + (dayOfMonth)) : (dayOfMonth)) + "-" + ((monthOfYear + 1) < 10 ? ("0" + (monthOfYear + 1)) : (monthOfYear + 1)) + "-" + year;  // Start date
                try {
                    locationData_datewise.clear();
                    for (int i = 0; i < history_response.locationData.size(); i++) {
                        Date date1 = sdf.parse(dt);//2018-06-09 12:12:24
                        Date date2 = (sdf.parse(sdf.format(sdf2.parse(history_response.locationData.get(i).date))));
                        if (date1.compareTo(date2) == 0) {
                            locationData_datewise.add(history_response.locationData.get(i));
                        }
                    }
                    if (locationData_datewise.size() > 0) {
                        txt_calendar.setText(((dayOfMonth) < 10 ? ("0" + (dayOfMonth)) : (dayOfMonth)) + "-" + ((monthOfYear + 1) < 10 ? ("0" + (monthOfYear + 1)) : (monthOfYear + 1)) + "-" + year);

                        adapter = new MyCustomAdapter(locationData_datewise);// new MyCustomAdapter(SocialAccount.this, response.body().socialdata);
                        recyclerView.setAdapter(adapter);

                    } else {
                        Toast.makeText(LocationHistory.this, "No record exist on this date", Toast.LENGTH_SHORT).show();
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        }, mYear, mMonth, mDay);
        try {
//            Date mDate = sdf.parse(history_response.locationData.get(history_response.locationData.size() - 1).date);
            Date mDate = (sdf.parse(sdf.format(sdf2.parse(history_response.locationData.get(history_response.locationData.size() - 1).date))));
            timeInMilliseconds = mDate.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        datePickerDialog.updateDate(mYear, mMonth - 1, mDay);


        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        datePickerDialog.getDatePicker().setMinDate(timeInMilliseconds);
        datePickerDialog.show();
    }

    private void getlocation_history() {
        ApiUtils.getAlterationService().getLocationHistory("location_history", user_id).enqueue(new Callback<Location_history_Response>() {
            @Override
            public void onResponse(Call<Location_history_Response> call, Response<Location_history_Response> response) {
                try {
                    if (response.code() == 200) {
                        if (response.body().statusCode == 1) {
                            if (response.body() != null) {

                                adapter = null;
                                Collections.reverse(response.body().locationData);
                                history_response = response.body();
                                if (response.body().locationData.size() > 0) {
                                    txt_message.setVisibility(View.GONE);
                                    rl_calender.setVisibility(View.VISIBLE);

                                    txt_calendar.setText(sdf.format(sdf2.parse(response.body().locationData.get(0).date)));
                                } else {
                                    txt_message.setVisibility(View.VISIBLE);
                                    rl_calender.setVisibility(View.GONE);
                                }


                                locationData_datewise.clear();
                                for (int i = 0; i < response.body().locationData.size(); i++) {
                                    Date date1 = (sdf.parse(sdf.format(sdf2.parse(response.body().locationData.get(0).date))));//2018-06-09 12:12:24
                                    Date date2 = (sdf.parse(sdf.format(sdf2.parse(response.body().locationData.get(i).date))));
                                    if (date1.compareTo(date2) == 0) {
                                        locationData_datewise.add(response.body().locationData.get(i));
                                        date_position++;
                                        start_position++;

                                    }
                                }

                                adapter = new MyCustomAdapter(locationData_datewise);// new MyCustomAdapter(SocialAccount.this, response.body().socialdata);
                                recyclerView.setAdapter(adapter);
                                if (locationData_datewise.size() > 0) {
                                    txt_message.setVisibility(View.GONE);
                                    rl_calender.setVisibility(View.VISIBLE);
                                } else {
                                    txt_message.setVisibility(View.VISIBLE);
                                    rl_calender.setVisibility(View.GONE);
                                }
                            } else {
                                Toast.makeText(LocationHistory.this, response.body().message, Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(LocationHistory.this, response.body().message, Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(LocationHistory.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Location_history_Response> call, Throwable t) {
                t.printStackTrace();
                Toast.makeText(LocationHistory.this, call.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public class MyCustomAdapter extends RecyclerView.Adapter<MyCustomAdapter.ItemViewHolder> {

        List<LocationData> list;

        public MyCustomAdapter(List<LocationData> list) {
            this.list = list;
        }


        @Override
        public MyCustomAdapter.ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

            return new MyCustomAdapter.ItemViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.location_history_list_item, parent, false));
        }

        public void onBindViewHolder(final MyCustomAdapter.ItemViewHolder holder, final int position) {

            try {

                final LocationData locationData = list.get(position);
//                holder.txt_time.setText(locationData.date);
                holder.txt_time.setText(sdf1.format(sdf2.parse(locationData.date)));
                holder.txt_address.setText(locationData.location);
                String image_path = "http://maps.google.com/maps/api/staticmap?center=" + locationData.latitude + "," + locationData.longitude + "&zoom=18&size=800x400&sensor=false&markers=" + locationData.latitude + "," + locationData.longitude;
                Picasso.with(LocationHistory.this).load(image_path).networkPolicy(NetworkPolicy.NO_CACHE).into(holder.img_map);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public int getItemCount() {
            return list != null ? list.size() : 0;
        }

        class ItemViewHolder extends RecyclerView.ViewHolder {
            TextView txt_time, txt_address;
            ImageView img_map;

            public ItemViewHolder(View itemView) {
                super(itemView);
                txt_time = (TextView) itemView.findViewById(R.id.txt_time);
                txt_address = (TextView) itemView.findViewById(R.id.txt_address);
                img_map = (ImageView) itemView.findViewById(R.id.img_map);
            }
        }
    }
}
