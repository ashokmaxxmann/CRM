package co.in.location;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatDialog;
import android.support.v7.widget.AppCompatCheckBox;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import co.in.location.Remote.ApiUtils;
import co.in.location.response.LoginResponse;
import co.in.location.service.MyIntentService;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Login extends AppCompatActivity implements View.OnClickListener {
    TextView txt_login, txt_forgotpass, prog_message, txt_create_account;
    EditText edt_email, edt_pass;
    AppCompatDialog progressDialog;
    AppCompatCheckBox checkBox;
    boolean remember = true;
    boolean pass_view = false;
    boolean doubleBackToExitPressedOnce = false;

    /*  private RadioGroup radioGroup;
      private RadioButton rb_admin, rb_employee;
      String type = "employee";*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        txt_login = (TextView) findViewById(R.id.txt_login);
        txt_forgotpass = (TextView) findViewById(R.id.txt_forgot);
        txt_create_account = (TextView) findViewById(R.id.txt_create_account);
        edt_email = (EditText) findViewById(R.id.edt_email);
        edt_pass = (EditText) findViewById(R.id.edt_pass);
        checkBox = (AppCompatCheckBox) findViewById(R.id.checkBox);
        boolean result = Utility.checkPermission(Login.this);
        /*radioGroup = (RadioGroup) findViewById(R.id.radiogroup);
        rb_admin = (RadioButton) findViewById(R.id.rb_admin);
        rb_employee = (RadioButton) findViewById(R.id.rb_employee);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                int pos = radioGroup.indexOfChild(findViewById(checkedId));

                //Method 2
                int pos1 = radioGroup.indexOfChild(findViewById(radioGroup.getCheckedRadioButtonId()));

                switch (pos) {
                    case 0:
                        rb_admin.setChecked(true);
                        type = "admin";
                        break;
                    case 1:
                        type = "employee";
                        rb_employee.setChecked(true);
                        break;
                }
            }

        });*/

        edt_email.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (edt_email.getText().toString().equalsIgnoreCase("")) {
                        edt_email.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                    } else if (!edt_email.getText().toString().equalsIgnoreCase("")) {
                        edt_email.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.button)));
                    }
                } else {
                    if (edt_email.getText().toString().equalsIgnoreCase("")) {
                        edt_email.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.placeholder)));
                    } else if (!edt_email.getText().toString().equalsIgnoreCase("")) {
                        edt_email.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                    }
                }
            }
        });

        edt_email.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!edt_email.getText().toString().equalsIgnoreCase("")) {
                    edt_email.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.button)));
                } else {
                    edt_email.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                }
            }
        });
        edt_pass.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (edt_pass.getText().toString().equalsIgnoreCase("")) {
                        edt_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                        edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_white, 0);
                    } else if (!edt_pass.getText().toString().equalsIgnoreCase("")) {
                        edt_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.button)));
                        if (pass_view) {
                            edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_hide, 0);
                        } else {
                            edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_view, 0);
                        }
                    }
                } else {
                    if (edt_pass.getText().toString().equalsIgnoreCase("")) {
                        edt_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.placeholder)));
                        edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_white, 0);
                    } else if (!edt_pass.getText().toString().equalsIgnoreCase("")) {
                        edt_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                        if (pass_view) {
                            edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_hide, 0);
                        } else {
                            edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_view, 0);
                        }
                    }
                }
            }
        });

        edt_pass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!edt_pass.getText().toString().equalsIgnoreCase("")) {
                    edt_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.button)));
                    if (pass_view) {
                        edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_hide, 0);
                    } else {
                        edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_view, 0);
                    }
                } else {
                    edt_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                    edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_white, 0);
                }
            }
        });

        edt_pass.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                final int DRAWABLE_LEFT = 0;
                final int DRAWABLE_TOP = 1;
                final int DRAWABLE_RIGHT = 2;
                final int DRAWABLE_BOTTOM = 3;

                if (event.getAction() == MotionEvent.ACTION_UP) {
                    if (event.getRawX() >= (edt_pass.getRight() - edt_pass.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {
                        if (pass_view) {
                            pass_view = false;
                            edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_hide, 0);
                            edt_pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                        } else {
                            pass_view = true;
                            edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_view, 0);
                            edt_pass.setInputType(InputType.TYPE_CLASS_TEXT);
                        }
                        return true;
                    }
                }
                return false;
            }
        });

        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    remember = true;
                } else {
                    remember = false;
                }
            }
        });
        txt_login.setOnClickListener(this);
        txt_forgotpass.setOnClickListener(this);
        txt_create_account.setOnClickListener(this);

        progressDialog = new AppCompatDialog(Login.this);
        progressDialog.setCancelable(false);
        progressDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progressDialog.setContentView(R.layout.progress_loading);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        prog_message = progressDialog.findViewById(R.id.tv_progress_message);
        prog_message.setText("Please wait..");
        GifImageView gifImageView = (GifImageView) progressDialog.findViewById(R.id.GifImageView);
        gifImageView.setGifImageResource(R.drawable.loadinggif);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.txt_create_account:
                Intent intent = new Intent(Login.this, Register.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                overridePendingTransition(R.anim.slide_in_top, R.anim.stay);
                startActivity(intent);
                break;
            case R.id.txt_login:
                if (validation()) {
                    if (MyApp.getInstance().isConnectingToInternet()) {
                        login_request();

                    } else {
                        Toast.makeText(Login.this, "No internet connection available.", Toast.LENGTH_LONG).show();
                    }
                }
                break;
            case R.id.txt_forgot:
                final Dialog dialog1 = new Dialog(Login.this);
                dialog1.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog1.setContentView(R.layout.custom_alert);
                dialog1.setCancelable(false);
                Button btn_submit = (Button) dialog1.findViewById(R.id.btn_submit);
                Button btn_cancel = (Button) dialog1.findViewById(R.id.btn_cancel);
                final EditText edt_email = (EditText) dialog1.findViewById(R.id.edt_email);
                final TextView txt_message = (TextView) dialog1.findViewById(R.id.txt_message);
                btn_submit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (MyApp.getInstance().isConnectingToInternet()) {
                            if (!TextUtils.isEmpty(edt_email.getText().toString()) && (Patterns.EMAIL_ADDRESS.matcher(edt_email.getText().toString()).matches())) {
                                dialog1.dismiss();
                                txt_message.setVisibility(View.GONE);
//                                forget_pass_request(edt_email.getText().toString());
                            } else {
                                txt_message.setVisibility(View.VISIBLE);
                            }
                        } else {
                            Toast.makeText(Login.this, "No internet connection available.", Toast.LENGTH_LONG).show();
                        }
                    }
                });
                btn_cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog1.dismiss();

                    }
                });
                edt_email.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        txt_message.setVisibility(View.GONE);
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }

                    @Override
                    public void afterTextChanged(Editable s) {

                    }
                });
                dialog1.show();
                break;
        }

    }

    public boolean validation() {
        if ((TextUtils.isEmpty(edt_email.getText().toString())) || (!Patterns.EMAIL_ADDRESS.matcher(edt_email.getText().toString()).matches())) {
            edt_email.requestFocus();
            edt_email.setError("Please fill correct email");
            return false;
        }
        if ((TextUtils.isEmpty(edt_pass.getText().toString())) || (edt_pass.getText().toString().length() < 6)) {
            edt_pass.requestFocus();
            edt_pass.setError("Please fill correct password");
            return false;
        }
        return true;
    }

    private void login_request() {
        InputMethodManager inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        if (progressDialog != null) progressDialog.show();
        ApiUtils.getAlterationService().login("login", edt_email.getText().toString(), edt_pass.getText().toString()).enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                try {
                    if (response.code() == 200) {
                        if (response.body().statusCode == 1) {
                            Intent in = new Intent(Login.this, MainActivity.class);
                            in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            overridePendingTransition(R.anim.slide_in_top, R.anim.stay);
                            startActivity(in);

                            if (remember) {
                                Helper.storeLocally(Login.this, "user_id", response.body().loginData.userId);
                                Helper.storeLocally(Login.this, "user_name", response.body().loginData.name);
                                Helper.storeLocally(Login.this, "user_email", response.body().loginData.email);
                                Helper.storeLocally(Login.this, "user_phone", response.body().loginData.personal_number);
                                Helper.storeLocally(Login.this, "user_designation", response.body().loginData.designation);
                                Helper.storeLocally(Login.this, "user_department", response.body().loginData.department);
                                Helper.storeLocally(Login.this, "user_designation_id", response.body().loginData.designation_id);
                                Helper.storeLocally(Login.this, "user_department_id", response.body().loginData.department_id);
                                Helper.storeLocally(Login.this, "user_pic", response.body().loginData.image_path);
                                Helper.storeLocally(Login.this, "user_address", response.body().loginData.address);
                            }
                            if (!Helper.getLocalValue(getApplicationContext(), "user_designation").equalsIgnoreCase("admin")) {
                                start_Service();
                            }
                        } else {
                            Toast.makeText(Login.this, response.body().message, Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(Login.this, response.body().message, Toast.LENGTH_SHORT).show();
                    }
                    progressDialog.dismiss();
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(Login.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                t.printStackTrace();

                Toast.makeText(Login.this, call.toString(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        });
    }

/*
    private void employee_login_request() {
        InputMethodManager inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        if (progressDialog != null) progressDialog.show();
        ApiUtils.getAlterationService().login_post("user_login.php", edt_email.getText().toString(), edt_pass.getText().toString()).enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                try {
                    if (response.code() == 200) {
                        if (response.body().statusCode == 1) {
                            Intent in = new Intent(Login.this, MainActivity.class);
                            in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            overridePendingTransition(R.anim.slide_in_top, R.anim.stay);
                            startActivity(in);

                            if (remember) {
                                if(!Helper.getLocalValue(getApplicationContext(), "user_designation") .equalsIgnoreCase("admin"))
                                {
                                    start_Service();
                                }
                                Helper.storeLocally(Login.this, "user_id", response.body().loginData.get(0).userId);
                                Helper.storeLocally(Login.this, "admin_id", response.body().loginData.get(0).admin_id);
                                Helper.storeLocally(Login.this, "user_name", response.body().loginData.get(0).name);
                                Helper.storeLocally(Login.this, "user_email", response.body().loginData.get(0).email);
                                Helper.storeLocally(Login.this, "user_phone", response.body().loginData.get(0).phone);
                                Helper.storeLocally(Login.this, "user_designation", response.body().loginData.get(0).designation);
                                Helper.storeLocally(Login.this, "user_pic", response.body().loginData.get(0).profile_image);
                                Helper.storeLocally(Login.this, "user_address", response.body().loginData.get(0).address);
                            }
                        } else if (response.body().statusCode == 2) {
                            listDialog = new Dialog(Login.this);
                            listDialog.setTitle("Select Item");
                            LayoutInflater li = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                            View v = li.inflate(R.layout.admin_list, null, false);
                            listDialog.setContentView(v);
                            listDialog.setCancelable(true);
                            //there are a lot of settings, for dialog, check them all out!

                            RecyclerView list1 = (RecyclerView) listDialog.findViewById(R.id.admin_listview);
                            list1.setLayoutManager(new LinearLayoutManager(Login.this));
                            list1.setNestedScrollingEnabled(true);

                            list1.setAdapter(new MyCustomAdapter(response.body().loginData));
                            //now that the dialog is set up, it's time to show it
                            listDialog.show();
                        } else {
                            Toast.makeText(Login.this, response.body().message, Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(Login.this, response.body().message, Toast.LENGTH_SHORT).show();
                    }
                    progressDialog.dismiss();
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(Login.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                t.printStackTrace();
                Toast.makeText(Login.this, call.toString(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        });
    }
*/

/*
    public class MyCustomAdapter extends RecyclerView.Adapter<MyCustomAdapter.ItemViewHolder> {

        List<LoginData> list;

        public MyCustomAdapter(List<LoginData> list) {
            this.list = list;
        }


        @Override
        public MyCustomAdapter.ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

            return new MyCustomAdapter.ItemViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.admin_list_item, parent, false));
        }

        public void onBindViewHolder(final MyCustomAdapter.ItemViewHolder holder, final int position) {

            try {

                final LoginData loginData = list.get(position);
                holder.txt_name.setText(loginData.company_names);
                if (!loginData.profile_image.isEmpty()) {
                    Picasso.with(Login.this).load(ApiUtils.BASE_URL + loginData.profile_image).networkPolicy(NetworkPolicy.NO_CACHE).into(holder.img_profile_image);
                } else {
                    Picasso.with(Login.this).load(R.mipmap.profilepic).into(holder.img_profile_image);

                }
                holder.txt_name.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String selected_id = loginData.admin_id;
//                        Toast.makeText(Login.this, selected_id, Toast.LENGTH_SHORT).show();
                        listDialog.dismiss();
                        employee_login_requestWithAdminId(selected_id);
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public int getItemCount() {
            return list != null ? list.size() : 0;
        }

        class ItemViewHolder extends RecyclerView.ViewHolder {
            TextView txt_name;
            CircleImageView img_profile_image;

            public ItemViewHolder(View itemView) {
                super(itemView);
                txt_name = (TextView) itemView.findViewById(R.id.txt_name);
                img_profile_image = (CircleImageView) itemView.findViewById(R.id.img_profile_image);
            }
        }
    }
*/

/*
    private void employee_login_requestWithAdminId(String admin_id) {
        InputMethodManager inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        if (progressDialog != null) progressDialog.show();
        ApiUtils.getAlterationService().login_post("login_with_admin_id.php", edt_email.getText().toString(), edt_pass.getText().toString(), admin_id).enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                try {
                    if (response.code() == 200) {
                        if (response.body().statusCode == 1) {
                            Intent in = new Intent(Login.this, MainActivity.class);
                            in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            overridePendingTransition(R.anim.slide_in_top, R.anim.stay);
                            startActivity(in);

                            if (remember) {
                                if(!Helper.getLocalValue(getApplicationContext(), "user_designation") .equalsIgnoreCase("admin"))
                                {
                                    start_Service();
                                }
                                Helper.storeLocally(Login.this, "user_id", response.body().loginData.get(0).userId);
                                Helper.storeLocally(Login.this, "user_name", response.body().loginData.get(0).name);
                                Helper.storeLocally(Login.this, "user_email", response.body().loginData.get(0).email);
                                Helper.storeLocally(Login.this, "user_phone", response.body().loginData.get(0).phone);
                                Helper.storeLocally(Login.this, "user_designation", response.body().loginData.get(0).designation);
                                Helper.storeLocally(Login.this, "user_pic", response.body().loginData.get(0).profile_image);
                                Helper.storeLocally(Login.this, "user_address", response.body().loginData.get(0).address);
                            }
                        } else {
                            Toast.makeText(Login.this, response.body().message, Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(Login.this, response.body().message, Toast.LENGTH_SHORT).show();
                    }
                    progressDialog.dismiss();
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(Login.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                t.printStackTrace();
                Toast.makeText(Login.this, call.toString(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        });
    }
*/

    public void start_Service() {
        if (MyApp.getInstance().isConnectingToInternet()) {
            startService(new Intent(Login.this, MyIntentService.class));
        }
    }

    @Override
    public void onBackPressed() {
        FragmentManager manager = getSupportFragmentManager();
        if (manager.getBackStackEntryCount() > 0) {
            // If there are back-stack entries, leave the FragmentActivity
            // implementation take care of them.
            manager.popBackStack();

        } else {
            // Otherwise, ask user if he wants to leave :)
            if (doubleBackToExitPressedOnce) {
                super.onBackPressed();
                this.finishAffinity();
                return;
            }

            this.doubleBackToExitPressedOnce = true;
            Toast.makeText(this, "Please click back again to exit", Toast.LENGTH_SHORT).show();

            new Handler().postDelayed(new Runnable() {

                @Override
                public void run() {
                    doubleBackToExitPressedOnce = false;
                }
            }, 2000);
        }
    }
}

