package co.in.location.crm;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AppCompatDialog;
import android.support.v7.widget.CardView;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.futuremind.recyclerviewfastscroll.FastScroller;

import org.apache.http.util.TextUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import co.in.location.GifImageView;
import co.in.location.R;
import co.in.location.Remote.ApiUtils;
import co.in.location.data.CRMListData;
import co.in.location.response.CRMListResponse;
import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FilteredLeads extends AppCompatActivity implements View.OnClickListener {
    RecyclerView recyclerView;
    String name, email, phone, address, profile_pic;
    CRMListResponse respose;
    MyCustomAdapter adapter;
    public static boolean deleteLead = false;
    public static boolean updateLead = false;
    private int lastPosition = -1;
    EditText edt;
    ImageView img_back;
    View edt_view;
    public List<CRMListData> crm_list_data_search = new ArrayList<CRMListData>();
    int Totalcount = 0, currentpage = 1, number_of_page = 0, selected_button = 1;
    TextView txt_back, txt_next, txt_1, txt_2, txt_3, txt_4;
    public static boolean page1 = true, page2 = false, page3 = false, page4 = false, page5 = false, page6 = false;
    TextView txt_message, prog_message;
    AppCompatDialog progressDialog;
    String user_id = "", from_date, to_date;
    private FastScroller fastScroller;
    RelativeLayout rl_pagination;
    LinearLayout ll_pagination;
    List<CRMListData> list;
    String message;
    public static String type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filtered_leads);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        recyclerView = (RecyclerView) findViewById(R.id.crm_list);
        fastScroller = (FastScroller) findViewById(R.id.fastscroll);
        fastScroller.setRecyclerView(recyclerView);
        txt_message = (TextView) findViewById(R.id.txt_message);
        rl_pagination = (RelativeLayout) findViewById(R.id.rl_pagination);
        ll_pagination = (LinearLayout) findViewById(R.id.ll_pagination);
        recyclerView.setLayoutManager(new LinearLayoutManager(FilteredLeads.this));
        recyclerView.setNestedScrollingEnabled(true);
        recyclerView.addItemDecoration(new DividerItemDecoration(FilteredLeads.this, DividerItemDecoration.VERTICAL));
        progressDialog = new AppCompatDialog(FilteredLeads.this);
        progressDialog.setCancelable(false);
        progressDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progressDialog.setContentView(R.layout.progress_loading);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        prog_message = progressDialog.findViewById(R.id.tv_progress_message);
        prog_message.setText("Please wait..");
        GifImageView gifImageView = (GifImageView) progressDialog.findViewById(R.id.GifImageView);
        gifImageView.setGifImageResource(R.drawable.loadinggif);

        txt_back = (TextView) findViewById(R.id.txt_back);
        txt_next = (TextView) findViewById(R.id.txt_next);
        txt_1 = (TextView) findViewById(R.id.txt_1);
        txt_2 = (TextView) findViewById(R.id.txt_2);
        txt_3 = (TextView) findViewById(R.id.txt_3);
        txt_4 = (TextView) findViewById(R.id.txt_4);
        txt_back.setOnClickListener(this);
        txt_next.setOnClickListener(this);
        txt_1.setOnClickListener(this);
        txt_2.setOnClickListener(this);
        txt_3.setOnClickListener(this);
        txt_4.setOnClickListener(this);
        img_back = (ImageView) findViewById(R.id.img_back);

        txt_1.setBackgroundResource(R.drawable.select_circle_background);

        user_id = getIntent().getStringExtra("user_id");
        type = getIntent().getStringExtra("type");
        from_date = getIntent().getStringExtra("fromDate");
        to_date = getIntent().getStringExtra("toDate");
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FilteredLeads.this.finish();
            }
        });
        edt = (EditText) findViewById(R.id.edt);
        edt_view = (View) findViewById(R.id.edt_view);
        edt.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.clear, 0);

        edt.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                final int DRAWABLE_LEFT = 0;
                final int DRAWABLE_TOP = 1;
                final int DRAWABLE_RIGHT = 2;
                final int DRAWABLE_BOTTOM = 3;

                if (event.getAction() == MotionEvent.ACTION_UP) {
                    if (event.getRawX() >= (edt.getRight() - edt.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {
                        edt.setText("");
                        edt.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.clear_white, 0);
//                        adapter = new MyCustomAdapter(SearchUser.this, responce.userdata);
//                        user_ListView.setAdapter(adapter);
                        return true;
                    }
                }
                return false;
            }
        });

        //
        edt.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {
                // put the code of save Database here
                edt.setError(null);
                if (s.toString().length() > 0) {
                    edt_view.setBackgroundColor(getResources().getColor(R.color.white));
                    edt.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.clear_white, 0);
                } else {
                    edt_view.setBackgroundColor(getResources().getColor(R.color.white_lite));
                    edt.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.clear, 0);
                }
                crm_list_data_search = new ArrayList<CRMListData>();
                for (int i = 0; i < respose.crmListData.size(); i++) {
                    if ((respose.crmListData.get(i).company.toLowerCase().contains(edt.getText().toString().toLowerCase())) || (respose.crmListData.get(i).email.toLowerCase().contains(edt.getText().toString().toLowerCase()))) {
                        crm_list_data_search.add(respose.crmListData.get(i));
                    }
                }
                if (crm_list_data_search.size() > 0) {
                    txt_message.setVisibility(View.GONE);
                } else {
                    txt_message.setVisibility(View.VISIBLE);
                    txt_message.setText("Empty! Record not found");
                }
                adapter = new MyCustomAdapter(crm_list_data_search);
                recyclerView.setAdapter(adapter);
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
        });
        //
        edt.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
//                    InputMethodManager inputManager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
//
//                    inputManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);

                    InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
                    inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
                    edt.setSelectAllOnFocus(false);
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(edt.getWindowToken(), 0);
//                    performSearch();
                    crm_list_data_search = new ArrayList<CRMListData>();
                    for (int i = 0; i < respose.crmListData.size(); i++) {
                        if (respose.crmListData.get(i).company.toLowerCase().contains(edt.getText().toString())) {
                            crm_list_data_search.add(respose.crmListData.get(i));
                        }
                    }
                    if (crm_list_data_search.size() > 0) {
                        txt_message.setVisibility(View.GONE);
                    } else {
                        txt_message.setVisibility(View.VISIBLE);
                        txt_message.setText("Empty! Record not found");
                    }
                    adapter = new MyCustomAdapter(crm_list_data_search);
                    recyclerView.setAdapter(adapter);
                    return true;
                }
                return false;
            }
        });
        /* getCRMList();*/
        getCRMList(currentpage);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.txt_back:
                if (selected_button == 4) {
                    selectthree();
                } else if (selected_button == 3) {
                    selecttwo();
                } else if (selected_button == 2) {
                    selectone();
                } else {
                    txt_4.setText(txt_3.getText().toString());
                    txt_3.setText(txt_2.getText().toString());
                    txt_2.setText(txt_1.getText().toString());
                    txt_1.setText("" + (Integer.parseInt(txt_1.getText().toString()) - 1));
                }

                currentpage = currentpage - 1;
                if (currentpage == 1) {
                    txt_back.setVisibility(View.GONE);
                }
                getCRMList(currentpage);
                break;
            case R.id.txt_next:
                if (selected_button == 1) {
                    selecttwo();
                } else if (selected_button == 2) {
                    selectthree();
                } else if (selected_button == 3) {
                    selectfour();
                } else {
                    txt_1.setText(txt_2.getText().toString());
                    txt_2.setText(txt_3.getText().toString());
                    txt_3.setText(txt_4.getText().toString());
                    txt_4.setText("" + (Integer.parseInt(txt_4.getText().toString()) + 1));
                }
                if (currentpage == number_of_page) {
                    txt_next.setVisibility(View.GONE);
                }
                currentpage = currentpage + 1;
                getCRMList(currentpage);
                break;
            case R.id.txt_1:
                selectone();
                currentpage = Integer.parseInt(txt_1.getText().toString());
                selected_button = 1;
                getCRMList(currentpage);
                break;
            case R.id.txt_2:
                selecttwo();
                currentpage = Integer.parseInt(txt_2.getText().toString());
                selected_button = 2;
                getCRMList(currentpage);
                break;
            case R.id.txt_3:
                selectthree();
                currentpage = Integer.parseInt(txt_3.getText().toString());
                selected_button = 3;
                getCRMList(currentpage);
                break;
            case R.id.txt_4:
                selectfour();
                currentpage = Integer.parseInt(txt_4.getText().toString());
                selected_button = 4;
                getCRMList(currentpage);
                break;

        }
    }

    public void selectone() {
        selected_button = 1;
        txt_1.setBackgroundResource(R.drawable.select_circle_background);
        txt_2.setBackgroundResource(R.drawable.unselect_circle_background);
        txt_3.setBackgroundResource(R.drawable.unselect_circle_background);
        txt_4.setBackgroundResource(R.drawable.unselect_circle_background);
    }

    public void selecttwo() {
        selected_button = 2;
        txt_1.setBackgroundResource(R.drawable.unselect_circle_background);
        txt_2.setBackgroundResource(R.drawable.select_circle_background);
        txt_3.setBackgroundResource(R.drawable.unselect_circle_background);
        txt_4.setBackgroundResource(R.drawable.unselect_circle_background);
    }

    public void selectthree() {
        selected_button = 3;
        txt_1.setBackgroundResource(R.drawable.unselect_circle_background);
        txt_2.setBackgroundResource(R.drawable.unselect_circle_background);
        txt_3.setBackgroundResource(R.drawable.select_circle_background);
        txt_4.setBackgroundResource(R.drawable.unselect_circle_background);
    }

    public void selectfour() {
        selected_button = 4;
        txt_1.setBackgroundResource(R.drawable.unselect_circle_background);
        txt_2.setBackgroundResource(R.drawable.unselect_circle_background);
        txt_3.setBackgroundResource(R.drawable.unselect_circle_background);
        txt_4.setBackgroundResource(R.drawable.select_circle_background);
    }

/*
    private void getCRMList() {
        try {
            if (LeadCRMList.respose.statusCode == 1) {
                if (LeadCRMList.respose != null) {
                    crm_list_data_search = LeadCRMList.respose.crmListData;
                    respose = LeadCRMList.respose;

                    adapter = null;
                    adapter = new MyCustomAdapter(respose.crmListData);
                    recyclerView.setAdapter(adapter);
                    if (respose.crmListData.size() > 0) {
                        txt_message.setVisibility(View.GONE);
                    } else {
                        txt_message.setVisibility(View.VISIBLE);
                    }
                } else {
                    Toast.makeText(FilteredLeads.this, respose.message, Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(FilteredLeads.this, respose.message, Toast.LENGTH_SHORT).show();

            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(FilteredLeads.this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
*/

    private void getCRMList(int currentpage) {
        if (progressDialog != null) progressDialog.show();
        ApiUtils.getAlterationService().get_filterCRMList("leads-filter", user_id, type, from_date, to_date, Integer.toString(currentpage)).enqueue(new Callback<CRMListResponse>() {
            @Override
            public void onResponse(Call<CRMListResponse> call, Response<CRMListResponse> response) {
                try {
                    if (response.code() == 200) {
                        if (response.body().statusCode == 1) {
                            if (response.body() != null) {
                                respose = response.body();
                                Totalcount = response.body().Totalcount;
                                int remainder = Totalcount % 15;
                                int quotient = Totalcount / 15;
                                if (remainder > 0) {
                                    number_of_page = quotient + 1;
                                } else {
                                    number_of_page = quotient;
                                }
                                if (number_of_page == 1) {
                                    ll_pagination.setVisibility(View.GONE);
                                } else {
                                    ll_pagination.setVisibility(View.VISIBLE);
                                }
                                if (number_of_page > 4) {
                                    txt_1.setVisibility(View.VISIBLE);
                                    txt_2.setVisibility(View.VISIBLE);
                                    txt_3.setVisibility(View.VISIBLE);
                                    txt_4.setVisibility(View.VISIBLE);
                                    txt_next.setVisibility(View.VISIBLE);
                                    txt_back.setVisibility(View.VISIBLE);
                                    if (Integer.parseInt(txt_1.getText().toString()) == 1) {
                                        txt_back.setVisibility(View.GONE);
                                    }
                                    if (Integer.parseInt(txt_4.getText().toString()) == number_of_page) {
                                        txt_next.setVisibility(View.GONE);
                                    }
                                } else if (number_of_page == 4) {
                                    txt_1.setVisibility(View.VISIBLE);
                                    txt_2.setVisibility(View.VISIBLE);
                                    txt_3.setVisibility(View.VISIBLE);
                                    txt_4.setVisibility(View.VISIBLE);
                                    txt_next.setVisibility(View.GONE);
                                    txt_back.setVisibility(View.GONE);
                                } else if (number_of_page == 3) {
                                    txt_1.setVisibility(View.VISIBLE);
                                    txt_2.setVisibility(View.VISIBLE);
                                    txt_3.setVisibility(View.VISIBLE);
                                    txt_4.setVisibility(View.GONE);
                                    txt_next.setVisibility(View.GONE);
                                    txt_back.setVisibility(View.GONE);
                                } else if (number_of_page == 2) {
                                    txt_1.setVisibility(View.VISIBLE);
                                    txt_2.setVisibility(View.VISIBLE);
                                    txt_3.setVisibility(View.GONE);
                                    txt_4.setVisibility(View.GONE);
                                    txt_next.setVisibility(View.GONE);
                                    txt_back.setVisibility(View.GONE);
                                } else if (number_of_page == 1) {
                                    txt_1.setVisibility(View.VISIBLE);
                                    txt_2.setVisibility(View.GONE);
                                    txt_3.setVisibility(View.GONE);
                                    txt_4.setVisibility(View.GONE);
                                    txt_next.setVisibility(View.GONE);
                                    txt_back.setVisibility(View.GONE);
                                }
                                adapter = null;
                                adapter = new MyCustomAdapter(response.body().crmListData);// new MyCustomAdapter(SocialAccount.this, response.body().socialdata);
                                recyclerView.setAdapter(adapter);
                                fastScroller.setRecyclerView(recyclerView);
                                if (response.body().crmListData.size() > 0) {
                                    txt_message.setVisibility(View.GONE);
                                } else {
                                    txt_message.setVisibility(View.VISIBLE);
                                }
                            } else {

                                Toast.makeText(FilteredLeads.this, response.body().message, Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(FilteredLeads.this, response.body().message, Toast.LENGTH_SHORT).show();
                        }
                    }
                    progressDialog.dismiss();
                } catch (Exception e) {
                    progressDialog.dismiss();
                    e.printStackTrace();
                    Toast.makeText(FilteredLeads.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<CRMListResponse> call, Throwable t) {
                progressDialog.dismiss();
                t.printStackTrace();
                Toast.makeText(FilteredLeads.this, call.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public class MyCustomAdapter extends RecyclerView.Adapter<MyCustomAdapter.ItemViewHolder> {

        List<CRMListData> list;

        public MyCustomAdapter(List<CRMListData> list) {
            this.list = list;
        }


        @Override
        public MyCustomAdapter.ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

            return new MyCustomAdapter.ItemViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.crm_list_item_new, parent, false));
        }

        public void onBindViewHolder(final MyCustomAdapter.ItemViewHolder holder, final int position) {

            try {

                final CRMListData crmListData = list.get(position);
                holder.txt_name.setText(capitalize(crmListData.company));
                String searchString = edt.getText().toString();
                if ((!TextUtils.isEmpty(searchString)) && (crmListData.company.toLowerCase().contains(searchString.toLowerCase()))) {
                    holder.txt_name.setText(highlightSearchKey(searchString, crmListData.company));
                }
                holder.txt_email.setText(crmListData.email);
                holder.txt_email.setText(crmListData.email);
                if ((!TextUtils.isEmpty(searchString)) && (crmListData.email.toLowerCase().contains(searchString.toLowerCase()))) {
                    holder.txt_email.setText(highlightSearchKey(searchString, crmListData.email));
                }

                /*if (position > lastPosition) {

                    Animation animation = AnimationUtils.loadAnimation(LeadCRMListSearch.this, R.anim.up_from_bottom);
                    holder.itemView.startAnimation(animation);
                    lastPosition = position;
                } else {
                    Animation animation = AnimationUtils.loadAnimation(LeadCRMListSearch.this, R.anim.bottom_from_up);
                    holder.itemView.startAnimation(animation);
                    lastPosition = position;
                }*/
                holder.card_view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                       /* selected_id = userListData.id;
                        name = userListData.name;
                        email = userListData.email;
                        phone = userListData.phone;
                        address = userListData.address;
                        designation = userListData.designation;
                        profile_pic = userListData.profile_image;*/

                        Intent in = new Intent(FilteredLeads.this, LeadCRMDetails.class);
                        in.putExtra("id", crmListData.id);
                        startActivity(in);
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public int getItemCount() {
            return list != null ? list.size() : 0;
        }

        class ItemViewHolder extends RecyclerView.ViewHolder {
            TextView txt_name, txt_email;
            CircleImageView img_profile_image;
            CardView card_view;

            public ItemViewHolder(View itemView) {
                super(itemView);
                txt_name = (TextView) itemView.findViewById(R.id.txt_name);
                txt_email = (TextView) itemView.findViewById(R.id.txt_email);
                img_profile_image = (CircleImageView) itemView.findViewById(R.id.img_profile_image);
                card_view = (CardView) itemView.findViewById(R.id.card_view);
            }
        }
    }

    private Spannable highlightSearchKey(String s, String text) {
        SpannableString spannableString = new SpannableString(text);
        ForegroundColorSpan[] backgroundColorSpan = spannableString.getSpans(0, spannableString.length(), ForegroundColorSpan.class);
        for (ForegroundColorSpan bgSpan : backgroundColorSpan) {
            spannableString.removeSpan(bgSpan);
        }
        int indexOfKeyWord = spannableString.toString().toLowerCase().indexOf(s.toLowerCase());
        while (indexOfKeyWord > -1) {
            spannableString.setSpan(new ForegroundColorSpan(Color.BLUE), indexOfKeyWord, indexOfKeyWord + s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            indexOfKeyWord = spannableString.toString().toLowerCase().indexOf(s.toLowerCase(), indexOfKeyWord + s.length());
        }
        return spannableString;
    }

    private String capitalize(String capString) {
        StringBuffer capBuffer = new StringBuffer();
        Matcher capMatcher = Pattern.compile("([a-z])([a-z]*)", Pattern.CASE_INSENSITIVE).matcher(capString);
        while (capMatcher.find()) {
            capMatcher.appendReplacement(capBuffer, capMatcher.group(1).toUpperCase() + capMatcher.group(2).toLowerCase());
        }
        return capMatcher.appendTail(capBuffer).toString();
    }

/*
    @Override
    public void onResume() {
        super.onResume();
        if (deleteLead || updateLead) {
            deleteLead = false;
            updateLead = false;
            adapter = null;
            getCRMList();
        }
    }
*/


}