package co.in.location;

import android.content.Context;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

/**
 * Created by st185188 on 11/5/17.
 */

public class Helper {

    public static void storeLocally(Context context, String key, String value) {
        try {

            SharedPreferences sharedPreferences = context.getSharedPreferences(context.getResources().getString(R.string.app_name), Context.MODE_PRIVATE);
            sharedPreferences.edit().putString(key, value).apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void storeLocallyboolean(Context context, String key, boolean value) {
        try {

            SharedPreferences sharedPreferences = context.getSharedPreferences(context.getResources().getString(R.string.app_name), Context.MODE_PRIVATE);
            sharedPreferences.edit().putBoolean(key, value).apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String getLocalValue(Context context, String key) {
        try {
            return context.getSharedPreferences(context.getResources().getString(R.string.app_name), Context.MODE_PRIVATE).getString(key, null);
        } catch (Exception e) {

            e.printStackTrace();
            return null;
        }
    }

    public static boolean getLocalValueboolean(Context context, String key) {
        try {
            return context.getSharedPreferences(context.getResources().getString(R.string.app_name), Context.MODE_PRIVATE).getBoolean(key, false);
        } catch (Exception e) {

            e.printStackTrace();
            return false;
        }
    }

}
