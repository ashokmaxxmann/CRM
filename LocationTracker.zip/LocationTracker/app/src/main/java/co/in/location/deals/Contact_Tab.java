package co.in.location.deals;

import android.os.Bundle;
import android.support.percent.PercentRelativeLayout;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import co.in.location.R;

public class Contact_Tab extends Fragment {
    TextView txt_contact_owner, txt_lead_source, txt_account_name, txt_contact_name, txt_email, txt_vendor_name, txt_phone, txt_title, txt_lead_status, txt_department, txt_other_pohone, txt_home_phone, txt_mobile, txt_fax, txt_assistance, txt_date_birth, txt_reports_to, txt_assistance_phone, txt_createdby, txt_email_opt_out, txt_skype_id, txt_modify_by, txt_secondry_email, txt_serial_number, txt_reporting_to, txt_twiter;
    PercentRelativeLayout prl1, prl2, prl3, prl4, prl5, prl6, prl7, prl8, prl9, prl10, prl11, prl12, prl13, prl14, prl15, prl16, prl17, prl18, prl19, prl20, prl21, prl22, prl23, prl24, prl25, prl26, prl27, prl28, prl29, prl30, prl31, prl32, prl33, prl34, prl35, prl36, v7, prl37, prl38, prl39, prl40, prl41, prl42, prl43, prl44, prl45, prl46, prl47, prl48, prl49, prl50, prl51;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.deals_contact, container, false);
        txt_contact_owner = (TextView) view.findViewById(R.id.txt_contact_owner);
        txt_lead_source = (TextView) view.findViewById(R.id.txt_lead_source);
        txt_account_name = (TextView) view.findViewById(R.id.txt_account_name);
        txt_contact_name = (TextView) view.findViewById(R.id.txt_contact_name);
        txt_email = (TextView) view.findViewById(R.id.txt_email);
        txt_vendor_name = (TextView) view.findViewById(R.id.txt_vendor_name);
        txt_phone = (TextView) view.findViewById(R.id.txt_phone);
        txt_title = (TextView) view.findViewById(R.id.txt_title);
        txt_lead_status = (TextView) view.findViewById(R.id.txt_lead_status);
        txt_department = (TextView) view.findViewById(R.id.txt_department);
        txt_other_pohone = (TextView) view.findViewById(R.id.txt_other_pohone);
        txt_home_phone = (TextView) view.findViewById(R.id.txt_home_phone);
        txt_mobile = (TextView) view.findViewById(R.id.txt_mobile);
        txt_fax = (TextView) view.findViewById(R.id.txt_fax);
        txt_assistance = (TextView) view.findViewById(R.id.txt_assistance);
        txt_date_birth = (TextView) view.findViewById(R.id.txt_date_birth);
        txt_reports_to = (TextView) view.findViewById(R.id.txt_reports_to);
        txt_assistance_phone = (TextView) view.findViewById(R.id.txt_assistance_phone);
        txt_createdby = (TextView) view.findViewById(R.id.txt_createdby);
        txt_email_opt_out = (TextView) view.findViewById(R.id.txt_email_opt_out);
        txt_skype_id = (TextView) view.findViewById(R.id.txt_skype_id);
        txt_modify_by = (TextView) view.findViewById(R.id.txt_modify_by);
        txt_secondry_email = (TextView) view.findViewById(R.id.txt_secondry_email);
        txt_serial_number = (TextView) view.findViewById(R.id.txt_serial_number);
        txt_reporting_to = (TextView) view.findViewById(R.id.txt_reporting_to);
        txt_twiter = (TextView) view.findViewById(R.id.txt_twiter);


        prl1 = (PercentRelativeLayout) view.findViewById(R.id.prl1);
        prl2 = (PercentRelativeLayout) view.findViewById(R.id.prl2);
        prl3 = (PercentRelativeLayout) view.findViewById(R.id.prl3);
        prl4 = (PercentRelativeLayout) view.findViewById(R.id.prl4);
        prl5 = (PercentRelativeLayout) view.findViewById(R.id.prl5);
        prl6 = (PercentRelativeLayout) view.findViewById(R.id.prl6);
        prl7 = (PercentRelativeLayout) view.findViewById(R.id.prl7);
        prl8 = (PercentRelativeLayout) view.findViewById(R.id.prl8);
        prl9 = (PercentRelativeLayout) view.findViewById(R.id.prl9);
        prl10 = (PercentRelativeLayout) view.findViewById(R.id.prl10);
        prl11 = (PercentRelativeLayout) view.findViewById(R.id.prl11);
        prl12 = (PercentRelativeLayout) view.findViewById(R.id.prl12);
        prl13 = (PercentRelativeLayout) view.findViewById(R.id.prl13);
        prl14 = (PercentRelativeLayout) view.findViewById(R.id.prl14);
        prl15 = (PercentRelativeLayout) view.findViewById(R.id.prl15);
        prl16 = (PercentRelativeLayout) view.findViewById(R.id.prl16);
        prl17 = (PercentRelativeLayout) view.findViewById(R.id.prl17);
        prl18 = (PercentRelativeLayout) view.findViewById(R.id.prl18);
        prl19 = (PercentRelativeLayout) view.findViewById(R.id.prl19);
        prl20 = (PercentRelativeLayout) view.findViewById(R.id.prl20);
        prl21 = (PercentRelativeLayout) view.findViewById(R.id.prl21);
        prl22 = (PercentRelativeLayout) view.findViewById(R.id.prl22);
        prl23 = (PercentRelativeLayout) view.findViewById(R.id.prl23);
        prl24 = (PercentRelativeLayout) view.findViewById(R.id.prl24);
        prl25 = (PercentRelativeLayout) view.findViewById(R.id.prl25);
        prl26 = (PercentRelativeLayout) view.findViewById(R.id.prl26);


//        id = getIntent().getStringExtra("id");
//        currentpage = getIntent().getIntExtra("currentpage", 0);
//        txt_mobile.setOnClickListener(this);
//        getDetails();
//        dealCRMDetails = this;
        executeMethode();
        return view;
    }

    public void executeMethode() {

        txt_contact_owner.setText(DealsDetails.respose.crmListData.get(0).number);
        txt_lead_source.setText(DealsDetails.respose.crmListData.get(0).company);
        txt_account_name.setText(DealsDetails.respose.crmListData.get(0).f_name);
        txt_contact_name.setText(DealsDetails.respose.crmListData.get(0).l_name);
        txt_email.setText(DealsDetails.respose.crmListData.get(0).title);
        txt_vendor_name.setText(DealsDetails.respose.crmListData.get(0).address);
        txt_phone.setText(DealsDetails.respose.crmListData.get(0).city);
        txt_title.setText(DealsDetails.respose.crmListData.get(0).location);
        txt_lead_status.setText(DealsDetails.respose.crmListData.get(0).state);
        txt_department.setText(DealsDetails.respose.crmListData.get(0).pincode);
        txt_other_pohone.setText(DealsDetails.respose.crmListData.get(0).phone);
        txt_home_phone.setText(DealsDetails.respose.crmListData.get(0).mobile);
        txt_email.setText(DealsDetails.respose.crmListData.get(0).email);
        txt_fax.setText(DealsDetails.respose.crmListData.get(0).additonal_contact);
        txt_assistance.setText(DealsDetails.respose.crmListData.get(0).annual_revenue);
        txt_date_birth.setText(DealsDetails.respose.crmListData.get(0).no_employee);
        txt_reports_to.setText(DealsDetails.respose.crmListData.get(0).lead_source);
        txt_assistance_phone.setText(DealsDetails.respose.crmListData.get(0).sales_person);
        txt_createdby.setText(DealsDetails.respose.crmListData.get(0).industry);
        txt_email_opt_out.setText(DealsDetails.respose.crmListData.get(0).lead_owner);
        txt_skype_id.setText(DealsDetails.respose.crmListData.get(0).google_reviews);
        txt_modify_by.setText(DealsDetails.respose.crmListData.get(0).Just_Dial_Reviews);
        txt_secondry_email.setText(DealsDetails.respose.crmListData.get(0).facebook_reviews);
        txt_serial_number.setText(DealsDetails.respose.crmListData.get(0).Other_Social_Channel_Reviews);
        txt_reporting_to.setText(DealsDetails.respose.crmListData.get(0).Fb_likes);
        txt_twiter.setText(DealsDetails.respose.crmListData.get(0).FB_Followers);
    }

}
