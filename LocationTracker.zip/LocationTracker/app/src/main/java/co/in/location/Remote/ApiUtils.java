package co.in.location.Remote;

/**
 * Created by saitej dandge on 06-06-2017.
 */

public class ApiUtils {

  /*  public static final String BASE_URL = "http://maxxmannsupport.com/empapi/";*/

    /*public static final String BASE_URL = "http://maxxmannsupport.com/empapi/apidev/";*/
    public static final String BASE_URL = "http://crm.maxxmannsupport.com/api/";

    public static WebService getAlterationService() {
        return RetrofitClient.getClient(BASE_URL).create(WebService.class);
    }


    public static String getAPIEndPoint(String input) {
        return BASE_URL + input;
    }

}