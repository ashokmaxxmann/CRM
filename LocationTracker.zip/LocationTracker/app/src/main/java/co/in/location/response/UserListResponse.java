package co.in.location.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

import co.in.location.data.LoginData;
import co.in.location.data.UserListData;

public class UserListResponse {
    @SerializedName("status")
    @Expose
    public int statusCode;
    @SerializedName("message")
    @Expose
    public String message;
    @SerializedName("data")
    @Expose
    public List<UserListData> userListData = new ArrayList<>();
}
