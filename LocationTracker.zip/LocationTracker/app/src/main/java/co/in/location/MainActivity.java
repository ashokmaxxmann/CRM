package co.in.location;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatDelegate;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ExpandableListView;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import co.in.location.Remote.ApiUtils;
import co.in.location.admin.AddEmployee;
import co.in.location.admin.Admin_Profile_Update;
import co.in.location.admin.LiveLocations;
import co.in.location.crm.AssignLeadCRMList;
import co.in.location.crm.Filters;
import co.in.location.crm.LeadCRMList;
import co.in.location.crm.LeadCRMListSearch;
import co.in.location.admin.UserList;
import co.in.location.crm.UnassignLeadCRMList;
import co.in.location.deals.Deals;
import co.in.location.service.MyIntentService;
import co.in.location.user.LocationMap;
import co.in.location.user.User_Profile_Update;
import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {
    public static ExpandableListView expListView;
    List<String> listDataHeader;
    HashMap<String, List<String>> listDataChild;
    HashMap<String, List<String>> listDataChildid;
    public static String subcatid;
    public static String str_categories = "";
    public static String str_subcategories = "";
    public static String str_subcategoriesid = "";
    Fragment fragment;
    FragmentTransaction ft;
    public static DrawerLayout drawerLayout;
    public static ExpandableListAdapter expandableListAdapter;
    String[] str_admin = {"All Sales Rep.", "Leads", "Deals", "Add Sales Rep.", "Users Location", "Edit Profile", "Logout"};
    String[] str_user = {"My Location", "Leads", "Deals", "Edit Profile", "Logout"};
    String[] str_managment = {"All leads", "Assigned leads", "Unassigned leads"};

    String[] str = new String[4];
    //    String[] str_managment = {};
    String[] str_message = {};
    String[] str_setting = {};
    int[] icons_admin = {R.drawable.all_users_menu, R.drawable.leads_menu, R.drawable.ic_deal, R.drawable.add_user_menu, R.drawable.marker_menu, R.drawable.editprofile_menu, R.drawable.logout_menu};
    int[] icons_user = {R.drawable.marker_menu, R.drawable.leads_menu, R.drawable.ic_deal, R.drawable.editprofile_menu, R.drawable.logout_menu};
    int[] icons = new int[4];
    private int lastExpandedPosition = -1;
    public static int selected_groupPosition, selecte_childPosition = -1;
    boolean doubleBackToExitPressedOnce = false;
    TextView user_email, user_name;
    NavigationView mNavigationView;
    CircleImageView profile_image;
    List<String> menu_items_managment = new ArrayList<String>();
    List<String> menu_items_message = new ArrayList<String>();
    List<String> menu_items_setting = new ArrayList<String>();

    Handler myHandler = new Handler();
    Runnable myRunnable;
    boolean user_list = false;
    Map<String, String> map = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
    String name, email, image_url, designation;
    FrameLayout frameLayout;
    public static ActionBarDrawerToggle actionBarDrawerToggle;
    public static boolean mToolBarNavigationListenerIsRegistered = false;
    public static Menu menu_value;
    public static boolean all_lead = false;
    public static boolean add_lead = false;
    public static boolean add_page2 = false;
    public static boolean long_press = false;
   public static boolean leadcrmlist=false;
    public static LeadCRMList.MyCustomAdapter all_adapter_crm;
    public static Deals.MyCustomAdapter all_adapter_deals;
    public static UnassignLeadCRMList.MyCustomAdapter unassign_adapter;
    public static AssignLeadCRMList.MyCustomAdapter assign_adapter;
    public static HashMap<Integer, HashMap<String, Boolean>> checked_id = new HashMap<Integer, HashMap<String, Boolean>>();
    public static boolean fromMainpage = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        setContentView(R.layout.activity_main);
        selected_groupPosition = 0;
        selecte_childPosition = -1;
        Log.e("ashok", "onCreate()");

        boolean tabletSize = getResources().getBoolean(R.bool.isTablet);
        if (tabletSize) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }


       /* Intent serviceIntent = new Intent(this, MyIntentService.class);
        startService(serviceIntent);*/

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        expListView = (ExpandableListView) findViewById(R.id.expandableListView);
        drawerLayout = findViewById(R.id.drawer);
        mNavigationView = (NavigationView) findViewById(R.id.navigation_view);
        View header = mNavigationView.getHeaderView(0);
        user_email = (TextView) header.findViewById(R.id.user_email);
        user_name = (TextView) header.findViewById(R.id.user_name);
        profile_image = (CircleImageView) header.findViewById(R.id.profile_image);
        email = Helper.getLocalValue(MainActivity.this, "user_email");
        name = Helper.getLocalValue(MainActivity.this, "user_name");
        image_url = Helper.getLocalValue(MainActivity.this, "user_pic");
        designation = Helper.getLocalValue(MainActivity.this, "user_designation");
        user_email.setText(email);
        user_name.setText(name);
        if (!TextUtils.isEmpty(image_url)) {
            Picasso.with(MainActivity.this).load(ApiUtils.BASE_URL + image_url).networkPolicy(NetworkPolicy.NO_CACHE).into(profile_image);
        } else {
            Picasso.with(MainActivity.this).load(R.mipmap.profilepic).networkPolicy(NetworkPolicy.NO_CACHE).into(profile_image);

        }
        frameLayout = (FrameLayout) findViewById(R.id.frame);

        if (Helper.getLocalValue(MainActivity.this, "user_designation").equalsIgnoreCase("admin")) {
            fragment = new UserList();
            getSupportActionBar().setTitle("All Sales Representative");
            str = str_admin;
            icons = icons_admin;
        } else {
            fragment = new LocationMap();
            getSupportActionBar().setTitle("My Current Location");
            str = str_user;
            icons = icons_user;
        }
        ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.frame, fragment);
        ft.commit();


        menu_items_managment.clear();
        menu_items_message.clear();
        menu_items_setting.clear();
        boolean result = Utility.checkPermission(MainActivity.this);

        listDataHeader = new ArrayList<String>();
        listDataChild = new HashMap<String, List<String>>();
        listDataChildid = new HashMap<String, List<String>>();
        for (int i = 0; i < str.length; i++) {

            listDataHeader.add(str[i]);

            List<String> WebDesigning = new ArrayList<String>();
            List<String> WebDesignings = new ArrayList<String>();

            if (str[i].equalsIgnoreCase("Leads")) {
                for (int j = 0; j < str_managment.length; j++) {

                    WebDesigning.add(str_managment[j]);
                    WebDesignings.add("1");
                }
                listDataChild.put(listDataHeader.get(i), WebDesigning);
                listDataChildid.put(listDataHeader.get(i), WebDesignings);
            } else if (i == 2) {
                for (int k = 0; k < str_message.length; k++) {

                    WebDesigning.add(str_message[k]);
                    WebDesignings.add("1");
                }
                listDataChild.put(listDataHeader.get(i), WebDesigning);
                listDataChildid.put(listDataHeader.get(i), WebDesignings);
            } else if (i == 5) {
                for (int k = 0; k < str_setting.length; k++) {
                    WebDesigning.add(str_setting[k]);
                    WebDesignings.add("1");
                }
                listDataChild.put(listDataHeader.get(i), WebDesigning);
                listDataChildid.put(listDataHeader.get(i), WebDesignings);
            } else {
                listDataChild.put(listDataHeader.get(i), WebDesigning);
                listDataChildid.put(listDataHeader.get(i), WebDesigning);
            }
        }
        expandableListAdapter = new ExpandableListAdapter(this, listDataHeader, listDataChild, icons);
        expListView.setAdapter(expandableListAdapter);
        expListView.setFooterDividersEnabled(true);
        expListView.addFooterView(new View(expListView.getContext()));

        expListView.setGroupIndicator(null);
        expListView.setChildIndicator(null);
        expListView.setChildDivider(getResources().getDrawable(R.color.white));
        expListView.setDivider(getResources().getDrawable(R.color.white));
        expListView.setDividerHeight(0);


        expListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {

            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {

                return false;
            }
        });


        expListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {

            @Override
            public void onGroupExpand(int groupPosition) {
                str_categories = listDataHeader.get(groupPosition);
                if (!str_categories.equalsIgnoreCase("Logout")) {
                    if (lastExpandedPosition != -1 && groupPosition != lastExpandedPosition) {
                        expListView.collapseGroup(lastExpandedPosition);
                    }
                    lastExpandedPosition = groupPosition;
                }
                if (listDataChild.get(str_categories).size() == 0) {
                    menu_value.getItem(0).setVisible(false);
                    if (str_categories.equalsIgnoreCase("All Sales Rep.")) {
                        add_lead = false;
                        fragment = new UserList();
                        getSupportActionBar().setTitle("All Sales Rep.");
                        ft = getSupportFragmentManager().beginTransaction();
                        ft.replace(R.id.frame, fragment);
                        ft.commit();
                        drawerLayout.closeDrawers();
                        selected_groupPosition = groupPosition;
                    } else if (str_categories.equalsIgnoreCase("My Location")) {
                        add_lead = false;
                        fragment = new LocationMap();
                        getSupportActionBar().setTitle("My Location");
                        ft = getSupportFragmentManager().beginTransaction();
                        ft.replace(R.id.frame, fragment);
                        ft.commit();
                        drawerLayout.closeDrawers();
                        selected_groupPosition = groupPosition;
                    } else if (str_categories.equalsIgnoreCase("Leads")) {
                        all_lead = true;
                        add_lead = false;
                        getSupportActionBar().setTitle("Leads");
                        fragment = new LeadCRMList();
                        ft = getSupportFragmentManager().beginTransaction();
                        ft.replace(R.id.frame, fragment);
                        ft.commit();
                        drawerLayout.closeDrawers();
                        selected_groupPosition = groupPosition;
                    } else if (str_categories.equalsIgnoreCase("Deals")) {
                        leadcrmlist=false;
                        add_lead = false;
                        getSupportActionBar().setTitle("Deals");
                        fragment = new Deals();
//                        fragment = new NewDeals();
                        ft = getSupportFragmentManager().beginTransaction();
                        ft.replace(R.id.frame, fragment);
                        ft.commit();
                        drawerLayout.closeDrawers();
                        selected_groupPosition = groupPosition;
                    } else if (str_categories.equalsIgnoreCase("Add Sales Rep.")) {
                        add_lead = false;
                        getSupportActionBar().setTitle("Add Sales Rep.");
                        fragment = new AddEmployee();
                        ft = getSupportFragmentManager().beginTransaction();
                        ft.replace(R.id.frame, fragment);
                        ft.commit();
                        drawerLayout.closeDrawers();
                        selected_groupPosition = groupPosition;
                    } else if (str_categories.equalsIgnoreCase("Users Location")) {
                        add_lead = false;
                        getSupportActionBar().setTitle("Users Location");
                        fragment = new LiveLocations();
                        ft = getSupportFragmentManager().beginTransaction();
                        ft.replace(R.id.frame, fragment);
                        ft.commit();
                        drawerLayout.closeDrawers();
                        selected_groupPosition = groupPosition;
                    }  /*else if (str_categories.equalsIgnoreCase("Location History")) {
                        Toast.makeText(MainActivity.this, "Permission denied for your account", Toast.LENGTH_SHORT).show();
                       *//* getSupportActionBar().setTitle("Location History");
                        fragment = new UserLocationHistory();
                        ft = getSupportFragmentManager().beginTransaction();
                        ft.replace(R.id.frame, fragment);
                        ft.commit();
                        drawerLayout.closeDrawers();
                        selected_groupPosition = groupPosition;*//*
                    }*/ else if (str_categories.equalsIgnoreCase("Edit Profile")) {
                        add_lead = false;
                        getSupportActionBar().setTitle("Profile Update");
                        if (Helper.getLocalValue(MainActivity.this, "user_designation").equalsIgnoreCase("admin")) {
                            fragment = new Admin_Profile_Update();
                        } else {
                            fragment = new User_Profile_Update();
                        }
                        ft = getSupportFragmentManager().beginTransaction();
                        ft.replace(R.id.frame, fragment);
                        ft.commit();
                        drawerLayout.closeDrawers();
                        selected_groupPosition = groupPosition;
                    } else if (str_categories.equalsIgnoreCase("Logout")) {
                        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
                        alertDialogBuilder.setMessage("Are you sure,You want to logout");
                        alertDialogBuilder.setCancelable(false);
                        alertDialogBuilder.setPositiveButton("yes",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface arg0, int arg1) {
                                        stop_Service();
                                        Helper.storeLocally(MainActivity.this, "user_id", null);
                                        Helper.storeLocally(MainActivity.this, "user_email", null);
                                        myHandler.removeCallbacks(myRunnable);
                                        startActivity(new Intent(MainActivity.this, Login.class));
                                        MainActivity.this.finishAffinity();
                                    }
                                });

                        alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                drawerLayout.closeDrawers();
//                                previoue_position=selected_groupPosition;
                            }
                        });

                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    }
                    execute();
                } else
                    selected_groupPosition = groupPosition;

            }
        });

        // Listview Group collasped listener
        expListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {

            @Override
            public void onGroupCollapse(int groupPosition) {
                if (!str_categories.equalsIgnoreCase("Logout")) {
                    selecte_childPosition = -1;
                }

            }
        });

        // Listview on child click listener
        expListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {

            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                // TODO Auto-generated method stub
                str_subcategories = listDataChild.get(listDataHeader.get(groupPosition)).get(childPosition);
                str_subcategoriesid = listDataChildid.get(listDataHeader.get(groupPosition)).get(childPosition);

                subcatid = str_subcategoriesid;
                selecte_childPosition = childPosition;

                getSupportActionBar().setTitle(str_subcategories);
                /*if (str_subcategories.equalsIgnoreCase("New Lead")) {
                    user_list = true;
                    fromMainpage = true;
                    fragment = new LeadCRMForm1();
                    Bundle bundle = new Bundle();
                    bundle.putString("from", "from_add");
                    fragment.setArguments(bundle);
                } else */
                if (str_subcategories.equalsIgnoreCase("All Leads")) {
                    user_list = true;
                    fragment = new LeadCRMList();
                    Bundle args = new Bundle();
                    args.putString("type", "2");
                    args.putString("message", "All Leads");
                    fragment.setArguments(args);
                } else if (str_subcategories.equalsIgnoreCase("Assigned Leads")) {
                    user_list = true;
                    fragment = new LeadCRMList();
                    Bundle args = new Bundle();
                    args.putString("type", "1");
                    args.putString("message", "Assigned Leads");
                    fragment.setArguments(args);
                } else if (str_subcategories.equalsIgnoreCase("Unassigned Leads")) {
                    leadcrmlist=true;
                    user_list = true;
                    fragment = new LeadCRMList();
                    Bundle args = new Bundle();
                    args.putString("type", "0");
                    args.putString("message", "Unassigned Leads");
                    fragment.setArguments(args);
                }

                ft = getSupportFragmentManager().beginTransaction();
                ft.add(R.id.frame, fragment);
                ft.commit();
                drawerLayout.closeDrawers();
                parent.setAdapter(expandableListAdapter);
                expListView.expandGroup(groupPosition);
                return false;
            }
        });
        expListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                // Code here will be triggered once the drawer closes as we dont want anything to happen so we leave this blank
                super.onDrawerClosed(drawerView);
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                // Code here will be triggered once the drawer open as we dont want anything to happen so we leave this blank
                String name = Helper.getLocalValue(MainActivity.this, "user_name");
                user_name.setText(name);
                String image_url = Helper.getLocalValue(MainActivity.this, "user_pic");
                if (!TextUtils.isEmpty(image_url)) {
                    Picasso.with(MainActivity.this).load(ApiUtils.BASE_URL + image_url).networkPolicy(NetworkPolicy.NO_CACHE).into(profile_image);
                } else {
                    Picasso.with(MainActivity.this).load(R.mipmap.profilepic).networkPolicy(NetworkPolicy.NO_CACHE).into(profile_image);

                }

                super.onDrawerOpened(drawerView);
            }
        };


        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessay or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();

        actionBarDrawerToggle.setDrawerIndicatorEnabled(false);
        Drawable drawable = ResourcesCompat.getDrawable(getResources(), R.drawable.menu_divider, MainActivity.this.getTheme());
        actionBarDrawerToggle.setHomeAsUpIndicator(drawable);
        actionBarDrawerToggle.setToolbarNavigationClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerVisible(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                } else {
                    drawerLayout.openDrawer(GravityCompat.START);
                }
            }
        });

    }

    /* @Override
     public void onBackPressed() {
         if (bottomSheetBehaviorstate == 3) {
             ManagePermission.onBackPressed();
         } else {
             super.onBackPressed();
         }
     }*/
    @Override
    public void onBackPressed() {
        android.support.v4.app.FragmentManager fm = getSupportFragmentManager();
        int size = fm.getBackStackEntryCount();
        if (size > 0) {
            // If there are back-stack entries, leave the FragmentActivity
            // implementation take care of them.

            if (size > 1) {
                fm.popBackStack();
            } else {
                if (fromMainpage) {
                    fm.popBackStack();
                } else {
                    alert();
                }

            }

        } else {
            if (long_press) {
                long_press = false;
                if(leadcrmlist)
                {
                    leadcrmlist=false;
                    LeadCRMList cr = new LeadCRMList();
                    cr.ok(this);
                }
                else
                {
                    Deals cr = new Deals();
                    cr.ok(this);
                }
//                Toast.makeText(this, "work", Toast.LENGTH_SHORT).show();
            } else {
                // Otherwise, ask user if he wants to leave :)
                if (doubleBackToExitPressedOnce) {
                    super.onBackPressed();
                    myHandler.removeCallbacks(myRunnable);
                    selected_groupPosition = -1;
                    this.finishAffinity();
                    return;
                }

                this.doubleBackToExitPressedOnce = true;
                Toast.makeText(this, "Please click back again to exit", Toast.LENGTH_SHORT).show();

                new Handler().postDelayed(new Runnable() {

                    @Override
                    public void run() {
                        doubleBackToExitPressedOnce = false;
                    }
                }, 2000);
            }
        }
    }

    public void stop_Service() {
        stopService(new Intent(MainActivity.this, MyIntentService.class));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e("ashok", "onDestroy()");
    }

    public void execute() {
        MainActivity.drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);

        // Remove back button
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        // Show hamburger
        MainActivity.actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
        // Remove the/any drawer toggle listener
        MainActivity.actionBarDrawerToggle.setToolbarNavigationClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Doesn't have to be onBackPressed
//                        onBackPressed();
                getFragmentManager().popBackStack();
            }
        });
        MainActivity.mToolBarNavigationListenerIsRegistered = false;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_search, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.cancel_menu:

                alert();
                return true;
            case R.id.search:
                Intent in = new Intent(MainActivity.this, LeadCRMListSearch.class);
                startActivity(in);
                return true;
            case R.id.filter:
                startActivity(new Intent(MainActivity.this, Filters.class));
                break;
            default:
                break;
        }
        return true;
    }

    public void alert() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
        alertDialogBuilder.setTitle("Are you sure,You want to cancel?");
        alertDialogBuilder.setMessage("All data will be erased.");
        alertDialogBuilder.setCancelable(false);
        alertDialogBuilder.setPositiveButton("yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        Method_execute();
                    }
                });

        alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        menu_value = menu;
        if (all_lead) {
            all_lead = false;
            menu.getItem(0).setVisible(false);
            menu.getItem(1).setVisible(true);
            menu.getItem(2).setVisible(true);
        } else if (add_lead) {
            if (add_page2) {
                menu.getItem(0).setVisible(true);
                menu.getItem(1).setVisible(false);
                menu.getItem(2).setVisible(false);
            } else {
                menu.getItem(0).setVisible(false);
                menu.getItem(1).setVisible(false);
                menu.getItem(2).setVisible(false);
            }
        } else {
            menu.getItem(0).setVisible(false);
            menu.getItem(1).setVisible(false);
            menu.getItem(2).setVisible(false);
        }
        return true;
    }

    public void Method_execute() {
        Helper.storeLocally(MainActivity.this, "number", "");
        Helper.storeLocally(MainActivity.this, "first_name", "");
        Helper.storeLocally(MainActivity.this, "last_name", "");
        Helper.storeLocally(MainActivity.this, "company_name", "");
        Helper.storeLocally(MainActivity.this, "title", "");
        Helper.storeLocally(MainActivity.this, "city_name", "");
        Helper.storeLocally(MainActivity.this, "address", "");
        Helper.storeLocally(MainActivity.this, "loction_name", "");
        Helper.storeLocally(MainActivity.this, "state", "");
        Helper.storeLocally(MainActivity.this, "pincode", "");
        Helper.storeLocally(MainActivity.this, "phone", "");
        Helper.storeLocally(MainActivity.this, "mobile", "");
        Helper.storeLocally(MainActivity.this, "additonal_contact", "");
        Helper.storeLocally(MainActivity.this, "email", "");
        Helper.storeLocally(MainActivity.this, "lead_source", "");
        Helper.storeLocally(MainActivity.this, "no_employee", "");
        Helper.storeLocally(MainActivity.this, "annual_revenue", "");
        Helper.storeLocally(MainActivity.this, "industry", "");
        Helper.storeLocally(MainActivity.this, "lead_owner", "");
        Helper.storeLocally(MainActivity.this, "sales_person", "");


        Helper.storeLocally(MainActivity.this, "google_reviews", "");
        Helper.storeLocally(MainActivity.this, "Just_Dial_Reviews", "");
        Helper.storeLocally(MainActivity.this, "facebook_reviews", "");
        Helper.storeLocally(MainActivity.this, "Other_Social_Channel_Reviews", "");
        Helper.storeLocally(MainActivity.this, "Fb_likes", "");
        Helper.storeLocally(MainActivity.this, "FB_Followers", "");
        Helper.storeLocally(MainActivity.this, "Response_Rate", "");
        Helper.storeLocally(MainActivity.this, "Engagement_Rate", "");
        Helper.storeLocally(MainActivity.this, "Linkedin_Followers", "");

        Helper.storeLocally(MainActivity.this, "Website", "");
        Helper.storeLocally(MainActivity.this, "Website_Technology", "");
        Helper.storeLocally(MainActivity.this, "Website_information", "");
        Helper.storeLocally(MainActivity.this, "Website_Type", "");
        Helper.storeLocally(MainActivity.this, "Overlook_and_Feels", "");
        Helper.storeLocally(MainActivity.this, "Website_Language", "");
        Helper.storeLocally(MainActivity.this, "Content_Quality", "");
        Helper.storeLocally(MainActivity.this, "Graphic_Quality", "");
        Helper.storeLocally(MainActivity.this, "Global_Rank", "");
        Helper.storeLocally(MainActivity.this, "total_score", "");


        Helper.storeLocally(MainActivity.this, "Ranking_Keyword_1", "");
        Helper.storeLocally(MainActivity.this, "Global_Rank_Keyword_1", "");
        Helper.storeLocally(MainActivity.this, "Ranking_Keyword_2", "");
        Helper.storeLocally(MainActivity.this, "Global_Rank_Keyword_2", "");
        Helper.storeLocally(MainActivity.this, "Ranking_Keyword_3", "");
        Helper.storeLocally(MainActivity.this, "Global_Rank_Keyword_3", "");
        Helper.storeLocally(MainActivity.this, "Ranking_Keyword_4", "");
        Helper.storeLocally(MainActivity.this, "Global_Rank_Keyword_4", "");
        Helper.storeLocally(MainActivity.this, "Ranking_Keyword_5", "");
        Helper.storeLocally(MainActivity.this, "Global_Rank_Keyword_5", "");
        Helper.storeLocally(MainActivity.this, "Ranking_Keyword_6", "");
        Helper.storeLocally(MainActivity.this, "Global_Rank_Keyword_6", "");
        Helper.storeLocally(MainActivity.this, "Ranking_Keyword_7", "");
        Helper.storeLocally(MainActivity.this, "Global_Rank_Keyword_7", "");


        Helper.storeLocally(MainActivity.this, "First_Actions", "");
        Helper.storeLocally(MainActivity.this, "First_Action_Remarks", "");
        Helper.storeLocally(MainActivity.this, "Second_Actions", "");
        Helper.storeLocally(MainActivity.this, "Second_Action_Remarks", "");
        Helper.storeLocally(MainActivity.this, "Third_Actions", "");
        Helper.storeLocally(MainActivity.this, "Third_Action_Remarks", "");
        Helper.storeLocally(MainActivity.this, "Fourth_Actions", "");
        Helper.storeLocally(MainActivity.this, "Fouth_Action_Remarks", "");
        Helper.storeLocally(MainActivity.this, "Fifth_Actions", "");
        Helper.storeLocally(MainActivity.this, "Fifth_Action_Remarks", "");
        Helper.storeLocally(MainActivity.this, "Final_Actions", "");
        Helper.storeLocally(MainActivity.this, "Final_Action_Remarks", "");

        Helper.storeLocally(MainActivity.this, "Proposal_Sent_For", "");
        Helper.storeLocally(MainActivity.this, "Proposal_Sent_On", "");
        Helper.storeLocally(MainActivity.this, "Total_value", "");
        Helper.storeLocally(MainActivity.this, "Expected_Closure_Date", "");
        Helper.storeLocally(MainActivity.this, "Proposal_not_sent_for", "");
        Helper.storeLocally(MainActivity.this, "Reason", "");
        Helper.storeLocally(MainActivity.this, "Status", "");

        drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);

        // Remove back button
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        // Show hamburger
        actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
        // Remove the/any drawer toggle listener
        mToolBarNavigationListenerIsRegistered = false;
        android.support.v4.app.FragmentManager fm = getSupportFragmentManager();
        int size = fm.getBackStackEntryCount();
        if (size > 0) {
            for (int i = 0; i < size; i++) {
                getSupportFragmentManager().popBackStack();
            }
        }
        menu_value.getItem(0).setVisible(false);

    }

}