package co.in.location;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatDialog;
import android.support.v7.widget.AppCompatCheckBox;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListPopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import co.in.location.Remote.ApiUtils;
import co.in.location.response.RegisterResponse;
import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class Register extends AppCompatActivity implements View.OnClickListener {
    EditText edt_name, edt_phone, edt_email, edt_pass, edt_con_pass, edt_add, edt_designation;
    TextView txt_submit, txt_login;
    AppCompatDialog progressDialog;
    TextView prog_message;
    boolean pass_view = false, con_pass_view = false;
    boolean doubleBackToExitPressedOnce = false;
    CircleImageView profile_image;
    private int REQUEST_CAMERA = 0, SELECT_FILE = 1;
    private String realPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        edt_name = (EditText) findViewById(R.id.edt_name);
        edt_email = (EditText) findViewById(R.id.edt_email);
        edt_phone = (EditText) findViewById(R.id.edt_phone);
        edt_pass = (EditText) findViewById(R.id.edt_pass);
        edt_con_pass = (EditText) findViewById(R.id.edt_con_pass);
        edt_add = (AutoCompleteTextView) findViewById(R.id.edt_add);
        edt_designation = (EditText) findViewById(R.id.edt_designation);
        txt_submit = (TextView) findViewById(R.id.txt_submit);
        txt_login = (TextView) findViewById(R.id.txt_login);
        txt_submit.setOnClickListener(this);
        txt_login.setOnClickListener(this);
        progressDialog = new AppCompatDialog(Register.this);
        progressDialog.setCancelable(false);
        progressDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progressDialog.setContentView(R.layout.progress_loading);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        prog_message = progressDialog.findViewById(R.id.tv_progress_message);
        prog_message.setText("Please wait..");

        GifImageView gifImageView = (GifImageView) progressDialog.findViewById(R.id.GifImageView);
        gifImageView.setGifImageResource(R.drawable.loadinggif);

        profile_image = (CircleImageView) findViewById(R.id.profile_image);
        profile_image.setOnClickListener(this);


        edt_name.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (edt_name.getText().toString().equalsIgnoreCase("")) {
                        edt_name.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                    } else if (!edt_name.getText().toString().equalsIgnoreCase("")) {
                        edt_name.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.button)));
                    }
                } else {
                    if (edt_name.getText().toString().equalsIgnoreCase("")) {
                        edt_name.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.placeholder)));
                    } else if (!edt_name.getText().toString().equalsIgnoreCase("")) {
                        edt_name.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                    }
                }
            }
        });

        edt_name.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!edt_name.getText().toString().equalsIgnoreCase("")) {
                    edt_name.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.button)));
                } else {
                    edt_name.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                }
            }
        });
        edt_email.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (edt_email.getText().toString().equalsIgnoreCase("")) {
                        edt_email.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                    } else if (!edt_email.getText().toString().equalsIgnoreCase("")) {
                        edt_email.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.button)));
                    }
                } else {
                    if (edt_email.getText().toString().equalsIgnoreCase("")) {
                        edt_email.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.placeholder)));
                    } else if (!edt_email.getText().toString().equalsIgnoreCase("")) {
                        edt_email.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                    }
                }
            }
        });

        edt_email.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!edt_email.getText().toString().equalsIgnoreCase("")) {
                    edt_email.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.button)));
                } else {
                    edt_email.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                }
            }
        });
        edt_phone.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (edt_phone.getText().toString().equalsIgnoreCase("")) {
                        edt_phone.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                    } else if (!edt_phone.getText().toString().equalsIgnoreCase("")) {
                        edt_phone.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.button)));
                    }
                } else {
                    if (edt_phone.getText().toString().equalsIgnoreCase("")) {
                        edt_phone.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.placeholder)));
                    } else if (!edt_phone.getText().toString().equalsIgnoreCase("")) {
                        edt_phone.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                    }
                }
            }
        });

        edt_phone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!edt_phone.getText().toString().equalsIgnoreCase("")) {
                    edt_phone.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.button)));
                } else {
                    edt_phone.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                }
            }
        });
        edt_pass.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (edt_pass.getText().toString().equalsIgnoreCase("")) {
                        edt_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                        edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_white, 0);
                    } else if (!edt_pass.getText().toString().equalsIgnoreCase("")) {
                        edt_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.button)));
                        if (pass_view) {
                            edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_hide, 0);
                        } else {
                            edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_view, 0);
                        }
                    }
                } else {
                    if (edt_pass.getText().toString().equalsIgnoreCase("")) {
                        edt_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.placeholder)));
                        edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_white, 0);
                    } else if (!edt_pass.getText().toString().equalsIgnoreCase("")) {
                        edt_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                        if (pass_view) {
                            edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_hide, 0);
                        } else {
                            edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_view, 0);
                        }
                    }
                }
            }
        });

        edt_pass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!edt_pass.getText().toString().equalsIgnoreCase("")) {
                    edt_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.button)));
                    if (pass_view) {
                        edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_hide, 0);
                    } else {
                        edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_view, 0);
                    }
                } else {
                    edt_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                    edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_white, 0);
                }
            }
        });

        edt_pass.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                final int DRAWABLE_LEFT = 0;
                final int DRAWABLE_TOP = 1;
                final int DRAWABLE_RIGHT = 2;
                final int DRAWABLE_BOTTOM = 3;

                if (event.getAction() == MotionEvent.ACTION_UP) {
                    if (event.getRawX() >= (edt_pass.getRight() - edt_pass.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {
                        if (pass_view) {
                            pass_view = false;
                            edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_hide, 0);
                            edt_pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                        } else {
                            pass_view = true;
                            edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_view, 0);
                            edt_pass.setInputType(InputType.TYPE_CLASS_TEXT);
                        }
                        return true;
                    }
                }
                return false;
            }
        });
        edt_con_pass.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (edt_con_pass.getText().toString().equalsIgnoreCase("")) {
                        edt_con_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                        edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_white, 0);
                    } else if (!edt_con_pass.getText().toString().equalsIgnoreCase("")) {
                        edt_con_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.button)));
                        if (con_pass_view) {
                            edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_hide, 0);
                        } else {
                            edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_view, 0);
                        }
                    }
                } else {
                    if (edt_con_pass.getText().toString().equalsIgnoreCase("")) {
                        edt_con_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.placeholder)));
                        edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_white, 0);
                    } else if (!edt_con_pass.getText().toString().equalsIgnoreCase("")) {
                        edt_con_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                        if (con_pass_view) {
                            edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_hide, 0);
                        } else {
                            edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_view, 0);
                        }
                    }
                }
            }
        });

        edt_con_pass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!edt_con_pass.getText().toString().equalsIgnoreCase("")) {
                    edt_con_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.button)));
                    if (con_pass_view) {
                        edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_hide, 0);
                    } else {
                        edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_view, 0);
                    }
                } else {
                    edt_con_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                    edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_white, 0);
                }
            }
        });


        edt_con_pass.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                final int DRAWABLE_LEFT = 0;
                final int DRAWABLE_TOP = 1;
                final int DRAWABLE_RIGHT = 2;
                final int DRAWABLE_BOTTOM = 3;

                if (event.getAction() == MotionEvent.ACTION_UP) {
                    if (event.getRawX() >= (edt_con_pass.getRight() - edt_con_pass.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {
                        if (con_pass_view) {
                            con_pass_view = false;
                            edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_hide, 0);
                            edt_con_pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                        } else {
                            con_pass_view = true;
                            edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_view, 0);
                            edt_con_pass.setInputType(InputType.TYPE_CLASS_TEXT);
                        }
                        return true;
                    }
                }
                return false;
            }
        });

        edt_add.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (edt_add.getText().toString().equalsIgnoreCase("")) {
                        edt_add.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                    } else if (!edt_add.getText().toString().equalsIgnoreCase("")) {
                        edt_add.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.button)));
                    }
                } else {
                    if (edt_add.getText().toString().equalsIgnoreCase("")) {
                        edt_add.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.placeholder)));
                    } else if (!edt_add.getText().toString().equalsIgnoreCase("")) {
                        edt_add.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                    }
                }
            }
        });

        edt_add.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!edt_add.getText().toString().equalsIgnoreCase("")) {
                    edt_add.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.button)));
                } else {
                    edt_add.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                }
            }
        });
        edt_designation.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (edt_designation.getText().toString().equalsIgnoreCase("")) {
                        edt_designation.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                    } else if (!edt_designation.getText().toString().equalsIgnoreCase("")) {
                        edt_designation.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.button)));
                    }
                } else {
                    if (edt_designation.getText().toString().equalsIgnoreCase("")) {
                        edt_designation.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.placeholder)));
                    } else if (!edt_designation.getText().toString().equalsIgnoreCase("")) {
                        edt_designation.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                    }
                }
            }
        });

        edt_designation.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!edt_designation.getText().toString().equalsIgnoreCase("")) {
                    edt_designation.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.button)));
                } else {
                    edt_designation.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.input)));
                }
            }
        });
        edt_con_pass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                edt_con_pass.setError(null);
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!edt_pass.getText().toString().contains(s.toString())) {
                    edt_con_pass.requestFocus();
                    edt_con_pass.setError("password not matched");

                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.profile_image:

                boolean result = Utility.checkPermission(Register.this);
                if (result) {
                    selectImage();
                } else {
                    Toast.makeText(Register.this, "Permission not granted", Toast.LENGTH_LONG).show();
                }
                break;
            case R.id.img_option:
                boolean results = Utility.checkPermission(Register.this);
                if (results) {
                    selectImage();
                } else {
                    Toast.makeText(Register.this, "Permission not granted", Toast.LENGTH_LONG).show();
                }
                break;
            case R.id.txt_submit:
                if (validation()) {
                    create_user();
                }
                break;
            case R.id.txt_login:
                Intent intent = new Intent(Register.this, Login.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                overridePendingTransition(R.anim.slide_in_top, R.anim.stay);
                startActivity(intent);
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        //super.onActivityResult(requestCode, resultCode, data); comment this unless you want to pass your result to the activity.
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_FILE) {
                get_path(data);
            } else if (requestCode == REQUEST_CAMERA) {
                onCaptureImageResult(data);
            }

        }


    }

    public void get_path(Intent data) {
        realPath = null;

        Uri uri = data.getData();
        if (realPath == null) {
            realPath = getRealPathFromURI_BelowAPI11(Register.this, uri);
            if (realPath == null) {
                realPath = getRealPathFromURI_API11to18(Register.this, uri);
                if (realPath == null) {
                    realPath = getRealPathFromURI_API19(Register.this, uri);
                    if (realPath == null) {
                        Toast.makeText(Register.this, "Image Path not getting", Toast.LENGTH_LONG).show();
                    } else {
                        onSelectFromGalleryResult(data, realPath);
                    }
                } else {
                    onSelectFromGalleryResult(data, realPath);
                }
            } else {
                onSelectFromGalleryResult(data, realPath);
            }
        } else {
            onSelectFromGalleryResult(data, realPath);
        }
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);

        File destination = new File(Environment.getExternalStorageDirectory(), System.currentTimeMillis() + ".jpg");
        realPath = destination.toString();
        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        profile_image.setImageBitmap(thumbnail);
    }

    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data, String path) {

        Bitmap bm = null;
        if (data != null) {
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(Register.this.getContentResolver(), data.getData());
                // Log.d(TAG, String.valueOf(bitmap));

                profile_image.setImageBitmap(bitmap);
                /*txt_filename.setText(path.substring(path.lastIndexOf("/") + 1));*/
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @SuppressLint("NewApi")
    public String getRealPathFromURI_API19(Context context, Uri uri) {
        String filePath = "";
        String wholeID = DocumentsContract.getDocumentId(uri);

        // Split at colon, use second item in the array
        String id = wholeID.split(":")[1];

        String[] column = {MediaStore.Images.Media.DATA};

        // where id is equal to
        String sel = MediaStore.Images.Media._ID + "=?";

        Cursor cursor = context.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, column, sel, new String[]{id}, null);

        int columnIndex = cursor.getColumnIndex(column[0]);

        if (cursor.moveToFirst()) {
            filePath = cursor.getString(columnIndex);
        }
        cursor.close();
//        source_file = new File(filePath);
        return filePath;
    }

    @SuppressLint("NewApi")
    public String getRealPathFromURI_API11to18(Context context, Uri contentUri) {
        String[] proj = {MediaStore.Images.Media.DATA};
        String result = null;

        CursorLoader cursorLoader = new CursorLoader(context, contentUri, proj, null, null, null);
        Cursor cursor = cursorLoader.loadInBackground();

        if (cursor != null) {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            result = cursor.getString(column_index);
            cursor.close();
//            source_file = new File(result);
        }
        return result;
    }

    public String getRealPathFromURI_BelowAPI11(Context context, Uri contentUri) {
        String[] proj = {MediaStore.Images.Media.DATA};
        String result = null;
        Cursor cursor = context.getContentResolver().query(contentUri, proj, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        result = cursor.getString(column_index);
        cursor.close();
//        source_file = new File(result);
        return result;
    }

    private void galleryIntent() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);//
        startActivityForResult(Intent.createChooser(intent, "Select File"), SELECT_FILE);
    }

    private void cameraIntent() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, REQUEST_CAMERA);
    }

    private void selectImage() {
        final CharSequence[] items = {"Take Photo", "Choose from Library", "Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
        builder.setTitle("Upload Photo!");
        builder.setCancelable(false);
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                boolean result = Utility.checkPermission(Register.this);

                if (items[item].equals("Take Photo")) {
                    if (result) cameraIntent();

                } else if (items[item].equals("Choose from Library")) {
                    if (result) galleryIntent();

                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    public boolean validation() {
//        String a = edt_c_code.getSelectedCountryCodeWithPlus();

        if (TextUtils.isEmpty(edt_name.getText().toString())) {
            edt_name.requestFocus();
            edt_name.setError("Please fill name");
            return false;
        }
        if ((TextUtils.isEmpty(edt_email.getText().toString())) || (!Patterns.EMAIL_ADDRESS.matcher(edt_email.getText().toString()).matches())) {
            edt_email.requestFocus();
            edt_email.setError("Please fill correct email");
            return false;
        }
        if ((TextUtils.isEmpty(edt_phone.getText().toString())) || (edt_phone.getText().toString().length() < 10)) {
            edt_phone.requestFocus();
            edt_phone.setError("Please fill correct number");
            return false;
        }

        if ((TextUtils.isEmpty(edt_pass.getText().toString())) || (edt_pass.getText().toString().length() < 6)) {
            edt_pass.requestFocus();
            edt_pass.setError("Please fill minimum 6 char.");
            return false;
        }
        if ((TextUtils.isEmpty(edt_con_pass.getText().toString())) || (!edt_con_pass.getText().toString().equalsIgnoreCase(edt_pass.getText().toString()))) {
            edt_con_pass.requestFocus();
            edt_con_pass.setError("Password not matched");
            return false;
        }
        if ((TextUtils.isEmpty(edt_add.getText().toString())) || (edt_add.getText().toString().length() < 6)) {
            edt_add.requestFocus();
            edt_add.setError("Please fill address");
            return false;
        }
        if (TextUtils.isEmpty(edt_designation.getText().toString())) {
            edt_designation.requestFocus();
            edt_designation.setError("Please fill company name");
            return false;
        }
        return true;
    }

    private void create_user() {
        InputMethodManager inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        if (progressDialog != null) progressDialog.show();
        MultipartBody.Builder builder = new MultipartBody.Builder();
        builder.setType(MultipartBody.FORM);

        builder.addFormDataPart("admin_name", edt_name.getText().toString());
        builder.addFormDataPart("admin_email", edt_email.getText().toString());
        builder.addFormDataPart("admin_password", edt_pass.getText().toString());
        builder.addFormDataPart("admin_phone", edt_phone.getText().toString());
        builder.addFormDataPart("admin_address", edt_add.getText().toString());
        builder.addFormDataPart("company_name", edt_designation.getText().toString());

        if (!TextUtils.isEmpty(realPath)) {
            File file = new File(realPath);
            builder.addFormDataPart("adminimageUpload", file.getName(), RequestBody.create(MediaType.parse("multipart/form-data"), file));
        }

        MultipartBody requestBody = builder.build();
        Call<RegisterResponse> call = ApiUtils.getAlterationService().register(requestBody);
        call.enqueue(new Callback<RegisterResponse>() {
            @Override
            public void onResponse(Call<RegisterResponse> call, Response<RegisterResponse> response) {

                /* Toast.makeText(MessageReply.this, "Success " + response.message(), Toast.LENGTH_LONG).show();*/
                try {
                    if (response.code() == 200) {
                        if (response.body().statusCode == 1) {
                            Intent in = new Intent(Register.this, MainActivity.class);
                            in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            overridePendingTransition(R.anim.slide_in_top, R.anim.stay);
                            startActivity(in);

                            Helper.storeLocally(Register.this, "user_id", response.body().data.get(0).userId);
                            Helper.storeLocally(Register.this, "admin_id", response.body().data.get(0).userId);
                            Helper.storeLocally(Register.this, "user_name", response.body().data.get(0).name);
                            Helper.storeLocally(Register.this, "user_email", response.body().data.get(0).email);
                            Helper.storeLocally(Register.this, "user_phone", response.body().data.get(0).phone);
                            Helper.storeLocally(Register.this, "user_designation", "admin");
                            Helper.storeLocally(Register.this, "user_company", response.body().data.get(0).company_names);
                            Helper.storeLocally(Register.this, "user_pic", response.body().data.get(0).profile_image);
                            Helper.storeLocally(Register.this, "user_address", response.body().data.get(0).address);
                        } else {
                            Toast.makeText(Register.this, response.body().message, Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(Register.this, response.body().message, Toast.LENGTH_SHORT).show();
                    }
                    progressDialog.dismiss();
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(Register.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<RegisterResponse> call, Throwable t) {
                Toast.makeText(Register.this, t.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        });
    }

    @Override
    public void onBackPressed() {
        FragmentManager manager = getSupportFragmentManager();
        if (manager.getBackStackEntryCount() > 0) {
            // If there are back-stack entries, leave the FragmentActivity
            // implementation take care of them.
            manager.popBackStack();

        } else {
            // Otherwise, ask user if he wants to leave :)
            if (doubleBackToExitPressedOnce) {
                super.onBackPressed();
                this.finishAffinity();
                return;
            }

            this.doubleBackToExitPressedOnce = true;
            Toast.makeText(this, "Please click back again to exit", Toast.LENGTH_SHORT).show();

            new Handler().postDelayed(new Runnable() {

                @Override
                public void run() {
                    doubleBackToExitPressedOnce = false;
                }
            }, 2000);
        }
    }
}
