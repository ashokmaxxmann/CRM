package co.in.location;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import co.in.location.slider.SlidingTabLayout;

public class NewDeals extends Fragment {

    private ViewPager pager;
    private ViewPagerAdapter adapter;
    private SlidingTabLayout tabs;
    public CharSequence Titles[];// =new CharSequence[3];
    int Numboftabs;
    SharedPreferences sharedpreferences;
    public static final String MyPREFERENCES = "MyPrefs";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.holidays, container, false);
        sharedpreferences = getActivity().getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        if (Helper.getLocalValue(getActivity(), "user_designation").equalsIgnoreCase("admin")) {
            Numboftabs = 3;
            Titles = new CharSequence[3];
            Titles[0] = "Contact_Tab\n Information";
            Titles[1] = "Account_Tab.java\n Information";
            Titles[2] = "Address\n Information";
        } else if (!Helper.getLocalValue(getActivity(), "user_designation").equalsIgnoreCase("admin")) {
            Numboftabs = 2;
            Titles = new CharSequence[2];
            Titles[0] = "HOLIDAYS";
            Titles[1] = "ALL FESTIVAL";
        }

        adapter = new ViewPagerAdapter(getActivity().getSupportFragmentManager(), Titles,
                Numboftabs);

        // Assigning ViewPager View and setting the adapter
        pager = (ViewPager) view.findViewById(R.id.tabLayout);
        pager.setAdapter(adapter);

        // Assiging the Sliding Tab Layout View
        tabs = (SlidingTabLayout) view.findViewById(R.id.tabLayout);
        tabs.setDistributeEvenly(true);
        tabs.setViewPager(pager);

        return view;
    }


    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Deals");
    }
}
