package co.in.location.data;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class UserListData {
    @SerializedName("id")
    @Expose
    public String id;
    @SerializedName("name")
    @Expose
    public String name;
    @SerializedName("email")
    @Expose
    public String email;
    @SerializedName("personal_number")
    @Expose
    public String personal_number;
    @SerializedName("address")
    @Expose
    public String address;
    @SerializedName("designation")
    @Expose
    public String designation;
    @SerializedName("designation_id")
    @Expose
    public String designation_id;
    @SerializedName("department")
    @Expose
    public String departments;
    @SerializedName("department_id")
    @Expose
    public String departments_id;
    @SerializedName("image_path")
    @Expose
    public String image_path;
}
