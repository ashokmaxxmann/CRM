package co.in.location.crm;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import co.in.location.Helper;
import co.in.location.R;
import co.in.location.slider.SlidingTabLayout;

public class LeadCRMDetailsFragment extends Fragment {

    private ViewPager pager;
    private CRMViewPagerAdapter adapter;
    private SlidingTabLayout tabs;
    public CharSequence Titles[];// =new CharSequence[3];
    int Numboftabs;
    public static String id;
    public static int currentpage;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.view_pager, container, false);
        if (Helper.getLocalValue(getActivity(), "user_designation").equalsIgnoreCase("admin")) {
            Numboftabs = 4;
            Titles = new CharSequence[4];
            Titles[0] = "Information";
            Titles[1] = "Analysis";
            Titles[2] = "Actions";
            Titles[3] = "Dialog";
        } else if (!Helper.getLocalValue(getActivity(), "user_designation").equalsIgnoreCase("admin")) {
            Numboftabs = 2;
            Titles = new CharSequence[2];
            Titles[0] = "Information";
            Titles[1] = "Analysis";
        }

        id = getArguments().getString("id");
        currentpage = getArguments().getInt("currentpage");
        adapter = new CRMViewPagerAdapter(getActivity().getSupportFragmentManager(), Titles,
                Numboftabs);

        // Assigning ViewPager View and setting the adapter
        pager = (ViewPager) view.findViewById(R.id.pager);
        pager.setAdapter(adapter);

        // Assiging the Sliding Tab Layout View
        tabs = (SlidingTabLayout) view.findViewById(R.id.tabLayout);
        tabs.setDistributeEvenly(true);
        tabs.setViewPager(pager);

        return view;
    }
}
