package co.in.location.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

import co.in.location.data.LoginData;
import co.in.location.data.RegisterData;

public class RegisterResponse {
    @SerializedName("status")
    @Expose
    public int statusCode;
    @SerializedName("message")
    @Expose
    public String message;
    @SerializedName("data")
    @Expose
    public List<RegisterData> data = new ArrayList<>();
}
