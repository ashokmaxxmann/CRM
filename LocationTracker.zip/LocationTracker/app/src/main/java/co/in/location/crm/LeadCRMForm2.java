package co.in.location.crm;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListPopupWindow;
import android.widget.TextView;

import co.in.location.Helper;
import co.in.location.MainActivity;
import co.in.location.R;

public class LeadCRMForm2 extends Fragment implements View.OnClickListener {
    View view;
    EditText edt_google_reviews, edt_facebook_reviews, edt_justdial_reviews, edt_other_reviews;
    EditText edt_fb_likes, edt_fb_followers, edt_responce_rate, edt_engagement_rate, edt_linkedin_followers;
    TextView txt_next, txt1, txt2, txt3, txt4, txt5, txt6;

    EditText edt_other_google_reviews, edt_other_facebook_reviews, edt_other_justdial_reviews, edt_other_other_reviews;
    EditText edt_other_fb_likes, edt_other_fb_followers, edt_other_responce_rate, edt_other_engagement_rate, edt_other_linkedin_followers;

    private String[] list_google_review = new String[]{"0", "10", "20", "30", "40", "50", "Others"};
    private String[] list_facebook_review = new String[]{"0", "10", "20", "30", "40", "50", "Others"};
    private String[] list_justdial_review = new String[]{"0", "10", "20", "30", "40", "50", "Others"};
    private String[] list_other_review = new String[]{"0", "10", "20", "30", "40", "50", "Others"};

    private String[] list_facebook_like = new String[]{"0", "10", "20", "30", "40", "50", "Others"};
    private String[] list_facebook_followers = new String[]{"0", "10", "20", "30", "40", "50", "Others"};
    private String[] list_response_rate = new String[]{"0", "10", "20", "30", "40", "50", "Others"};
    private String[] list_engagement_rate = new String[]{"0", "10", "20", "30", "40", "50", "Others"};

    private ListPopupWindow pw_google_review;
    private ListPopupWindow pw_facebook_review;
    private ListPopupWindow pw_justdial_review;
    private ListPopupWindow pw_other_review;

    private ListPopupWindow pw_facebook_like;
    private ListPopupWindow pw_facebook_followers;
    private ListPopupWindow pw_response_rate;
    private ListPopupWindow pw_engagement_rate;
    int clickable = 0;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.sales_crm2, container, false);
        LeadCRMList.page2 = true;
        edt_google_reviews = (EditText) view.findViewById(R.id.edt_google_reviews);
        edt_facebook_reviews = (EditText) view.findViewById(R.id.edt_facebook_reviews);
        edt_justdial_reviews = (EditText) view.findViewById(R.id.edt_justdial_reviews);
        edt_other_reviews = (EditText) view.findViewById(R.id.edt_other_reviews);
        edt_fb_likes = (EditText) view.findViewById(R.id.edt_fb_likes);
        edt_fb_followers = (EditText) view.findViewById(R.id.edt_fb_followers);
        edt_responce_rate = (EditText) view.findViewById(R.id.edt_responce_rate);
        edt_engagement_rate = (EditText) view.findViewById(R.id.edt_engagement_rate);
        edt_linkedin_followers = (EditText) view.findViewById(R.id.edt_linkedin_followers);

        edt_other_google_reviews = (EditText) view.findViewById(R.id.edt_other_google_reviews);
        edt_other_facebook_reviews = (EditText) view.findViewById(R.id.edt_other_facebook_reviews);
        edt_other_justdial_reviews = (EditText) view.findViewById(R.id.edt_other_justdial_reviews);
        edt_other_other_reviews = (EditText) view.findViewById(R.id.edt_other_other_reviews);
        edt_other_fb_likes = (EditText) view.findViewById(R.id.edt_other_fb_likes);
        edt_other_fb_followers = (EditText) view.findViewById(R.id.edt_other_fb_followers);
        edt_other_responce_rate = (EditText) view.findViewById(R.id.edt_other_responce_rate);
        edt_other_engagement_rate = (EditText) view.findViewById(R.id.edt_other_engagement_rate);
        edt_other_linkedin_followers = (EditText) view.findViewById(R.id.edt_other_linkedin_followers);


        txt_next = (TextView) view.findViewById(R.id.txt_next);
        txt1 = (TextView) view.findViewById(R.id.txt1);
        txt2 = (TextView) view.findViewById(R.id.txt2);
        txt3 = (TextView) view.findViewById(R.id.txt3);
        txt4 = (TextView) view.findViewById(R.id.txt4);
        txt5 = (TextView) view.findViewById(R.id.txt5);
        txt6 = (TextView) view.findViewById(R.id.txt6);

        pw_google_review = new ListPopupWindow(getActivity());
        pw_google_review.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_google_review));
        pw_google_review.setAnchorView(edt_google_reviews);
        pw_google_review.setModal(true);
        pw_google_review.setHeight(500);
        pw_google_review.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_google_reviews.setText(list_google_review[position]);
                pw_google_review.dismiss();
                edt_other_google_reviews.setText("");
                if (list_google_review[position].equalsIgnoreCase("Others")) {

                    edt_other_google_reviews.setVisibility(View.VISIBLE);
                } else {
                    edt_other_google_reviews.setVisibility(View.GONE);
                }
            }
        });
        pw_facebook_review = new ListPopupWindow(getActivity());
        pw_facebook_review.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_facebook_review));
        pw_facebook_review.setAnchorView(edt_facebook_reviews);
        pw_facebook_review.setModal(true);
        pw_facebook_review.setHeight(500);
        pw_facebook_review.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_facebook_reviews.setText(list_facebook_review[position]);
                pw_facebook_review.dismiss();
                edt_other_facebook_reviews.setText("");
                if (list_facebook_review[position].equalsIgnoreCase("Others")) {

                    edt_other_facebook_reviews.setVisibility(View.VISIBLE);
                } else {
                    edt_other_facebook_reviews.setVisibility(View.GONE);
                }
            }
        });
        pw_justdial_review = new ListPopupWindow(getActivity());
        pw_justdial_review.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_justdial_review));
        pw_justdial_review.setAnchorView(edt_justdial_reviews);
        pw_justdial_review.setModal(true);
        pw_justdial_review.setHeight(500);
        pw_justdial_review.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_justdial_reviews.setText(list_justdial_review[position]);
                pw_justdial_review.dismiss();
                edt_other_justdial_reviews.setText("");
                if (list_justdial_review[position].equalsIgnoreCase("Others")) {

                    edt_other_justdial_reviews.setVisibility(View.VISIBLE);
                } else {
                    edt_other_justdial_reviews.setVisibility(View.GONE);
                }
            }
        });
        pw_other_review = new ListPopupWindow(getActivity());
        pw_other_review.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_other_review));
        pw_other_review.setAnchorView(edt_other_reviews);
        pw_other_review.setModal(true);
        pw_other_review.setHeight(500);
        pw_other_review.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_other_reviews.setText(list_other_review[position]);
                pw_other_review.dismiss();
                edt_other_other_reviews.setText("");
                if (list_other_review[position].equalsIgnoreCase("Others")) {

                    edt_other_other_reviews.setVisibility(View.VISIBLE);
                } else {
                    edt_other_other_reviews.setVisibility(View.GONE);
                }
            }
        });

        pw_facebook_like = new ListPopupWindow(getActivity());
        pw_facebook_like.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_facebook_like));
        pw_facebook_like.setAnchorView(edt_fb_likes);
        pw_facebook_like.setModal(true);
        pw_facebook_like.setHeight(500);
        pw_facebook_like.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_fb_likes.setText(list_facebook_like[position]);
                pw_facebook_like.dismiss();
                edt_other_fb_likes.setText("");
                if (list_facebook_like[position].equalsIgnoreCase("Others")) {

                    edt_other_fb_likes.setVisibility(View.VISIBLE);
                } else {
                    edt_other_fb_likes.setVisibility(View.GONE);
                }
            }
        });
        pw_facebook_followers = new ListPopupWindow(getActivity());
        pw_facebook_followers.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_facebook_followers));
        pw_facebook_followers.setAnchorView(edt_fb_followers);
        pw_facebook_followers.setModal(true);
        pw_facebook_followers.setHeight(500);
        pw_facebook_followers.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_fb_followers.setText(list_facebook_followers[position]);
                pw_facebook_followers.dismiss();
                edt_other_fb_followers.setText("");
                if (list_facebook_followers[position].equalsIgnoreCase("Others")) {

                    edt_other_fb_followers.setVisibility(View.VISIBLE);
                } else {
                    edt_other_fb_followers.setVisibility(View.GONE);
                }
            }
        });
        pw_response_rate = new ListPopupWindow(getActivity());
        pw_response_rate.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_response_rate));
        pw_response_rate.setAnchorView(edt_responce_rate);
        pw_response_rate.setModal(true);
        pw_response_rate.setHeight(500);
        pw_response_rate.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_responce_rate.setText(list_response_rate[position]);
                pw_response_rate.dismiss();
                edt_other_responce_rate.setText("");
                if (list_response_rate[position].equalsIgnoreCase("Others")) {

                    edt_other_responce_rate.setVisibility(View.VISIBLE);
                } else {
                    edt_other_responce_rate.setVisibility(View.GONE);
                }
            }
        });
        pw_engagement_rate = new ListPopupWindow(getActivity());
        pw_engagement_rate.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_engagement_rate));
        pw_engagement_rate.setAnchorView(edt_engagement_rate);
        pw_engagement_rate.setModal(true);
        pw_engagement_rate.setHeight(500);
        pw_engagement_rate.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_engagement_rate.setText(list_engagement_rate[position]);
                pw_engagement_rate.dismiss();
                edt_other_engagement_rate.setText("");
                if (list_engagement_rate[position].equalsIgnoreCase("Others")) {

                    edt_other_engagement_rate.setVisibility(View.VISIBLE);
                } else {
                    edt_other_engagement_rate.setVisibility(View.GONE);
                }
            }
        });


        edt_google_reviews.setOnClickListener(this);
        edt_facebook_reviews.setOnClickListener(this);
        edt_justdial_reviews.setOnClickListener(this);
        edt_other_reviews.setOnClickListener(this);

        edt_fb_likes.setOnClickListener(this);
        edt_fb_followers.setOnClickListener(this);
        edt_responce_rate.setOnClickListener(this);
        edt_engagement_rate.setOnClickListener(this);

        txt_next.setOnClickListener(this);
        txt1.setOnClickListener(this);
        txt2.setOnClickListener(this);
        txt3.setOnClickListener(this);
        txt4.setOnClickListener(this);
        txt5.setOnClickListener(this);
        txt6.setOnClickListener(this);
        if (LeadCRMForm1.from.equalsIgnoreCase("from_update")) {
            LeadCRMFormUpdate.update_page2 = true;
        } else {
            MainActivity.add_page2 = true;
        }
        executeMethode();
        return view;
    }

    @Override
    public void onClick(View v) {
        InputMethodManager inputManager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);

        inputManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        switch (v.getId()) {
            case R.id.txt_next:
                if (validation()) {
                    clickable = 3;
                    data_save();
                }
                break;
            case R.id.edt_google_reviews:
                pw_google_review.show();
                break;
            case R.id.edt_facebook_reviews:
                pw_facebook_review.show();
                break;
            case R.id.edt_justdial_reviews:
                pw_justdial_review.show();
                break;
            case R.id.edt_other_reviews:
                pw_other_review.show();
                break;
            case R.id.edt_fb_likes:
                pw_facebook_like.show();
                break;
            case R.id.edt_fb_followers:
                pw_facebook_followers.show();
                break;
            case R.id.edt_responce_rate:
                pw_response_rate.show();
                break;
            case R.id.edt_engagement_rate:
                pw_engagement_rate.show();
                break;
            case R.id.txt1:
                if (LeadCRMList.page1) {
                    clickable = 1;
                    data_save();
                }
                break;
            case R.id.txt2:
                if (LeadCRMList.page2) {
                    clickable = 2;
                    data_save();
                }
                break;
            case R.id.txt3:
                if (LeadCRMList.page3) {
                    clickable = 3;
                    data_save();
                }
                break;
            case R.id.txt4:
                if (LeadCRMList.page4) {
                    clickable = 4;
                    data_save();
                }
                break;
            case R.id.txt5:
                if (LeadCRMList.page5) {
                    clickable = 5;
                    data_save();
                }
                break;
            case R.id.txt6:
                if (LeadCRMList.page6) {
                    clickable = 6;
                    data_save();
                }
                break;
        }
    }

    public boolean validation() {

        return true;
    }

    public void data_save() {
        Helper.storeLocally(getActivity(), "google_reviews", edt_google_reviews.getText().toString());
        Helper.storeLocally(getActivity(), "google_review_other", edt_other_google_reviews.getText().toString());
        Helper.storeLocally(getActivity(), "Just_Dial_Reviews", edt_justdial_reviews.getText().toString());
        Helper.storeLocally(getActivity(), "just_dial_reviews_other", edt_other_justdial_reviews.getText().toString());
        Helper.storeLocally(getActivity(), "facebook_reviews", edt_facebook_reviews.getText().toString());
        Helper.storeLocally(getActivity(), "facebook_review_other", edt_other_facebook_reviews.getText().toString());
        Helper.storeLocally(getActivity(), "Other_Social_Channel_Reviews", edt_other_reviews.getText().toString());
        Helper.storeLocally(getActivity(), "other_social_channel_review", edt_other_other_reviews.getText().toString());
        Helper.storeLocally(getActivity(), "Fb_likes", edt_fb_likes.getText().toString());
        Helper.storeLocally(getActivity(), "facebook_likes_other", edt_other_fb_likes.getText().toString());
        Helper.storeLocally(getActivity(), "FB_Followers", edt_fb_followers.getText().toString());
        Helper.storeLocally(getActivity(), "facebook_follwers_other", edt_other_fb_followers.getText().toString());
        Helper.storeLocally(getActivity(), "Response_Rate", edt_responce_rate.getText().toString());
        Helper.storeLocally(getActivity(), "response_rate_other", edt_other_responce_rate.getText().toString());
        Helper.storeLocally(getActivity(), "Engagement_Rate", edt_engagement_rate.getText().toString());
        Helper.storeLocally(getActivity(), "engagement_rate_other", edt_other_engagement_rate.getText().toString());
        Helper.storeLocally(getActivity(), "Linkedin_Followers", edt_linkedin_followers.getText().toString());
        if (clickable == 1) {
            Fragment fragment = new LeadCRMForm1();
            Bundle bundle = new Bundle();
            if (LeadCRMForm1.from.equalsIgnoreCase("from_update")) {
                bundle.putString("from", "from_update");
            } else {
                bundle.putString("from", "from_add");
            }
            fragment.setArguments(bundle);
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page1");
            ft.commit();
        } else if (clickable == 2) {

        } else if (clickable == 3) {
            Fragment fragment = new LeadCRMForm3();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page3");
            ft.commit();
        } else if (clickable == 4) {
            Fragment fragment = new LeadCRMForm4();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page4");
            ft.commit();
        } else if (clickable == 5) {
            Fragment fragment = new LeadCRMForm5();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page5");
            ft.commit();
        } else if (clickable == 6) {
            Fragment fragment = new LeadCRMForm6();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page6");
            ft.commit();
        }
    }

    public void executeMethode() {
        edt_google_reviews.setText(Helper.getLocalValue(getActivity(), "google_reviews"));
        if(Helper.getLocalValue(getActivity(), "google_reviews").equalsIgnoreCase("Others"))
        {
            edt_other_google_reviews.setVisibility(View.VISIBLE);
        }
        edt_other_google_reviews.setText(Helper.getLocalValue(getActivity(), "google_review_other"));
        edt_justdial_reviews.setText(Helper.getLocalValue(getActivity(), "Just_Dial_Reviews"));
        if(Helper.getLocalValue(getActivity(), "Just_Dial_Reviews").equalsIgnoreCase("Others"))
        {
            edt_other_justdial_reviews.setVisibility(View.VISIBLE);
        }
        edt_other_justdial_reviews.setText(Helper.getLocalValue(getActivity(), "just_dial_reviews_other"));
        edt_facebook_reviews.setText(Helper.getLocalValue(getActivity(), "facebook_reviews"));
        if(Helper.getLocalValue(getActivity(), "facebook_reviews").equalsIgnoreCase("Others"))
        {
            edt_other_facebook_reviews.setVisibility(View.VISIBLE);
        }
        edt_other_facebook_reviews.setText(Helper.getLocalValue(getActivity(), "facebook_review_other"));
        edt_other_reviews.setText(Helper.getLocalValue(getActivity(), "Other_Social_Channel_Reviews"));
        if(Helper.getLocalValue(getActivity(), "Other_Social_Channel_Reviews").equalsIgnoreCase("Others"))
        {
            edt_other_other_reviews.setVisibility(View.VISIBLE);
        }
        edt_other_other_reviews.setText(Helper.getLocalValue(getActivity(), "other_social_channel_review"));
        edt_fb_likes.setText(Helper.getLocalValue(getActivity(), "Fb_likes"));
        if(Helper.getLocalValue(getActivity(), "Fb_likes").equalsIgnoreCase("Others"))
        {
            edt_other_fb_likes.setVisibility(View.VISIBLE);
        }
        edt_other_fb_likes.setText(Helper.getLocalValue(getActivity(), "facebook_likes_other"));
        edt_fb_followers.setText(Helper.getLocalValue(getActivity(), "FB_Followers"));
        if(Helper.getLocalValue(getActivity(), "FB_Followers").equalsIgnoreCase("Others"))
        {
            edt_other_fb_followers.setVisibility(View.VISIBLE);
        }
        edt_other_fb_followers.setText(Helper.getLocalValue(getActivity(), "facebook_follwers_other"));
        edt_responce_rate.setText(Helper.getLocalValue(getActivity(), "Response_Rate"));
        if(Helper.getLocalValue(getActivity(), "Response_Rate").equalsIgnoreCase("Others"))
        {
            edt_other_responce_rate.setVisibility(View.VISIBLE);
        }
        edt_other_responce_rate.setText(Helper.getLocalValue(getActivity(), "response_rate_other"));
        edt_engagement_rate.setText(Helper.getLocalValue(getActivity(), "Engagement_Rate"));
        if(Helper.getLocalValue(getActivity(), "Engagement_Rate").equalsIgnoreCase("Others"))
        {
            edt_other_engagement_rate.setVisibility(View.VISIBLE);
        }
        edt_other_engagement_rate.setText(Helper.getLocalValue(getActivity(), "engagement_rate_other"));
        edt_linkedin_followers.setText(Helper.getLocalValue(getActivity(), "Linkedin_Followers"));
    }
}
