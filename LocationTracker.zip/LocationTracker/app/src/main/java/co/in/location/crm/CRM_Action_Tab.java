package co.in.location.crm;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.app.AppCompatDialog;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.SectionIndexer;
import android.widget.TextView;
import android.widget.Toast;

import co.in.location.GifImageView;
import co.in.location.Helper;
import co.in.location.R;
import co.in.location.Remote.ApiUtils;
import co.in.location.response.CRMListResponse;
import co.in.location.response.DeleteResponce;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CRM_Action_Tab extends Fragment {
    TextView txt_first_action, txt_first_action_remark, txt_second_action, txt_second_action_remark, txt_third_action, txt_third_action_remark, txt_fourth_action, txt_fourth_action_remark, txt_fifth_action, txt_fifth_action_remark, txt_final_action, txt_final_action_remark;
    TextView txt_proposal_sent_for, txt_proposal_sent_on, txt_total_value, txt_expected_closure_date, txt_proposal_not_sent_for, txt_reason, txt_status;
    String id;
    int currentpage;
    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.crm_action_tab, container, false);
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        txt_first_action = (TextView) view.findViewById(R.id.txt_first_action);
        txt_first_action_remark = (TextView) view.findViewById(R.id.txt_first_action_remark);
        txt_second_action = (TextView) view.findViewById(R.id.txt_second_action);
        txt_second_action_remark = (TextView) view.findViewById(R.id.txt_second_action_remark);
        txt_third_action = (TextView) view.findViewById(R.id.txt_third_action);
        txt_third_action_remark = (TextView) view.findViewById(R.id.txt_third_action_remark);
        txt_fourth_action = (TextView) view.findViewById(R.id.txt_fourth_action);
        txt_fourth_action_remark = (TextView) view.findViewById(R.id.txt_fourth_action_remark);
        txt_fifth_action = (TextView) view.findViewById(R.id.txt_fifth_action);
        txt_fifth_action_remark = (TextView) view.findViewById(R.id.txt_fifth_action_remark);
        txt_final_action = (TextView) view.findViewById(R.id.txt_final_action);
        txt_final_action_remark = (TextView) view.findViewById(R.id.txt_final_action_remark);
        txt_proposal_sent_for = (TextView) view.findViewById(R.id.txt_proposal_sent_for);
        txt_proposal_sent_on = (TextView) view.findViewById(R.id.txt_proposal_sent_on);
        txt_total_value = (TextView) view.findViewById(R.id.txt_total_value);
        txt_expected_closure_date = (TextView) view.findViewById(R.id.txt_expected_closure_date);
        txt_proposal_not_sent_for = (TextView) view.findViewById(R.id.txt_proposal_not_sent_for);
        txt_reason = (TextView) view.findViewById(R.id.txt_reason);
        txt_status = (TextView) view.findViewById(R.id.txt_status);

        id = LeadCRMDetailsFragment.id;
        currentpage = LeadCRMDetailsFragment.currentpage;
        executeMethode();
        return view;
    }

    public void executeMethode() {
        txt_first_action.setText(LeadCRMDetails.respose.crmListData.get(0).First_Actions);
        txt_first_action_remark.setText(LeadCRMDetails.respose.crmListData.get(0).First_Action_Remarks);
        txt_second_action.setText(LeadCRMDetails.respose.crmListData.get(0).Second_Actions);
        txt_second_action_remark.setText(LeadCRMDetails.respose.crmListData.get(0).Second_Action_Remarks);
        txt_third_action.setText(LeadCRMDetails.respose.crmListData.get(0).Third_Actions);
        txt_third_action_remark.setText(LeadCRMDetails.respose.crmListData.get(0).Third_Action_Remarks);
        txt_fourth_action.setText(LeadCRMDetails.respose.crmListData.get(0).Fourth_Actions);
        txt_fourth_action_remark.setText(LeadCRMDetails.respose.crmListData.get(0).Fouth_Action_Remarks);
        txt_fifth_action.setText(LeadCRMDetails.respose.crmListData.get(0).Fifth_Actions);
        txt_fifth_action_remark.setText(LeadCRMDetails.respose.crmListData.get(0).Fifth_Action_Remarks);
        txt_final_action.setText(LeadCRMDetails.respose.crmListData.get(0).Final_Actions);
        txt_final_action_remark.setText(LeadCRMDetails.respose.crmListData.get(0).Final_Action_Remarks);
        txt_proposal_sent_for.setText(LeadCRMDetails.respose.crmListData.get(0).Proposal_Sent_For);
        txt_proposal_sent_on.setText(LeadCRMDetails.respose.crmListData.get(0).Proposal_Sent_On);
        txt_total_value.setText(LeadCRMDetails.respose.crmListData.get(0).Total_value);
        txt_expected_closure_date.setText(LeadCRMDetails.respose.crmListData.get(0).Expected_Closure_Date);
        txt_proposal_not_sent_for.setText(LeadCRMDetails.respose.crmListData.get(0).Proposal_not_sent_for);
        txt_reason.setText(LeadCRMDetails.respose.crmListData.get(0).Reason);
        txt_status.setText(LeadCRMDetails.respose.crmListData.get(0).Status);
    }
}
