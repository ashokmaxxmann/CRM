package co.in.location.admin;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AppCompatDialog;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import co.in.location.BuildConfig;
import co.in.location.GifImageView;
import co.in.location.Helper;
import co.in.location.MainActivity;
import co.in.location.R;
import co.in.location.Remote.ApiUtils;
import co.in.location.response.LiveLocationResponce;
import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LiveLocations extends Fragment implements OnMapReadyCallback {
    View view;
    SupportMapFragment mapFragment;
    GoogleMap gmap;
    //    public static MarkerOptions markerOptions = new MarkerOptions();
    AppCompatDialog progressDialog;
    TextView prog_message, txt_message;
    String currentAddress;
    Activity activity;
    LiveLocationResponce responce;
    double lat = 0.0, lng = 0.0;
    String user_id = "0";
    private HashMap<Marker, String> mHashMap = new HashMap<Marker, String>();


    private static final String TAG = MainActivity.class.getSimpleName();
    private static final long UPDATE_INTERVAL_IN_MILLISECONDS = 1000 * 60 * 2;

    private static final long FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS = 1000 * 60 * 2;
    private static final int REQUEST_CHECK_SETTINGS = 100;
    private FusedLocationProviderClient mFusedLocationClient;
    private SettingsClient mSettingsClient;
    private LocationRequest mLocationRequest;
    private LocationSettingsRequest mLocationSettingsRequest;
    private LocationCallback mLocationCallback;
    private Location mCurrentLocation;
    private Boolean mRequestingLocationUpdates = true;
    public static Double mLatitude = 0.0, mLongitude = 0.0;
    public static MarkerOptions markerOptions = new MarkerOptions();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.activity_current_location, container, false);
        activity = getActivity();
        init();
        mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        txt_message = (TextView) view.findViewById(R.id.txt_message);
        progressDialog = new AppCompatDialog(activity);
        progressDialog.setCancelable(false);
        progressDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progressDialog.setContentView(R.layout.progress_loading);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        prog_message = progressDialog.findViewById(R.id.tv_progress_message);
        prog_message.setText("Please wait..");
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Users Location");
        GifImageView gifImageView = (GifImageView) progressDialog.findViewById(R.id.GifImageView);
        gifImageView.setGifImageResource(R.drawable.loadinggif);

        Dexter.withActivity(activity)
                .withPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                .withListener(new PermissionListener() {
                    @Override
                    public void onPermissionGranted(PermissionGrantedResponse response) {
                        if (mRequestingLocationUpdates) {
                            startLocationUpdates();
                        }
                    }

                    @Override
                    public void onPermissionDenied(PermissionDeniedResponse response) {
                        if (response.isPermanentlyDenied()) {
                            openSettings();
                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).check();


        if (Helper.getLocalValue(getActivity(), "user_designation").equalsIgnoreCase("admin")) {
            user_id = "0";
        } else {
            user_id = Helper.getLocalValue(getActivity(), "user_id");
        }

        getLocations();


        return view;
    }

    private void startLocationUpdates() {
        mSettingsClient
                .checkLocationSettings(mLocationSettingsRequest)
                .addOnSuccessListener(activity, new OnSuccessListener<LocationSettingsResponse>() {
                    @SuppressLint("MissingPermission")
                    @Override
                    public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                        Log.i(TAG, "All location settings are satisfied.");

//                        Toast.makeText(activity, "Started location updates!", Toast.LENGTH_SHORT).show();

                        //noinspection MissingPermission
                        mFusedLocationClient.requestLocationUpdates(mLocationRequest,
                                mLocationCallback, Looper.myLooper());

//                        updateLocationUI();
                    }
                })
                .addOnFailureListener(activity, new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        int statusCode = ((ApiException) e).getStatusCode();
                        switch (statusCode) {
                            case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                                Log.i(TAG, "Location settings are not satisfied. Attempting to upgrade " +
                                        "location settings ");
                                try {
                                    // Show the dialog by calling startResolutionForResult(), and check the
                                    // result in onActivityResult().
                                    ResolvableApiException rae = (ResolvableApiException) e;
                                    rae.startResolutionForResult(activity, REQUEST_CHECK_SETTINGS);
                                } catch (IntentSender.SendIntentException sie) {
                                    Log.i(TAG, "PendingIntent unable to execute request.");
                                }
                                break;
                            case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                                String errorMessage = "Location settings are inadequate, and cannot be " +
                                        "fixed here. Fix in Settings.";
                                Log.e(TAG, errorMessage);

                                Toast.makeText(activity, errorMessage, Toast.LENGTH_LONG).show();
                        }

//                        updateLocationUI();
                    }
                });
    }

    private void init() {
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(activity);
        mSettingsClient = LocationServices.getSettingsClient(activity);

        mLocationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                super.onLocationResult(locationResult);
                // location is received
                mCurrentLocation = locationResult.getLastLocation();
                if(responce!=null)
                {
                    if (responce.locationDataList.size() == 0) {
                        updateLocationUI();
                    }
                }

            }
        };
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(UPDATE_INTERVAL_IN_MILLISECONDS);
        mLocationRequest.setFastestInterval(FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder();
        builder.addLocationRequest(mLocationRequest);
        mLocationSettingsRequest = builder.build();
    }

    public void updateLocationUI() {

        if (mCurrentLocation != null) {
            mLatitude = mCurrentLocation.getLatitude();
            mLongitude = mCurrentLocation.getLongitude();
            LatLng latLng = new LatLng(mLatitude, mLongitude);
            currentAddress = getCompleteAddressString(mLatitude, mLongitude);
            if (gmap != null) {
                gmap.clear();
                if (MainActivity.selected_groupPosition == 3) {

                    Marker m = gmap.addMarker(markerOptions);
                    gmap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 18));
                    gmap.animateCamera(CameraUpdateFactory.zoomTo(18), 1500, null);
                }
            }
        }
    }

    public String getCompleteAddressString(double LATITUDE, double LONGITUDE) {

        Geocoder geocoder;
        List<Address> addresses;
        String address = "";
        geocoder = new Geocoder(activity, Locale.getDefault());

        try {
            addresses = geocoder.getFromLocation(LATITUDE, LONGITUDE, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5


            address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
        } catch (IOException e) {
            e.printStackTrace();
        }
        return address;
    }

    private void openSettings() {
        Intent intent = new Intent();
        intent.setAction(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package",
                BuildConfig.APPLICATION_ID, null);
        intent.setData(uri);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        gmap = googleMap;
        if ((mLatitude != null) && (mRequestingLocationUpdates)) {
            LatLng latLng = new LatLng(mLatitude, mLongitude);
            markerOptions.position(latLng);
            if (gmap != null) {
                gmap.clear();
                gmap.addMarker(markerOptions);
                gmap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 18));
                gmap.animateCamera(CameraUpdateFactory.zoomTo(18), 1500, null);
            }
        }
        gmap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
            @Override
            public void onInfoWindowClick(Marker marker) {
                // TODO
                String id = mHashMap.get(marker);
                Intent in = new Intent(getActivity(), LocationHistory.class);
                in.putExtra("user_id", id);
                startActivity(in);
            }
        });

/*
        gmap.setOnMapLoadedCallback(new GoogleMap.OnMapLoadedCallback() {
            @Override
            public void onMapLoaded() {

                LatLng customMarkerLocationOne = new LatLng(28.583911, 77.319116);
                LatLng customMarkerLocationTwo = new LatLng(28.583078, 77.313744);
                LatLng customMarkerLocationThree = new LatLng(28.580903, 77.317408);
                LatLng customMarkerLocationFour = new LatLng(28.580108, 77.315271);
                gmap.addMarker(new MarkerOptions().position(customMarkerLocationOne).
                        icon(BitmapDescriptorFactory.fromBitmap(
                                createCustomMarker(getActivity(), R.drawable.user_profile, "Manish")))).setTitle("iPragmatech Solutions Pvt Lmt");
                gmap.addMarker(new MarkerOptions().position(customMarkerLocationTwo).
                        icon(BitmapDescriptorFactory.fromBitmap(
                                createCustomMarker(getActivity(), R.drawable.user_profile, "Narender")))).setTitle("Hotel Nirulas Noida");

                gmap.addMarker(new MarkerOptions().position(customMarkerLocationThree).
                        icon(BitmapDescriptorFactory.fromBitmap(
                                createCustomMarker(getActivity(), R.drawable.user_profile, "Neha")))).setTitle("Acha Khao Acha Khilao");
                gmap.addMarker(new MarkerOptions().position(customMarkerLocationFour).
                        icon(BitmapDescriptorFactory.fromBitmap(
                                createCustomMarker(getActivity(), R.drawable.user_profile, "Nupur")))).setTitle("Subway Sector 16 Noida");

                //LatLngBound will cover all your marker on Google Maps
                LatLngBounds.Builder builder = new LatLngBounds.Builder();
                builder.include(customMarkerLocationOne); //Taking Point A (First LatLng)
                builder.include(customMarkerLocationThree); //Taking Point B (Second LatLng)
                LatLngBounds bounds = builder.build();
                CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, 200);
                gmap.moveCamera(cu);
                gmap.animateCamera(CameraUpdateFactory.zoomTo(14), 2000, null);
            }
        });
*/
    }

    private void getLocations() {
        ApiUtils.getAlterationService().liveLocation("current_location_listing", user_id).enqueue(new Callback<LiveLocationResponce>() {
            @Override
            public void onResponse(Call<LiveLocationResponce> call, Response<LiveLocationResponce> response) {
                try {
                    if (response.code() == 200) {
                        if (response.body().statusCode == 1) {
                            if (response.body() != null) {
                                responce = response.body();
                                loadingComplete();
                            } else {
                                Toast.makeText(getActivity(), response.body().message, Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(getActivity(), response.body().message, Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LiveLocationResponce> call, Throwable t) {
                t.printStackTrace();
                Toast.makeText(getActivity(), call.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void loadingComplete() {
        if (responce.locationDataList.size() > 0) {
            gmap.clear();
            txt_message.setVisibility(View.GONE);
            for (int i = 0; i < responce.locationDataList.size(); i++) {
                if ((!responce.locationDataList.get(i).latitude.equalsIgnoreCase("")) && (!responce.locationDataList.get(i).longitude.equalsIgnoreCase(""))) {
                    lat = Double.parseDouble(responce.locationDataList.get(i).latitude);
                    lng = Double.parseDouble(responce.locationDataList.get(i).longitude);
                    LatLng latLng = new LatLng(lat, lng);
                    currentAddress = getCompleteAddressString(lat, lng);
                    /*markerOptions.title(currentAddress);
                    markerOptions.snippet(responce.locationDataList.get(i).name);
                    markerOptions.visible(true);
                    markerOptions.position(latLng);
                    Marker m = gmap.addMarker(markerOptions);*/
                    Marker marker = gmap.addMarker(new MarkerOptions().position(latLng).snippet(capitalize(responce.locationDataList.get(i).name)).icon(BitmapDescriptorFactory.fromBitmap(
                            createCustomMarker(getActivity(), responce.locationDataList.get(i).profile_image, responce.locationDataList.get(i).name))).title(currentAddress));

                    mHashMap.put(marker, responce.locationDataList.get(i).user_id);
                    //                  gmap.addMarker(new MarkerOptions().position(latLng).icon(BitmapDescriptorFactory.fromBitmap(
//                            createCustomMarker(getActivity(), R.mipmap.profile_picashok, responce.locationDataList.get(i).name)))).setTitle(currentAddress);
                    if (i == 0) {
                        gmap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15));
                        gmap.animateCamera(CameraUpdateFactory.zoomTo(15), 1500, null);
                    }
                }
            }
        } else {
            txt_message.setVisibility(View.VISIBLE);
        }
    }

    public Bitmap createCustomMarker(Activity activity, String image_url, String _name) {

        View marker = ((LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.custom_marker_layout, null);

        CircleImageView markerImage = (CircleImageView) marker.findViewById(R.id.user_dp);
//        markerImage.setImageResource(resource);

        if(!TextUtils.isEmpty(image_url))
        {
            Picasso.with(activity).load(image_url).networkPolicy(NetworkPolicy.NO_CACHE).into(markerImage);
        } else {
            Picasso.with(activity).load(R.mipmap.profilepic).into(markerImage);

        }

        TextView txt_name = (TextView) marker.findViewById(R.id.name);
        txt_name.setText(_name);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity) activity).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        marker.setLayoutParams(new ViewGroup.LayoutParams(52, ViewGroup.LayoutParams.WRAP_CONTENT));
        marker.measure(displayMetrics.widthPixels, displayMetrics.heightPixels);
        marker.layout(0, 0, displayMetrics.widthPixels, displayMetrics.heightPixels);
        marker.buildDrawingCache();
        Bitmap bitmap = Bitmap.createBitmap(marker.getMeasuredWidth(), marker.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        marker.draw(canvas);
        return bitmap;
    }
    private String capitalize(String capString) {
        StringBuffer capBuffer = new StringBuffer();
        Matcher capMatcher = Pattern.compile("([a-z])([a-z]*)", Pattern.CASE_INSENSITIVE).matcher(capString);
        while (capMatcher.find()) {
            capMatcher.appendReplacement(capBuffer, capMatcher.group(1).toUpperCase() + capMatcher.group(2).toLowerCase());
        }
        return capMatcher.appendTail(capBuffer).toString();
    }

}