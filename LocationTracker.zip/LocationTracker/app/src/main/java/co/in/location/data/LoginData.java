package co.in.location.data;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class LoginData {
    @SerializedName("id")
    @Expose
    public String userId;
    @SerializedName("name")
    @Expose
    public String name;
    @SerializedName("email")
    @Expose
    public String email;
    @SerializedName("personal_number")
    @Expose
    public String personal_number;
    @SerializedName("address")
    @Expose
    public String address;
    @SerializedName("designation")
    @Expose
    public String designation;
    @SerializedName("designation_id")
    @Expose
    public String designation_id;
    @SerializedName("department")
    @Expose
    public String department;
    @SerializedName("department_id")
    @Expose
    public String department_id;
    @SerializedName("image_path")
    @Expose
    public String image_path;
}
