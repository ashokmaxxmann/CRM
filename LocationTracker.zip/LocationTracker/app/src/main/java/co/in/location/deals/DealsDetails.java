package co.in.location.deals;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatDelegate;
import android.support.v7.app.AppCompatDialog;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import co.in.location.GifImageView;
import co.in.location.Helper;
import co.in.location.R;
import co.in.location.Remote.ApiUtils;
import co.in.location.crm.LeadCRMFormUpdate;
import co.in.location.crm.LeadCRMList;
import co.in.location.response.CRMListResponse;
import co.in.location.response.DeleteResponce;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DealsDetails extends AppCompatActivity {
    String id;
    int currentpage;
    AppCompatDialog progressDialog;
    TextView prog_message;
    public static CRMListResponse respose;
    public static DealsDetails leadCRMDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.deals_details);
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Deals Details");

        progressDialog = new AppCompatDialog(DealsDetails.this);
        progressDialog.setCancelable(false);
        progressDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progressDialog.setContentView(R.layout.progress_loading);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        prog_message = progressDialog.findViewById(R.id.tv_progress_message);
        prog_message.setText("Please wait..");
        GifImageView gifImageView = (GifImageView) progressDialog.findViewById(R.id.GifImageView);
        gifImageView.setGifImageResource(R.drawable.loadinggif);

        Intent in = getIntent();
        id = in.getStringExtra("id");
        currentpage = in.getIntExtra("currentpage", 0);
        leadCRMDetails = this;
        getDetails();
    }

    private void getDetails() {
        if (progressDialog != null) progressDialog.show();
        ApiUtils.getAlterationService().getCRMLeadDetails("leads-details", id).enqueue(new Callback<CRMListResponse>() {
            @Override
            public void onResponse(Call<CRMListResponse> call, Response<CRMListResponse> response) {
                try {
                    if (response.code() == 200) {
                        if (response.body().statusCode == 1) {
                            if (response.body() != null) {
                                respose = response.body();
                                Fragment fragment = new DealsFragment();
                                Bundle bundle = new Bundle();
                                bundle.putString("id", id);
                                bundle.putInt("currentpage", currentpage);
                                fragment.setArguments(bundle);
                                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                                ft.replace(R.id.frame, fragment);
                                ft.commit();
                            } else {

                                Toast.makeText(DealsDetails.this, response.body().message, Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(DealsDetails.this, response.body().message, Toast.LENGTH_SHORT).show();
                        }
                    }
                    progressDialog.dismiss();
                } catch (Exception e) {
                    progressDialog.dismiss();
                    e.printStackTrace();
                    Toast.makeText(DealsDetails.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<CRMListResponse> call, Throwable t) {
                progressDialog.dismiss();
                t.printStackTrace();
                Toast.makeText(DealsDetails.this, call.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        menu.getItem(0).setVisible(true);
        menu.getItem(1).getSubMenu().getItem(0).setVisible(false);
        return true;
    }

    private void delete_lead() {
        if (progressDialog != null) progressDialog.show();
        ApiUtils.getAlterationService().delete_lead("leads-delete", Helper.getLocalValue(DealsDetails.this, "user_id"), currentpage, respose.crmListData.get(0).id).enqueue(new Callback<DeleteResponce>() {
            @Override
            public void onResponse(Call<DeleteResponce> call, Response<DeleteResponce> response) {
                try {
                    if (response.code() == 200) {
                        if (response.body().statusCode == 1) {
                            if (response.body() != null) {
                                Toast.makeText(DealsDetails.this, response.body().message, Toast.LENGTH_SHORT).show();
                                LeadCRMList.deleteLead = true;
                                DealsDetails.this.finish();
                            } else {

                                Toast.makeText(DealsDetails.this, response.body().message, Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(DealsDetails.this, response.body().message, Toast.LENGTH_SHORT).show();
                        }
                    }
                    progressDialog.dismiss();
                } catch (Exception e) {
                    progressDialog.dismiss();
                    e.printStackTrace();
                    Toast.makeText(DealsDetails.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<DeleteResponce> call, Throwable t) {
                progressDialog.dismiss();
                t.printStackTrace();
                Toast.makeText(DealsDetails.this, call.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // todo: goto back activity from here
                DealsDetails.this.finish();
                return true;

            case R.id.edit_menu:
                LeadCRMList.page1 = true;
                LeadCRMList.page2 = true;
                LeadCRMList.page3 = true;
                LeadCRMList.page4 = true;
                LeadCRMList.page5 = true;
                LeadCRMList.page6 = true;
                dataSave();
                return true;
            case R.id.option_menu:
                return true;
            case R.id.delete:
                delete_lead();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void dataSave() {
        Helper.storeLocally(DealsDetails.this, "number", respose.crmListData.get(0).number);
        Helper.storeLocally(DealsDetails.this, "first_name", respose.crmListData.get(0).f_name);
        Helper.storeLocally(DealsDetails.this, "last_name", respose.crmListData.get(0).l_name);
        Helper.storeLocally(DealsDetails.this, "company_name", respose.crmListData.get(0).company);
        Helper.storeLocally(DealsDetails.this, "title", respose.crmListData.get(0).title);
        Helper.storeLocally(DealsDetails.this, "city_name", respose.crmListData.get(0).city);
        Helper.storeLocally(DealsDetails.this, "address", respose.crmListData.get(0).address);
        Helper.storeLocally(DealsDetails.this, "loction_name", respose.crmListData.get(0).location);
        Helper.storeLocally(DealsDetails.this, "state", respose.crmListData.get(0).state);
        Helper.storeLocally(DealsDetails.this, "pincode", respose.crmListData.get(0).pincode);
        Helper.storeLocally(DealsDetails.this, "phone", respose.crmListData.get(0).phone);
        Helper.storeLocally(DealsDetails.this, "mobile", respose.crmListData.get(0).mobile);
        Helper.storeLocally(DealsDetails.this, "additonal_contact", respose.crmListData.get(0).additonal_contact);
        Helper.storeLocally(DealsDetails.this, "email", respose.crmListData.get(0).email);
        Helper.storeLocally(DealsDetails.this, "lead_source", respose.crmListData.get(0).lead_source);
        Helper.storeLocally(DealsDetails.this, "lead_source_other", respose.crmListData.get(0).lead_source_other);
        Helper.storeLocally(DealsDetails.this, "no_employee", respose.crmListData.get(0).no_employee);
        Helper.storeLocally(DealsDetails.this, "annual_revenue", respose.crmListData.get(0).annual_revenue);
        Helper.storeLocally(DealsDetails.this, "industry", respose.crmListData.get(0).industry);
        Helper.storeLocally(DealsDetails.this, "industry_other", respose.crmListData.get(0).industry_other);
        Helper.storeLocally(DealsDetails.this, "lead_owner", respose.crmListData.get(0).lead_owner);
        Helper.storeLocally(DealsDetails.this, "sales_person", respose.crmListData.get(0).sales_person);


        Helper.storeLocally(DealsDetails.this, "google_reviews", respose.crmListData.get(0).google_reviews);
        Helper.storeLocally(DealsDetails.this, "google_review_other", respose.crmListData.get(0).google_review_other);
        Helper.storeLocally(DealsDetails.this, "Just_Dial_Reviews", respose.crmListData.get(0).Just_Dial_Reviews);
        Helper.storeLocally(DealsDetails.this, "just_dial_reviews_other", respose.crmListData.get(0).just_dial_reviews_other);
        Helper.storeLocally(DealsDetails.this, "facebook_reviews", respose.crmListData.get(0).facebook_reviews);
        Helper.storeLocally(DealsDetails.this, "facebook_review_other", respose.crmListData.get(0).facebook_review_other);
        Helper.storeLocally(DealsDetails.this, "Other_Social_Channel_Reviews", respose.crmListData.get(0).Other_Social_Channel_Reviews);
        Helper.storeLocally(DealsDetails.this, "other_social_channel_review", respose.crmListData.get(0).other_social_channel_review);
        Helper.storeLocally(DealsDetails.this, "Fb_likes", respose.crmListData.get(0).Fb_likes);
        Helper.storeLocally(DealsDetails.this, "facebook_likes_other", respose.crmListData.get(0).facebook_likes_other);
        Helper.storeLocally(DealsDetails.this, "FB_Followers", respose.crmListData.get(0).FB_Followers);
        Helper.storeLocally(DealsDetails.this, "facebook_follwers_other", respose.crmListData.get(0).facebook_follwers_other);
        Helper.storeLocally(DealsDetails.this, "Response_Rate", respose.crmListData.get(0).Response_Rate);
        Helper.storeLocally(DealsDetails.this, "response_rate_other", respose.crmListData.get(0).response_rate_other);
        Helper.storeLocally(DealsDetails.this, "Engagement_Rate", respose.crmListData.get(0).Engagement_Rate);
        Helper.storeLocally(DealsDetails.this, "engagement_rate_other", respose.crmListData.get(0).engagement_rate_other);
        Helper.storeLocally(DealsDetails.this, "Linkedin_Followers", respose.crmListData.get(0).Linkedin_Followers);

        Helper.storeLocally(DealsDetails.this, "Website", respose.crmListData.get(0).Website);
        Helper.storeLocally(DealsDetails.this, "website_other", respose.crmListData.get(0).website_other);
        Helper.storeLocally(DealsDetails.this, "Website_Technology", respose.crmListData.get(0).Website_Technology);
        Helper.storeLocally(DealsDetails.this, "website_technology_other", respose.crmListData.get(0).website_technology_other);
        Helper.storeLocally(DealsDetails.this, "Website_information", respose.crmListData.get(0).Website_information);
        Helper.storeLocally(DealsDetails.this, "Website_Type", respose.crmListData.get(0).Website_Type);
        Helper.storeLocally(DealsDetails.this, "website_type_other", respose.crmListData.get(0).website_type_other);
        Helper.storeLocally(DealsDetails.this, "Overlook_and_Feels", respose.crmListData.get(0).Overlook_and_Feels);
        Helper.storeLocally(DealsDetails.this, "overlook_and_feel_other", respose.crmListData.get(0).overlook_and_feel_other);
        Helper.storeLocally(DealsDetails.this, "Website_Language", respose.crmListData.get(0).Website_Language);
        Helper.storeLocally(DealsDetails.this, "website_language_other", respose.crmListData.get(0).website_language_other);
        Helper.storeLocally(DealsDetails.this, "Content_Quality", respose.crmListData.get(0).Content_Quality);
        Helper.storeLocally(DealsDetails.this, "content_quality_other", respose.crmListData.get(0).content_quality_other);
        Helper.storeLocally(DealsDetails.this, "Graphic_Quality", respose.crmListData.get(0).Graphic_Quality);
        Helper.storeLocally(DealsDetails.this, "graphic_quality_other", respose.crmListData.get(0).graphic_quality_other);
        Helper.storeLocally(DealsDetails.this, "Global_Rank", respose.crmListData.get(0).Global_Rank);
        Helper.storeLocally(DealsDetails.this, "global_rank_other", respose.crmListData.get(0).global_rank_other);
        Helper.storeLocally(DealsDetails.this, "total_score", respose.crmListData.get(0).total_score);


        Helper.storeLocally(DealsDetails.this, "Ranking_Keyword_1", respose.crmListData.get(0).Ranking_Keyword_1);
        Helper.storeLocally(DealsDetails.this, "Global_Rank_Keyword_1", respose.crmListData.get(0).Global_Rank_Keyword_1);
        Helper.storeLocally(DealsDetails.this, "Ranking_Keyword_2", respose.crmListData.get(0).Ranking_Keyword_2);
        Helper.storeLocally(DealsDetails.this, "Global_Rank_Keyword_2", respose.crmListData.get(0).Global_Rank_Keyword_2);
        Helper.storeLocally(DealsDetails.this, "Ranking_Keyword_3", respose.crmListData.get(0).Ranking_Keyword_3);
        Helper.storeLocally(DealsDetails.this, "Global_Rank_Keyword_3", respose.crmListData.get(0).Global_Rank_Keyword_3);
        Helper.storeLocally(DealsDetails.this, "Ranking_Keyword_4", respose.crmListData.get(0).Ranking_Keyword_4);
        Helper.storeLocally(DealsDetails.this, "Global_Rank_Keyword_4", respose.crmListData.get(0).Global_Rank_Keyword_4);
        Helper.storeLocally(DealsDetails.this, "Ranking_Keyword_5", respose.crmListData.get(0).Ranking_Keyword_5);
        Helper.storeLocally(DealsDetails.this, "Global_Rank_Keyword_5", respose.crmListData.get(0).Global_Rank_Keyword_5);
        Helper.storeLocally(DealsDetails.this, "Ranking_Keyword_6", respose.crmListData.get(0).Ranking_Keyword_6);
        Helper.storeLocally(DealsDetails.this, "Global_Rank_Keyword_6", respose.crmListData.get(0).Global_Rank_Keyword_6);
        Helper.storeLocally(DealsDetails.this, "Ranking_Keyword_7", respose.crmListData.get(0).Ranking_Keyword_7);
        Helper.storeLocally(DealsDetails.this, "Global_Rank_Keyword_7", respose.crmListData.get(0).Global_Rank_Keyword_7);


        Helper.storeLocally(DealsDetails.this, "First_Actions", respose.crmListData.get(0).First_Actions);
        Helper.storeLocally(DealsDetails.this, "first_action_other", respose.crmListData.get(0).first_action_other);
        Helper.storeLocally(DealsDetails.this, "First_Action_Remarks", respose.crmListData.get(0).First_Action_Remarks);
        Helper.storeLocally(DealsDetails.this, "first_action_remarks_other", respose.crmListData.get(0).first_action_remarks_other);
        Helper.storeLocally(DealsDetails.this, "Second_Actions", respose.crmListData.get(0).Second_Actions);
        Helper.storeLocally(DealsDetails.this, "second_action_other", respose.crmListData.get(0).second_action_other);
        Helper.storeLocally(DealsDetails.this, "Second_Action_Remarks", respose.crmListData.get(0).Second_Action_Remarks);
        Helper.storeLocally(DealsDetails.this, "second_action_remarks_other", respose.crmListData.get(0).second_action_remarks_other);
        Helper.storeLocally(DealsDetails.this, "Third_Actions", respose.crmListData.get(0).Third_Actions);
        Helper.storeLocally(DealsDetails.this, "third_action_other", respose.crmListData.get(0).third_action_other);
        Helper.storeLocally(DealsDetails.this, "Third_Action_Remarks", respose.crmListData.get(0).Third_Action_Remarks);
        Helper.storeLocally(DealsDetails.this, "third_action_remarks_other", respose.crmListData.get(0).third_action_remarks_other);
        Helper.storeLocally(DealsDetails.this, "Fourth_Actions", respose.crmListData.get(0).Fourth_Actions);
        Helper.storeLocally(DealsDetails.this, "fourth_action_other", respose.crmListData.get(0).fourth_action_other);
        Helper.storeLocally(DealsDetails.this, "Fouth_Action_Remarks", respose.crmListData.get(0).Fouth_Action_Remarks);
        Helper.storeLocally(DealsDetails.this, "fourth_action_remarks_other", respose.crmListData.get(0).fourth_action_remarks_other);
        Helper.storeLocally(DealsDetails.this, "Fifth_Actions", respose.crmListData.get(0).Fifth_Actions);
        Helper.storeLocally(DealsDetails.this, "fifth_action_other", respose.crmListData.get(0).fifth_action_other);
        Helper.storeLocally(DealsDetails.this, "Fifth_Action_Remarks", respose.crmListData.get(0).Fifth_Action_Remarks);
        Helper.storeLocally(DealsDetails.this, "fifth_action_remarks_other", respose.crmListData.get(0).fifth_action_remarks_other);
        Helper.storeLocally(DealsDetails.this, "Final_Actions", respose.crmListData.get(0).Final_Actions);
        Helper.storeLocally(DealsDetails.this, "final_action_other", respose.crmListData.get(0).final_action_other);
        Helper.storeLocally(DealsDetails.this, "Final_Action_Remarks", respose.crmListData.get(0).Final_Action_Remarks);
        Helper.storeLocally(DealsDetails.this, "final_action_remarks_other", respose.crmListData.get(0).final_action_remarks_other);


        Helper.storeLocally(DealsDetails.this, "Proposal_Sent_For", respose.crmListData.get(0).Proposal_Sent_For);
        Helper.storeLocally(DealsDetails.this, "proposal_sent_for_other", respose.crmListData.get(0).proposal_sent_for_other);
        Helper.storeLocally(DealsDetails.this, "Proposal_Sent_On", respose.crmListData.get(0).Proposal_Sent_On);
        Helper.storeLocally(DealsDetails.this, "Total_value", respose.crmListData.get(0).Total_value);
        Helper.storeLocally(DealsDetails.this, "Expected_Closure_Date", respose.crmListData.get(0).Expected_Closure_Date);
        Helper.storeLocally(DealsDetails.this, "Proposal_not_sent_for", respose.crmListData.get(0).Proposal_not_sent_for);
        Helper.storeLocally(DealsDetails.this, "proposal_not_sent_for_other", respose.crmListData.get(0).proposal_not_sent_for_other);
        Helper.storeLocally(DealsDetails.this, "Reason", respose.crmListData.get(0).Reason);
        Helper.storeLocally(DealsDetails.this, "reason_other", respose.crmListData.get(0).reason_other);
        Helper.storeLocally(DealsDetails.this, "Status", respose.crmListData.get(0).Status);
        Helper.storeLocally(DealsDetails.this, "status_other", respose.crmListData.get(0).status_other);

        Intent in = new Intent(DealsDetails.this, LeadCRMFormUpdate.class);
        startActivity(in);
    }

}
