package co.in.location.data;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CRMData {
    @SerializedName("id")
    @Expose
    public String id;
    @SerializedName("f_name")
    @Expose
    public String f_name;
    @SerializedName("l_name")
    @Expose
    public String l_name;
    @SerializedName("lead_source")
    @Expose
    public String lead_source;
    @SerializedName("sales_person")
    @Expose
    public String sales_person;
    @SerializedName("lead_owner")
    @Expose
    public String lead_owner;

}
