package co.in.location.user;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.ListPopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import co.in.location.Helper;
import co.in.location.R;
import co.in.location.Remote.ApiUtils;
import co.in.location.data.LocationData;
import co.in.location.data.UserListData;
import co.in.location.response.Location_history_Response;
import co.in.location.response.LoginResponse;
import co.in.location.response.UserListResponse;
import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserLocationHistory extends Fragment implements View.OnClickListener {
    RecyclerView recyclerView;
    ImageView img_calendar, img_back_arrow, img_next_arrow;
    TextView txt_message, txt_calendar;
    MyCustomAdapter adapter;
    private int mYear, mMonth, mDay;
    public List<LocationData> locationData_datewise = new ArrayList<LocationData>();
    Location_history_Response history_response;
    int date_position = 0;
    int start_position = 0;
    boolean match = false;
    RelativeLayout rl_calender, title;
    View view;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.activity_location_history, container, false);
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        recyclerView = (RecyclerView) view.findViewById(R.id.location_history_list);
        txt_message = (TextView) view.findViewById(R.id.txt_message);
        txt_calendar = (TextView) view.findViewById(R.id.txt_calendar);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setNestedScrollingEnabled(true);
        img_calendar = (ImageView) view.findViewById(R.id.img_calendar);
        img_back_arrow = (ImageView) view.findViewById(R.id.img_back_arrow);
        img_next_arrow = (ImageView) view.findViewById(R.id.img_next_arrow);
        rl_calender = (RelativeLayout) view.findViewById(R.id.rl_calender);
        title = (RelativeLayout) view.findViewById(R.id.title);
        title.setVisibility(View.GONE);
        img_calendar.setOnClickListener(this);
        img_back_arrow.setOnClickListener(this);
        img_next_arrow.setOnClickListener(this);
        txt_calendar.setOnClickListener(this);
        getlocation_history();
        Calendar c = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        txt_calendar.setText(sdf.format(c.getTime()));
        return view;
    }

    @Override
    public void onClick(View v) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        String dt;
        Calendar c;
        switch (v.getId()) {
            case R.id.txt_calendar:
                date();
                break;
            case R.id.img_calendar:
                date();
                break;
            case R.id.img_back_arrow:
                date_position = 0;
                try {
                    for (int j = 0; j < history_response.locationData.size(); j++) {
                        Date date1 = sdf.parse(txt_calendar.getText().toString());//2018-06-09 12:12:24
                        Date date2 = sdf.parse(history_response.locationData.get(j).date);
                        if (date1.compareTo(date2) == 0) {
                            match = true;
                            date_position--;
                        } else {
                            if (match) {
                                date_position = j;
                                match = false;
                                break;
                            }
                        }
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                if (date_position > 0) {
                    dt = txt_calendar.getText().toString();  // Start date
                    c = Calendar.getInstance();
                    try {
                        c.setTime(sdf.parse(dt));
                        locationData_datewise.clear();
                        for (int i = 0; i < history_response.locationData.size(); i++) {
                            Date date1 = sdf.parse(history_response.locationData.get(date_position).date);//2018-06-09 12:12:24
                            Date date2 = sdf.parse(history_response.locationData.get(i).date);
                            if (date1.compareTo(date2) == 0) {
                                locationData_datewise.add(history_response.locationData.get(i));
                            }
                        }

                        adapter = new MyCustomAdapter(locationData_datewise);// new MyCustomAdapter(SocialAccount.this, response.body().socialdata);
                        recyclerView.setAdapter(adapter);


                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    c.add(Calendar.DATE, -1);  // number of days to add, can also use Calendar.DAY_OF_MONTH in place of Calendar.DATE
                    txt_calendar.setText(locationData_datewise.get(0).date.substring(0, 11));
                } else {
                    Toast.makeText(getActivity(), "No record exist on previous date", Toast.LENGTH_SHORT).show();
                }


                break;
            case R.id.img_next_arrow:
                date_position = 0;
                match = false;
                try {
                    for (int j = 0; j < history_response.locationData.size(); j++) {
                        Date date1 = sdf.parse(txt_calendar.getText().toString());//2018-06-09 12:12:24
                        Date date2 = sdf.parse(history_response.locationData.get(j).date);
                        if (date1.compareTo(date2) == 0) {
                            date_position = j - 1;
                            break;
                        }
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                if (date_position > 0) {
                    dt = txt_calendar.getText().toString();  // Start date
                    c = Calendar.getInstance();
                    try {
                        c.setTime(sdf.parse(dt));

                        locationData_datewise.clear();
                        for (int i = 0; i < history_response.locationData.size(); i++) {
                            Date date1 = sdf.parse(history_response.locationData.get(date_position).date);//2018-06-09 12:12:24
                            Date date2 = sdf.parse(history_response.locationData.get(i).date);
                            if (date1.compareTo(date2) == 0) {
                                locationData_datewise.add(history_response.locationData.get(i));
                            }
                        }

                        adapter = new MyCustomAdapter(locationData_datewise);// new MyCustomAdapter(SocialAccount.this, response.body().socialdata);
                        recyclerView.setAdapter(adapter);


                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    c.add(Calendar.DATE, 1);  // number of days to add, can also use Calendar.DAY_OF_MONTH in place of Calendar.DATE
                    txt_calendar.setText(locationData_datewise.get(0).date.substring(0, 11));
                } else {
                    date_position = start_position;
                    Toast.makeText(getActivity(), "No record exist on next date", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    public void date() {
        long timeInMilliseconds = 0;
        String date = txt_calendar.getText().toString();
        mYear = Integer.parseInt(date.substring(6, 10));
        mMonth = Integer.parseInt(date.substring(3, 5));
        mDay = Integer.parseInt(date.substring(0, 2));

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, mYear);
        calendar.set(Calendar.MONTH, mMonth);
        calendar.set(Calendar.DAY_OF_YEAR, mDay);


        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(),
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
                        String dt;
                        dt = ((dayOfMonth) < 10 ? ("0" + (dayOfMonth)) : (dayOfMonth)) + "-" + ((monthOfYear + 1) < 10 ? ("0" + (monthOfYear + 1)) : (monthOfYear + 1)) + "-" + year;  // Start date
                        try {
                            locationData_datewise.clear();
                            for (int i = 0; i < history_response.locationData.size(); i++) {
                                Date date1 = sdf.parse(dt);//2018-06-09 12:12:24
                                Date date2 = sdf.parse(history_response.locationData.get(i).date);
                                if (date1.compareTo(date2) == 0) {
                                    locationData_datewise.add(history_response.locationData.get(i));
                                }
                            }
                            if (locationData_datewise.size() > 0) {
                                txt_calendar.setText(((dayOfMonth) < 10 ? ("0" + (dayOfMonth)) : (dayOfMonth)) + "-" + ((monthOfYear + 1) < 10 ? ("0" + (monthOfYear + 1)) : (monthOfYear + 1)) + "-" + year);

                                adapter = new MyCustomAdapter(locationData_datewise);// new MyCustomAdapter(SocialAccount.this, response.body().socialdata);
                                recyclerView.setAdapter(adapter);

                            } else {
                                Toast.makeText(getActivity(), "No record exist on this date", Toast.LENGTH_SHORT).show();
                            }
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    }
                }, mYear, mMonth, mDay);

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        try {
            Date mDate = sdf.parse(history_response.locationData.get(history_response.locationData.size() - 1).date);
            timeInMilliseconds = mDate.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        datePickerDialog.updateDate(mYear, mMonth - 1, mDay);


        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        datePickerDialog.getDatePicker().setMinDate(timeInMilliseconds);
        datePickerDialog.show();
    }

    private void getlocation_history() {
        ApiUtils.getAlterationService().getLocationHistory("locations_history.php", Helper.getLocalValue(getActivity(), "user_id")).enqueue(new Callback<Location_history_Response>() {
            @Override
            public void onResponse(Call<Location_history_Response> call, Response<Location_history_Response> response) {
                try {
                    if (response.code() == 200) {
                        if (response.body().statusCode == 1) {
                            if (response.body() != null) {

                                adapter = null;
                                Collections.reverse(response.body().locationData);
                                history_response = response.body();
                                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
                                if (response.body().locationData.size() > 0) {
                                    txt_message.setVisibility(View.GONE);
                                    rl_calender.setVisibility(View.VISIBLE);

                                    txt_calendar.setText(sdf.format(sdf.parse(response.body().locationData.get(0).date)));
                                } else {
                                    txt_message.setVisibility(View.VISIBLE);
                                    rl_calender.setVisibility(View.GONE);
                                }


                                locationData_datewise.clear();
                                for (int i = 0; i < response.body().locationData.size(); i++) {
                                    Date date1 = sdf.parse(response.body().locationData.get(0).date);//2018-06-09 12:12:24
                                    Date date2 = sdf.parse(response.body().locationData.get(i).date);
                                    if (date1.compareTo(date2) == 0) {
                                        locationData_datewise.add(response.body().locationData.get(i));
                                        date_position++;
                                        start_position++;

                                    }
                                }

                                adapter = new MyCustomAdapter(locationData_datewise);// new MyCustomAdapter(SocialAccount.this, response.body().socialdata);
                                recyclerView.setAdapter(adapter);
                                if (locationData_datewise.size() > 0) {
                                    txt_message.setVisibility(View.GONE);
                                    rl_calender.setVisibility(View.VISIBLE);
                                } else {
                                    txt_message.setVisibility(View.VISIBLE);
                                    rl_calender.setVisibility(View.GONE);
                                }
                            } else {
                                Toast.makeText(getActivity(), response.body().message, Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(getActivity(), response.body().message, Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Location_history_Response> call, Throwable t) {
                t.printStackTrace();
                Toast.makeText(getActivity(), call.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public class MyCustomAdapter extends RecyclerView.Adapter<MyCustomAdapter.ItemViewHolder> {

        List<LocationData> list;

        public MyCustomAdapter(List<LocationData> list) {
            this.list = list;
        }


        @Override
        public ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

            return new ItemViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.location_history_list_item, parent, false));
        }

        public void onBindViewHolder(final ItemViewHolder holder, final int position) {

            try {

                final LocationData locationData = list.get(position);
                holder.txt_time.setText(locationData.date);
                holder.txt_address.setText(locationData.location);
                String image_path = "http://maps.google.com/maps/api/staticmap?center=" + locationData.latitude + "," + locationData.longitude + "&zoom=18&size=800x400&sensor=false&markers=" + locationData.latitude + "," + locationData.longitude + "&key=AIzaSyCrOlyl3bqiOCrktIcTNFv8ILS6wBYQpU0";
                Picasso.with(getActivity()).load(image_path).networkPolicy(NetworkPolicy.NO_CACHE).into(holder.img_map);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public int getItemCount() {
            return list != null ? list.size() : 0;
        }

        class ItemViewHolder extends RecyclerView.ViewHolder {
            TextView txt_time, txt_address;
            ImageView img_map;

            public ItemViewHolder(View itemView) {
                super(itemView);
                txt_time = (TextView) itemView.findViewById(R.id.txt_time);
                txt_address = (TextView) itemView.findViewById(R.id.txt_address);
                img_map = (ImageView) itemView.findViewById(R.id.img_map);
            }
        }
    }
}
