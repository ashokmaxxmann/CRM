package co.in.location.admin;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatDialog;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListPopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import co.in.location.GifImageView;
import co.in.location.R;
import co.in.location.Remote.ApiUtils;
import co.in.location.Remote.UserRoleResponce;
import co.in.location.Utility;
import co.in.location.data.ListData;
import co.in.location.response.UserListResponse;
import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Edit_Account extends AppCompatActivity implements View.OnClickListener {
    EditText edt_name, edt_phone, edt_email, edt_pass, edt_con_pass, edt_add, edt_designation, edt_department;
    TextView txt_submit;
    AppCompatDialog progressDialog;
    TextView prog_message;
    boolean pass_view = false, con_pass_view = false;
    boolean doubleBackToExitPressedOnce = false;
    private String[] list_approve;
    private ListPopupWindow lpw2, lpw3;
    String Designation, Department, Designation_id, Department_id, user_id, name, email, personal_number, address, image_path;
    ImageView img_back;
    CircleImageView profile_image;
    private int REQUEST_CAMERA = 0, SELECT_FILE = 1;
    private String realPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit__account);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        edt_name = (EditText) findViewById(R.id.edt_name);
        edt_email = (EditText) findViewById(R.id.edt_email);
        edt_phone = (EditText) findViewById(R.id.edt_phone);
        edt_pass = (EditText) findViewById(R.id.edt_pass);
        edt_con_pass = (EditText) findViewById(R.id.edt_con_pass);
        edt_add = (AutoCompleteTextView) findViewById(R.id.edt_add);
        edt_designation = (EditText) findViewById(R.id.edt_designation);
        edt_department = (EditText) findViewById(R.id.edt_department);
        txt_submit = (TextView) findViewById(R.id.txt_submit);
        txt_submit.setOnClickListener(this);
        progressDialog = new AppCompatDialog(Edit_Account.this);
        progressDialog.setCancelable(false);
        progressDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progressDialog.setContentView(R.layout.progress_loading);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        prog_message = progressDialog.findViewById(R.id.tv_progress_message);
        prog_message.setText("Please wait..");

        userRolelist();
        departmentlist();

        profile_image = (CircleImageView) findViewById(R.id.profile_image);
        profile_image.setOnClickListener(this);


        GifImageView gifImageView = (GifImageView) progressDialog.findViewById(R.id.GifImageView);
        gifImageView.setGifImageResource(R.drawable.loadinggif);
        img_back = (ImageView) findViewById(R.id.img_back);
        img_back.setOnClickListener(this);

        Intent in = getIntent();
        user_id = in.getStringExtra("user_id");
        name = in.getStringExtra("name");
        email = in.getStringExtra("email");
        personal_number = in.getStringExtra("personal_number");
        address = in.getStringExtra("address");
        Designation = in.getStringExtra("designation");
        Department = in.getStringExtra("departments");
        Designation_id = in.getStringExtra("designation_id");
        Department_id = in.getStringExtra("departments_id");
        image_path = in.getStringExtra("image_path");
        if (!image_path.isEmpty()) {
            Picasso.with(Edit_Account.this).load(ApiUtils.BASE_URL + image_path).networkPolicy(NetworkPolicy.NO_CACHE).into(profile_image);
        } else {
            Picasso.with(Edit_Account.this).load(R.mipmap.profilepic).into(profile_image);

        }
        edt_name.setText(name);
        edt_phone.setText(personal_number);
        edt_email.setText(email);
        edt_add.setText(address);
        edt_designation.setText(Designation);
        edt_department.setText(Department);

        edt_name.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (edt_name.getText().toString().equalsIgnoreCase("")) {
                        edt_name.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
                    } else if (!edt_name.getText().toString().equalsIgnoreCase("")) {
                        edt_name.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.colorPrimary)));
                    }
                } else {
                    if (edt_name.getText().toString().equalsIgnoreCase("")) {
                        edt_name.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.placeholder)));
                    } else if (!edt_name.getText().toString().equalsIgnoreCase("")) {
                        edt_name.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
                    }
                }
            }
        });

        edt_name.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!edt_name.getText().toString().equalsIgnoreCase("")) {
                    edt_name.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.colorPrimary)));
                } else {
                    edt_name.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
                }
            }
        });
        edt_email.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (edt_email.getText().toString().equalsIgnoreCase("")) {
                        edt_email.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
                    } else if (!edt_email.getText().toString().equalsIgnoreCase("")) {
                        edt_email.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.colorPrimary)));
                    }
                } else {
                    if (edt_email.getText().toString().equalsIgnoreCase("")) {
                        edt_email.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.placeholder)));
                    } else if (!edt_email.getText().toString().equalsIgnoreCase("")) {
                        edt_email.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
                    }
                }
            }
        });

        edt_email.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!edt_email.getText().toString().equalsIgnoreCase("")) {
                    edt_email.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.colorPrimary)));
                } else {
                    edt_email.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
                }
            }
        });
        edt_phone.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (edt_phone.getText().toString().equalsIgnoreCase("")) {
                        edt_phone.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
                    } else if (!edt_phone.getText().toString().equalsIgnoreCase("")) {
                        edt_phone.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.colorPrimary)));
                    }
                } else {
                    if (edt_phone.getText().toString().equalsIgnoreCase("")) {
                        edt_phone.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.placeholder)));
                    } else if (!edt_phone.getText().toString().equalsIgnoreCase("")) {
                        edt_phone.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
                    }
                }
            }
        });

        edt_phone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!edt_phone.getText().toString().equalsIgnoreCase("")) {
                    edt_phone.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.colorPrimary)));
                } else {
                    edt_phone.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
                }
            }
        });
        edt_pass.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (edt_pass.getText().toString().equalsIgnoreCase("")) {
                        edt_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
                        edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_white, 0);
                    } else if (!edt_pass.getText().toString().equalsIgnoreCase("")) {
                        edt_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.colorPrimary)));
                        if (pass_view) {
                            edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_hide, 0);
                        } else {
                            edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_view, 0);
                        }
                    }
                } else {
                    if (edt_pass.getText().toString().equalsIgnoreCase("")) {
                        edt_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.placeholder)));
                        edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_white, 0);
                    } else if (!edt_pass.getText().toString().equalsIgnoreCase("")) {
                        edt_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
                        if (pass_view) {
                            edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_hide, 0);
                        } else {
                            edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_view, 0);
                        }
                    }
                }
            }
        });

        edt_pass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!edt_pass.getText().toString().equalsIgnoreCase("")) {
                    edt_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.colorPrimary)));
                    if (pass_view) {
                        edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_hide, 0);
                    } else {
                        edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_view, 0);
                    }
                } else {
                    edt_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
                    edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_white, 0);
                }
            }
        });

        edt_pass.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                final int DRAWABLE_LEFT = 0;
                final int DRAWABLE_TOP = 1;
                final int DRAWABLE_RIGHT = 2;
                final int DRAWABLE_BOTTOM = 3;

                if (event.getAction() == MotionEvent.ACTION_UP) {
                    if (event.getRawX() >= (edt_pass.getRight() - edt_pass.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {
                        if (pass_view) {
                            pass_view = false;
                            edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_hide, 0);
                            edt_pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                        } else {
                            pass_view = true;
                            edt_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_view, 0);
                            edt_pass.setInputType(InputType.TYPE_CLASS_TEXT);
                        }
                        return true;
                    }
                }
                return false;
            }
        });
        edt_con_pass.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (edt_con_pass.getText().toString().equalsIgnoreCase("")) {
                        edt_con_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
                        edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_white, 0);
                    } else if (!edt_con_pass.getText().toString().equalsIgnoreCase("")) {
                        edt_con_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.colorPrimary)));
                        if (con_pass_view) {
                            edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_hide, 0);
                        } else {
                            edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_view, 0);
                        }
                    }
                } else {
                    if (edt_con_pass.getText().toString().equalsIgnoreCase("")) {
                        edt_con_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.placeholder)));
                        edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_white, 0);
                    } else if (!edt_con_pass.getText().toString().equalsIgnoreCase("")) {
                        edt_con_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
                        if (con_pass_view) {
                            edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_hide, 0);
                        } else {
                            edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_view, 0);
                        }
                    }
                }
            }
        });

        edt_con_pass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!edt_con_pass.getText().toString().equalsIgnoreCase("")) {
                    edt_con_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.colorPrimary)));
                    if (con_pass_view) {
                        edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_hide, 0);
                    } else {
                        edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_view, 0);
                    }
                } else {
                    edt_con_pass.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
                    edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_white, 0);
                }
            }
        });


        edt_con_pass.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                final int DRAWABLE_LEFT = 0;
                final int DRAWABLE_TOP = 1;
                final int DRAWABLE_RIGHT = 2;
                final int DRAWABLE_BOTTOM = 3;

                if (event.getAction() == MotionEvent.ACTION_UP) {
                    if (event.getRawX() >= (edt_con_pass.getRight() - edt_con_pass.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {
                        if (con_pass_view) {
                            con_pass_view = false;
                            edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_hide, 0);
                            edt_con_pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                        } else {
                            con_pass_view = true;
                            edt_con_pass.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pass_view, 0);
                            edt_con_pass.setInputType(InputType.TYPE_CLASS_TEXT);
                        }
                        return true;
                    }
                }
                return false;
            }
        });

        edt_add.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (edt_add.getText().toString().equalsIgnoreCase("")) {
                        edt_add.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
                    } else if (!edt_add.getText().toString().equalsIgnoreCase("")) {
                        edt_add.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.colorPrimary)));
                    }
                } else {
                    if (edt_add.getText().toString().equalsIgnoreCase("")) {
                        edt_add.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.placeholder)));
                    } else if (!edt_add.getText().toString().equalsIgnoreCase("")) {
                        edt_add.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
                    }
                }
            }
        });

        edt_add.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!edt_add.getText().toString().equalsIgnoreCase("")) {
                    edt_add.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.colorPrimary)));
                } else {
                    edt_add.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
                }
            }
        });


        edt_designation.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if ((!edt_designation.getText().toString().equalsIgnoreCase(""))) {
                    edt_designation.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.colorPrimary)));
                    edt_designation.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.dropdown_active, 0);
                } else {
                    edt_designation.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
                    edt_designation.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.dropdown_inactive, 0);
                }
            }
        });
        edt_department.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if ((!edt_department.getText().toString().equalsIgnoreCase(""))) {
                    edt_department.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.colorPrimary)));
                    edt_department.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.dropdown_active, 0);
                } else {
                    edt_department.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
                    edt_department.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.dropdown_inactive, 0);
                }
            }
        });

        edt_con_pass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                edt_con_pass.setError(null);
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!edt_pass.getText().toString().contains(s.toString())) {
                    edt_con_pass.requestFocus();
                    edt_con_pass.setError("password not matched");

                }
            }
        });

        lpw2 = new ListPopupWindow(Edit_Account.this);
        lpw3 = new ListPopupWindow(Edit_Account.this);
        edt_designation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputMethodManager inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

                inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);

                lpw2.show();
            }
        });
        edt_department.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputMethodManager inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

                inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);

                lpw3.show();
            }
        });

        edt_designation.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.dropdown_active, 0);
        edt_department.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.dropdown_active, 0);

        edt_name.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
        edt_email.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
        edt_phone.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
        edt_add.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
        edt_designation.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
        edt_department.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.w_input)));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.profile_image:

                boolean result = Utility.checkPermission(Edit_Account.this);
                if (result) {
                    selectImage();
                } else {
                    Toast.makeText(Edit_Account.this, "Permission not granted", Toast.LENGTH_LONG).show();
                }
                break;
            case R.id.img_option:
                boolean results = Utility.checkPermission(Edit_Account.this);
                if (results) {
                    selectImage();
                } else {
                    Toast.makeText(Edit_Account.this, "Permission not granted", Toast.LENGTH_LONG).show();
                }
                break;

            case R.id.txt_submit:
                if (validation()) {
                    update_user();
                }
                break;
            case R.id.img_back:
                Edit_Account.this.finish();
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        //super.onActivityResult(requestCode, resultCode, data); comment this unless you want to pass your result to the activity.
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_FILE) {
                get_path(data);
            } else if (requestCode == REQUEST_CAMERA) {
                onCaptureImageResult(data);
            }

        }


    }

    public void get_path(Intent data) {
        realPath = null;

        Uri uri = data.getData();
        if (realPath == null) {
            realPath = getRealPathFromURI_BelowAPI11(Edit_Account.this, uri);
            if (realPath == null) {
                realPath = getRealPathFromURI_API11to18(Edit_Account.this, uri);
                if (realPath == null) {
                    realPath = getRealPathFromURI_API19(Edit_Account.this, uri);
                    if (realPath == null) {
                        Toast.makeText(Edit_Account.this, "Image Path not getting", Toast.LENGTH_LONG).show();
                    } else {
                        onSelectFromGalleryResult(data, realPath);
                    }
                } else {
                    onSelectFromGalleryResult(data, realPath);
                }
            } else {
                onSelectFromGalleryResult(data, realPath);
            }
        } else {
            onSelectFromGalleryResult(data, realPath);
        }
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);

        File destination = new File(Environment.getExternalStorageDirectory(), System.currentTimeMillis() + ".jpg");
        realPath = destination.toString();
        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        profile_image.setImageBitmap(thumbnail);
    }

    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data, String path) {

        Bitmap bm = null;
        if (data != null) {
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(Edit_Account.this.getContentResolver(), data.getData());
                // Log.d(TAG, String.valueOf(bitmap));

                profile_image.setImageBitmap(bitmap);
                /*txt_filename.setText(path.substring(path.lastIndexOf("/") + 1));*/
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @SuppressLint("NewApi")
    public String getRealPathFromURI_API19(Context context, Uri uri) {
        String filePath = "";
        String wholeID = DocumentsContract.getDocumentId(uri);

        // Split at colon, use second item in the array
        String id = wholeID.split(":")[1];

        String[] column = {MediaStore.Images.Media.DATA};

        // where id is equal to
        String sel = MediaStore.Images.Media._ID + "=?";

        Cursor cursor = context.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, column, sel, new String[]{id}, null);

        int columnIndex = cursor.getColumnIndex(column[0]);

        if (cursor.moveToFirst()) {
            filePath = cursor.getString(columnIndex);
        }
        cursor.close();
//        source_file = new File(filePath);
        return filePath;
    }

    @SuppressLint("NewApi")
    public String getRealPathFromURI_API11to18(Context context, Uri contentUri) {
        String[] proj = {MediaStore.Images.Media.DATA};
        String result = null;

        CursorLoader cursorLoader = new CursorLoader(context, contentUri, proj, null, null, null);
        Cursor cursor = cursorLoader.loadInBackground();

        if (cursor != null) {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            result = cursor.getString(column_index);
            cursor.close();
//            source_file = new File(result);
        }
        return result;
    }

    public String getRealPathFromURI_BelowAPI11(Context context, Uri contentUri) {
        String[] proj = {MediaStore.Images.Media.DATA};
        String result = null;
        Cursor cursor = context.getContentResolver().query(contentUri, proj, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        result = cursor.getString(column_index);
        cursor.close();
//        source_file = new File(result);
        return result;
    }

    private void galleryIntent() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);//
        startActivityForResult(Intent.createChooser(intent, "Select File"), SELECT_FILE);
    }

    private void cameraIntent() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, REQUEST_CAMERA);
    }

    private void selectImage() {
        final CharSequence[] items = {"Take Photo", "Choose from Library", "Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(Edit_Account.this);
        builder.setTitle("Upload Photo!");
        builder.setCancelable(false);
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                boolean result = Utility.checkPermission(Edit_Account.this);

                if (items[item].equals("Take Photo")) {
                    if (result) cameraIntent();

                } else if (items[item].equals("Choose from Library")) {
                    if (result) galleryIntent();

                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    public boolean validation() {
//        String a = edt_c_code.getSelectedCountryCodeWithPlus();

        if (TextUtils.isEmpty(edt_name.getText().toString())) {
            edt_name.requestFocus();
            edt_name.setError("Please fill name");
            return false;
        }
        if ((TextUtils.isEmpty(edt_email.getText().toString())) || (!Patterns.EMAIL_ADDRESS.matcher(edt_email.getText().toString()).matches())) {
            edt_email.requestFocus();
            edt_email.setError("Please fill correct email");
            return false;
        }
        if ((TextUtils.isEmpty(edt_phone.getText().toString())) || (edt_phone.getText().toString().length() < 10)) {
            edt_phone.requestFocus();
            edt_phone.setError("Please fill correct number");
            return false;
        }
/*
        if ((TextUtils.isEmpty(edt_pass.getText().toString())) || (edt_pass.getText().toString().length() < 6)) {
            edt_pass.requestFocus();
            edt_pass.setError("Please fill minimum 6 char.");
            return false;
        }
        if ((TextUtils.isEmpty(edt_con_pass.getText().toString())) || (!edt_con_pass.getText().toString().equalsIgnoreCase(edt_pass.getText().toString()))) {
            edt_con_pass.requestFocus();
            edt_con_pass.setError("Password not matched");
            return false;
        }*/
        if (!TextUtils.isEmpty(edt_pass.getText().toString())) {
            if ((TextUtils.isEmpty(edt_con_pass.getText().toString())) || (!edt_con_pass.getText().toString().equalsIgnoreCase(edt_pass.getText().toString()))) {
                edt_con_pass.requestFocus();
                edt_con_pass.setError("Password not matched");
                return false;
            }
        }
        if ((TextUtils.isEmpty(edt_add.getText().toString())) || (edt_add.getText().toString().length() < 6)) {
            edt_add.requestFocus();
            edt_add.setError("Please fill address");
            return false;
        }
        if (TextUtils.isEmpty(edt_designation.getText().toString())) {
            Toast.makeText(Edit_Account.this, "Please select user designation", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

    private void update_user() {
        InputMethodManager inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        if (progressDialog != null) progressDialog.show();
        MultipartBody.Builder builder = new MultipartBody.Builder();
        builder.setType(MultipartBody.FORM);
        builder.addFormDataPart("user_id", user_id);
        builder.addFormDataPart("name", edt_name.getText().toString());
        builder.addFormDataPart("email", edt_email.getText().toString());
        builder.addFormDataPart("password", edt_con_pass.getText().toString());
        builder.addFormDataPart("personal_number", edt_phone.getText().toString());
        builder.addFormDataPart("address", edt_add.getText().toString());
        builder.addFormDataPart("designation", Designation_id);
        builder.addFormDataPart("departments", Department_id);

        if (!TextUtils.isEmpty(realPath)) {
            File file = new File(realPath);
            builder.addFormDataPart("image_path", file.getName(), RequestBody.create(MediaType.parse("multipart/form-data"), file));
        }

        MultipartBody requestBody = builder.build();
        Call<UserListResponse> call = ApiUtils.getAlterationService().update_user(requestBody);
        call.enqueue(new Callback<UserListResponse>() {
            @Override
            public void onResponse(Call<UserListResponse> call, Response<UserListResponse> response) {

                /* Toast.makeText(MessageReply.this, "Success " + response.message(), Toast.LENGTH_LONG).show();*/
                try {
                    if (response.code() == 200) {
                        if (response.body().statusCode == 1) {
                            UserList.responce = response.body();
                            Toast.makeText(Edit_Account.this, response.body().message, Toast.LENGTH_LONG).show();
                            UserList.update_user_profile = true;
                            Edit_Account.this.finish();
                        } else {
                            Toast.makeText(Edit_Account.this, response.body().message, Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(Edit_Account.this, response.body().message, Toast.LENGTH_SHORT).show();
                    }
                    progressDialog.dismiss();
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(Edit_Account.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<UserListResponse> call, Throwable t) {
                Toast.makeText(Edit_Account.this, t.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        });
    }

    private void userRolelist() {
        ApiUtils.getAlterationService().user_role("user-role-list", "").enqueue(new Callback<UserRoleResponce>() {
            @Override
            public void onResponse(Call<UserRoleResponce> call, Response<UserRoleResponce> response) {
                try {
                    if (response.code() == 200) {
                        if (response.body().statusCode == 1) {
                            if (response.body() != null) {
                                lpw2.setAdapter(new UserRoleAdapter(Edit_Account.this, response.body().listData));
                            }
                            lpw2.setAnchorView(edt_designation);
                            lpw2.setModal(true);
                        } else {
                            Toast.makeText(Edit_Account.this, response.body().message, Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(Edit_Account.this, response.body().message, Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<UserRoleResponce> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    private void departmentlist() {
        ApiUtils.getAlterationService().department("department-list", "").enqueue(new Callback<UserRoleResponce>() {
            @Override
            public void onResponse(Call<UserRoleResponce> call, Response<UserRoleResponce> response) {
                try {
                    if (response.code() == 200) {
                        if (response.body().statusCode == 1) {
                            if (response.body() != null) {
                                lpw3.setAdapter(new UserDepartmentAdapter(Edit_Account.this, response.body().listData));
                            }
                            lpw3.setAnchorView(edt_department);
                            lpw3.setModal(true);
                        } else {
                            Toast.makeText(Edit_Account.this, response.body().message, Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(Edit_Account.this, response.body().message, Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<UserRoleResponce> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    class UserRoleAdapter extends BaseAdapter {

        LayoutInflater inflater;
        List<ListData> list;

        public UserRoleAdapter(FragmentActivity fragmentActivity, List<ListData> list) {
            inflater = LayoutInflater.from(fragmentActivity);
            this.list = list;
        }

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int paramInt) {
            return paramInt;
        }

        class ViewHolder {
            TextView txt_role;
        }

        @Override
        public long getItemId(int paramInt) {
            return paramInt;
        }

        @Override
        public View getView(final int paramInt, View itemView, ViewGroup paramViewGroup) {

            UserRoleAdapter.ViewHolder holder;
            if (itemView == null) {
                itemView = inflater.inflate(R.layout.user_role_list, paramViewGroup, false);
                holder = new UserRoleAdapter.ViewHolder();

                holder.txt_role = (TextView) itemView.findViewById(R.id.txt_role);

                itemView.setTag(holder);
            } else {
                holder = (UserRoleAdapter.ViewHolder) itemView.getTag();
            }
            final ListData listData = list.get(paramInt);
            holder.txt_role.setText(listData.display_name);

            holder.txt_role.setTag(paramInt);
            holder.txt_role.setOnClickListener(new View.OnClickListener() {

                @SuppressWarnings("deprecation")
                @Override
                public void onClick(View vv) {
                    // TODO Auto-generated method stub
                    int pos1 = (Integer) vv.getTag();
                    ListData listData = list.get(pos1);

                    Designation_id = listData.id;
                    edt_designation.setText(listData.display_name);
                    lpw2.dismiss();
                }
            });
            return itemView;
        }
    }

    class UserDepartmentAdapter extends BaseAdapter {

        LayoutInflater inflater;
        List<ListData> list;

        public UserDepartmentAdapter(FragmentActivity fragmentActivity, List<ListData> list) {
            inflater = LayoutInflater.from(fragmentActivity);
            this.list = list;
        }

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int paramInt) {
            return paramInt;
        }

        class ViewHolder {
            TextView txt_role;
        }

        @Override
        public long getItemId(int paramInt) {
            return paramInt;
        }

        @Override
        public View getView(final int paramInt, View itemView, ViewGroup paramViewGroup) {

            UserDepartmentAdapter.ViewHolder holder;
            if (itemView == null) {
                itemView = inflater.inflate(R.layout.user_role_list, paramViewGroup, false);
                holder = new UserDepartmentAdapter.ViewHolder();

                holder.txt_role = (TextView) itemView.findViewById(R.id.txt_role);

                itemView.setTag(holder);
            } else {
                holder = (UserDepartmentAdapter.ViewHolder) itemView.getTag();
            }
            final ListData listData = list.get(paramInt);
            holder.txt_role.setText(listData.name);

            holder.txt_role.setTag(paramInt);
            holder.txt_role.setOnClickListener(new View.OnClickListener() {

                @SuppressWarnings("deprecation")
                @Override
                public void onClick(View vv) {
                    // TODO Auto-generated method stub
                    int pos1 = (Integer) vv.getTag();
                    ListData listData = list.get(pos1);

                    Department_id = listData.id;
                    edt_department.setText(listData.name);
                    lpw3.dismiss();
                }
            });
            return itemView;
        }
    }
}
