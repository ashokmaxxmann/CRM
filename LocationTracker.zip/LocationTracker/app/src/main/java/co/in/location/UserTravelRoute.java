package co.in.location;

import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import co.in.location.admin.LocationHistory;

public class UserTravelRoute extends AppCompatActivity implements OnMapReadyCallback {
    GoogleMap map;
    public static MarkerOptions markerOptions = new MarkerOptions();
    public static MarkerOptions markerOptions2 = new MarkerOptions();
    LatLng origin, dest;
    int array_size, remain_array_size, start_point, end_point,repeted=2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_travel_route);
        // Initializing
//        markerPoints = new ArrayList<LatLng>();

        // Getting reference to SupportMapFragment of the activity_main
        SupportMapFragment fm = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);

        // Getting reference to Button

        // Getting Map for the SupportMapFragment
        fm.getMapAsync(this);
        /*flat = Double.parseDouble("30.721595");
        flng = Double.parseDouble("76.7686156");
        slat = Double.parseDouble("30.739471");
        slng = Double.parseDouble("76.7825333");
        tlat = Double.parseDouble("30.702618");
        tlng = Double.parseDouble("76.819172");

        folat = Double.parseDouble("30.750953");
        folng = Double.parseDouble("76.7808114");

        origin = new LatLng(flat, flng);
        dest = new LatLng(slat, slng);
        third = new LatLng(tlat, tlng);
        fourth = new LatLng(folat, folng);
        markerPoints.add(origin);
        markerPoints.add(dest);
        markerPoints.add(third);
        markerPoints.add(fourth);*/


        // Click event handler for Button btn_draw

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;
        if (LocationHistory.history_response.locationData.size() > 0) {
//            currentAddress = getCompleteAddressString(mLatitude, mLongitude);
            if (map != null) {
                map.clear();
                array_size = LocationHistory.history_response.locationData.size();
                for (int i = 0; i < LocationHistory.history_response.locationData.size(); i++) {
                    if (i == 0||i==LocationHistory.history_response.locationData.size()-1) {
                        LatLng point = new LatLng(Double.parseDouble(LocationHistory.history_response.locationData.get(i).latitude), Double.parseDouble(LocationHistory.history_response.locationData.get(i).longitude));
                        markerOptions.title(getCompleteAddressString(point.latitude, point.longitude));
                        markerOptions.icon(BitmapDescriptorFactory.fromResource(R.mipmap.redmarker));
                        markerOptions.position(point);
                        map.addMarker(markerOptions);
                        if (i == 0) {
                            map.moveCamera(CameraUpdateFactory.newLatLngZoom(point, 12));
                            map.animateCamera(CameraUpdateFactory.zoomTo(12), 1500, null);
                        }
                    }
                    else
                    {
                        LatLng point = new LatLng(Double.parseDouble(LocationHistory.history_response.locationData.get(i).latitude), Double.parseDouble(LocationHistory.history_response.locationData.get(i).longitude));
                        markerOptions.title(getCompleteAddressString(point.latitude, point.longitude));
                        markerOptions.icon(BitmapDescriptorFactory.fromResource(R.mipmap.purpalmarker));
                        markerOptions.position(point);
                        map.addMarker(markerOptions);
                    }
                }
                origin = new LatLng(Double.parseDouble(LocationHistory.history_response.locationData.get(0).latitude), Double.parseDouble(LocationHistory.history_response.locationData.get(0).longitude));
                if (array_size >= 10) {
                    remain_array_size = array_size - 10;
                    start_point = 1;
                    end_point = 10 - 1;
                    dest = new LatLng(Double.parseDouble(LocationHistory.history_response.locationData.get(end_point).latitude), Double.parseDouble(LocationHistory.history_response.locationData.get(end_point).longitude));

                } else {

                    remain_array_size = 0;
                    start_point = end_point + 2;
                    end_point = array_size-1 ;
                    dest = new LatLng(Double.parseDouble(LocationHistory.history_response.locationData.get(array_size - 1).latitude), Double.parseDouble(LocationHistory.history_response.locationData.get(array_size - 1).longitude));

                }
                String url = getDirectionsUrl(origin, dest);

                DownloadTask downloadTask = new DownloadTask();

                // Start downloading json data from Google Directions API
                downloadTask.execute(url);

                /*markerOptions.title(getCompleteAddressString(flat, flng));
                markerOptions.snippet("Ashok");
                markerOptions.visible(true);
                markerOptions.position(origin);
                Marker m = map.addMarker(markerOptions);

                markerOptions2.title(getCompleteAddressString(slat, slng));
                markerOptions2.snippet("Ashu");
                markerOptions2.visible(true);
                markerOptions2.position(dest);
                map.addMarker(markerOptions2);
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(origin, 12));
                map.animateCamera(CameraUpdateFactory.zoomTo(12), 1500, null);*/
            }
        }


    }

    public String getCompleteAddressString(double LATITUDE, double LONGITUDE) {

        Geocoder geocoder;
        List<Address> addresses;
        String address = "";
        geocoder = new Geocoder(UserTravelRoute.this, Locale.getDefault());

        try {
            addresses = geocoder.getFromLocation(LATITUDE, LONGITUDE, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5


            address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
        } catch (IOException e) {
            e.printStackTrace();
        }
        return address;
    }

    private String getDirectionsUrl(LatLng origin, LatLng dest) {

        // Origin of route
        String str_origin = "origin=" + origin.latitude + "," + origin.longitude;

        // Destination of route
        String str_dest = "destination=" + dest.latitude + "," + dest.longitude;

        // Sensor enabled
        String sensor = "sensor=false";

        // Waypoints
        String waypoints = "";


        for (int i = start_point; i <= end_point - 1; i++) {

//            LatLng point = (LatLng) markerPoints.get(i);
            LatLng point = new LatLng(Double.parseDouble(LocationHistory.history_response.locationData.get(i).latitude), Double.parseDouble(LocationHistory.history_response.locationData.get(i).longitude));

            if (LocationHistory.history_response.locationData.size() == 2) {

            } else {
                waypoints = waypoints + point.latitude + "," + point.longitude + "|";
            }

        }
        String parameters;
        if (waypoints.length() > 0) {
            parameters = str_origin + "&" + str_dest + "&" + sensor + "&waypoints=" + waypoints;
        } else {
            parameters = str_origin + "&" + str_dest + "&" + sensor;
        }

        // Building the parameters to the web service
//        String parameters = str_origin + "&" + str_dest + "&" + sensor + "&" + waypoints;

        // Output format
        String output = "json";

        // Building the url to the web service
        String url = "https://maps.googleapis.com/maps/api/directions/" + output + "?" + parameters;

        return url;
    }

    /**
     * A method to download json data from url
     */
    private String downloadUrl(String strUrl) throws IOException {
        String data = "";
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(strUrl);

            // Creating an http connection to communicate with url
            urlConnection = (HttpURLConnection) url.openConnection();

            // Connecting to url
            urlConnection.connect();

            // Reading data from url
            iStream = urlConnection.getInputStream();

            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));

            StringBuffer sb = new StringBuffer();

            String line = "";
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }

            data = sb.toString();

            br.close();

        } catch (Exception e) {
            Log.d("Exception while", e.toString());
        } finally {
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }

    // Fetches data from url passed
    private class DownloadTask extends AsyncTask<String, Void, String> {

        // Downloading data in non-ui thread
        @Override
        protected String doInBackground(String... url) {

            // For storing data from web service

            String data = "";

            try {
                // Fetching the data from web service
                data = downloadUrl(url[0]);
            } catch (Exception e) {
                Log.d("Background Task", e.toString());
            }
            return data;
        }

        // Executes in UI thread, after the execution of
        // doInBackground()
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            ParserTask parserTask = new ParserTask();

            // Invokes the thread for parsing the JSON data
            parserTask.execute(result);
        }
    }

    /**
     * A class to parse the Google Places in JSON format
     */
    private class ParserTask extends AsyncTask<String, Integer, List<List<HashMap<String, String>>>> {

        // Parsing the data in non-ui thread
        @Override
        protected List<List<HashMap<String, String>>> doInBackground(String... jsonData) {

            JSONObject jObject;
            List<List<HashMap<String, String>>> routes = null;

            try {
                jObject = new JSONObject(jsonData[0]);
                /*DirectionsJSONParser parser = new DirectionsJSONParser();

                // Starts parsing data
                routes = parser.parse(jObject);*/
            } catch (Exception e) {
                e.printStackTrace();
            }
            return routes;
        }

        // Executes in UI thread, after the parsing process
        @Override
        protected void onPostExecute(List<List<HashMap<String, String>>> result) {

            ArrayList<LatLng> points = null;
            PolylineOptions lineOptions = null;

            // Traversing through all the routes
            for (int i = 0; i < result.size(); i++) {
                points = new ArrayList<LatLng>();
                lineOptions = new PolylineOptions();

                // Fetching i-th route
                List<HashMap<String, String>> path = result.get(i);

                // Fetching all the points in i-th route
                for (int j = 0; j < path.size(); j++) {
                    HashMap<String, String> point = path.get(j);

                    double lat = Double.parseDouble(point.get("lat"));
                    double lng = Double.parseDouble(point.get("lng"));
                    LatLng position = new LatLng(lat, lng);

                    points.add(position);
                }

                // Adding all the points in the route to LineOptions
                lineOptions.addAll(points);
                lineOptions.width(5);
                lineOptions.color(Color.BLUE);
            }

            // Drawing polyline in the Google Map for the i-th route
            map.addPolyline(lineOptions);
//=============================///
            if (remain_array_size > 0) {
                origin = new LatLng(Double.parseDouble(LocationHistory.history_response.locationData.get(end_point + 1).latitude), Double.parseDouble(LocationHistory.history_response.locationData.get(end_point + 1).longitude));
                if (remain_array_size >= 10) {

                    remain_array_size = array_size - repeted*10;
                    start_point = end_point + 2;
                    end_point = (repeted*10) - 1;
                    dest = new LatLng(Double.parseDouble(LocationHistory.history_response.locationData.get(end_point).latitude), Double.parseDouble(LocationHistory.history_response.locationData.get(end_point).longitude));
                    repeted++;
                } else {
                    remain_array_size = 0;
                    start_point = end_point + 2;
                    end_point = array_size-1 ;
                    dest = new LatLng(Double.parseDouble(LocationHistory.history_response.locationData.get(array_size - 1).latitude), Double.parseDouble(LocationHistory.history_response.locationData.get(array_size - 1).longitude));
                }
                String url = getDirectionsUrl(origin, dest);

                DownloadTask downloadTask = new DownloadTask();

                // Start downloading json data from Google Directions API
                downloadTask.execute(url);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
}