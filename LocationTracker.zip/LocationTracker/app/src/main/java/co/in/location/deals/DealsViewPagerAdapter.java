package co.in.location.deals;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import co.in.location.deals.Account_Tab;
import co.in.location.deals.Address_Tab;
import co.in.location.deals.Contact_Tab;
import co.in.location.deals.Deals_Tab;

public class DealsViewPagerAdapter extends FragmentStatePagerAdapter {

    CharSequence Titles[];
    int NumbOfTabs;

    public DealsViewPagerAdapter(FragmentManager fm, CharSequence mTitles[],
                               int mNumbOfTabsumb) {
        super(fm);
        this.Titles = mTitles;
        this.NumbOfTabs = mNumbOfTabsumb;
    }

    // This method return the fragment for the every position in the View Pager
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                Contact_Tab contact_tab = new Contact_Tab();
                return contact_tab;
            case 1:
                Account_Tab account_tab = new Account_Tab();
                return account_tab;
            case 2:
                Address_Tab address_tab = new Address_Tab();
                return address_tab;
            case 3:
                Deals_Tab deals_tab = new Deals_Tab();
                return deals_tab;
            default:
                return null;
        }
    }

    // This method return the titles for the Tabs in the Tab Strip
    @Override
    public CharSequence getPageTitle(int position) {
        return Titles[position];
    }

    // This method return the Number of tabs for the tabs Strip
    @Override
    public int getCount() {
        return NumbOfTabs;
    }
}