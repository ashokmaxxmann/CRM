package co.in.location.crm;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.app.AppCompatDialog;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.SectionIndexer;
import android.widget.TextView;
import android.widget.Toast;

import co.in.location.GifImageView;
import co.in.location.Helper;
import co.in.location.R;
import co.in.location.Remote.ApiUtils;
import co.in.location.response.CRMListResponse;
import co.in.location.response.DeleteResponce;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CRM_Analysis_Tab extends Fragment {
    TextView txt_google_review, txt_justdial_review, txt_facebook_review, txt_other_review, txt_fb_likes, txt_fb_followers, txt_responcerate, txt_engagementrate, txt_linkedin_followers;
    TextView txt_website, txt_website_technology, txt_wensite_input, txt_website_type, txt_overlook_feel, txt_website_language, txt_content_quality, txt_graphics_quality, txt_global_rank, txt_total_score;
    TextView txt_keyword1, txt_gr1, txt_keyword2, txt_gr2, txt_keyword3, txt_gr3, txt_keyword4, txt_gr4, txt_keyword5, txt_gr5, txt_keyword6, txt_gr6, txt_keyword7, txt_gr7;
    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.crm_analysis_tab, container, false);
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        txt_google_review = (TextView) view.findViewById(R.id.txt_google_review);
        txt_justdial_review = (TextView) view.findViewById(R.id.txt_justdial_review);
        txt_facebook_review = (TextView) view.findViewById(R.id.txt_facebook_review);
        txt_other_review = (TextView) view.findViewById(R.id.txt_other_review);
        txt_fb_likes = (TextView) view.findViewById(R.id.txt_fb_likes);
        txt_fb_followers = (TextView) view.findViewById(R.id.txt_fb_followers);
        txt_responcerate = (TextView) view.findViewById(R.id.txt_responcerate);
        txt_engagementrate = (TextView) view.findViewById(R.id.txt_engagementrate);
        txt_linkedin_followers = (TextView) view.findViewById(R.id.txt_linkedin_followers);
        txt_website = (TextView) view.findViewById(R.id.txt_website);
        txt_website_technology = (TextView) view.findViewById(R.id.txt_website_technology);
        txt_wensite_input = (TextView) view.findViewById(R.id.txt_wensite_input);
        txt_website_type = (TextView) view.findViewById(R.id.txt_website_type);
        txt_overlook_feel = (TextView) view.findViewById(R.id.txt_overlook_feel);
        txt_website_language = (TextView) view.findViewById(R.id.txt_website_language);
        txt_content_quality = (TextView) view.findViewById(R.id.txt_content_quality);
        txt_graphics_quality = (TextView) view.findViewById(R.id.txt_graphics_quality);
        txt_global_rank = (TextView) view.findViewById(R.id.txt_global_rank);
        txt_total_score = (TextView) view.findViewById(R.id.txt_total_score);
        txt_keyword1 = (TextView) view.findViewById(R.id.txt_keyword1);
        txt_gr1 = (TextView) view.findViewById(R.id.txt_gr1);
        txt_keyword2 = (TextView) view.findViewById(R.id.txt_keyword2);
        txt_gr2 = (TextView) view.findViewById(R.id.txt_gr2);
        txt_keyword3 = (TextView) view.findViewById(R.id.txt_keyword3);
        txt_gr3 = (TextView) view.findViewById(R.id.txt_gr3);
        txt_keyword4 = (TextView) view.findViewById(R.id.txt_keyword4);
        txt_gr4 = (TextView) view.findViewById(R.id.txt_gr4);
        txt_keyword5 = (TextView) view.findViewById(R.id.txt_keyword5);
        txt_gr5 = (TextView) view.findViewById(R.id.txt_gr5);
        txt_keyword6 = (TextView) view.findViewById(R.id.txt_keyword6);
        txt_gr6 = (TextView) view.findViewById(R.id.txt_gr6);
        txt_keyword7 = (TextView) view.findViewById(R.id.txt_keyword7);
        txt_gr7 = (TextView) view.findViewById(R.id.txt_gr7);

//        id = LeadCRMDetailsFragment.id;
//        currentpage = LeadCRMDetailsFragment.currentpage;
//        txt_mobile.setOnClickListener(this);
        executeMethode();
//        leadCRMDetails1111 = this;
        return view;
    }

    public void executeMethode() {
        txt_google_review.setText(LeadCRMDetails.respose.crmListData.get(0).google_reviews);
        txt_justdial_review.setText(LeadCRMDetails.respose.crmListData.get(0).Just_Dial_Reviews);
        txt_facebook_review.setText(LeadCRMDetails.respose.crmListData.get(0).facebook_reviews);
        txt_other_review.setText(LeadCRMDetails.respose.crmListData.get(0).Other_Social_Channel_Reviews);
        txt_fb_likes.setText(LeadCRMDetails.respose.crmListData.get(0).Fb_likes);
        txt_fb_followers.setText(LeadCRMDetails.respose.crmListData.get(0).FB_Followers);
        txt_responcerate.setText(LeadCRMDetails.respose.crmListData.get(0).Response_Rate);
        txt_engagementrate.setText(LeadCRMDetails.respose.crmListData.get(0).Engagement_Rate);
        txt_linkedin_followers.setText(LeadCRMDetails.respose.crmListData.get(0).Linkedin_Followers);
        txt_website.setText(LeadCRMDetails.respose.crmListData.get(0).Website);
        txt_website_technology.setText(LeadCRMDetails.respose.crmListData.get(0).Website_Technology);
        txt_wensite_input.setText(LeadCRMDetails.respose.crmListData.get(0).Website_information);
        txt_website_type.setText(LeadCRMDetails.respose.crmListData.get(0).Website_Type);
        txt_overlook_feel.setText(LeadCRMDetails.respose.crmListData.get(0).Overlook_and_Feels);
        txt_website_language.setText(LeadCRMDetails.respose.crmListData.get(0).Website_Language);
        txt_content_quality.setText(LeadCRMDetails.respose.crmListData.get(0).Content_Quality);
        txt_graphics_quality.setText(LeadCRMDetails.respose.crmListData.get(0).Graphic_Quality);
        txt_global_rank.setText(LeadCRMDetails.respose.crmListData.get(0).Global_Rank);
        txt_total_score.setText(LeadCRMDetails.respose.crmListData.get(0).total_score);
        txt_keyword1.setText(LeadCRMDetails.respose.crmListData.get(0).Ranking_Keyword_1);
        txt_gr1.setText(LeadCRMDetails.respose.crmListData.get(0).Global_Rank_Keyword_1);
        txt_keyword2.setText(LeadCRMDetails.respose.crmListData.get(0).Ranking_Keyword_2);
        txt_gr2.setText(LeadCRMDetails.respose.crmListData.get(0).Global_Rank_Keyword_2);
        txt_keyword3.setText(LeadCRMDetails.respose.crmListData.get(0).Ranking_Keyword_3);
        txt_gr3.setText(LeadCRMDetails.respose.crmListData.get(0).Global_Rank_Keyword_3);
        txt_keyword4.setText(LeadCRMDetails.respose.crmListData.get(0).Ranking_Keyword_4);
        txt_gr4.setText(LeadCRMDetails.respose.crmListData.get(0).Global_Rank_Keyword_4);
        txt_keyword5.setText(LeadCRMDetails.respose.crmListData.get(0).Ranking_Keyword_5);
        txt_gr5.setText(LeadCRMDetails.respose.crmListData.get(0).Global_Rank_Keyword_5);
        txt_keyword6.setText(LeadCRMDetails.respose.crmListData.get(0).Ranking_Keyword_6);
        txt_gr6.setText(LeadCRMDetails.respose.crmListData.get(0).Global_Rank_Keyword_6);
        txt_keyword7.setText(LeadCRMDetails.respose.crmListData.get(0).Ranking_Keyword_7);
        txt_gr7.setText(LeadCRMDetails.respose.crmListData.get(0).Global_Rank_Keyword_7);
    }
}
