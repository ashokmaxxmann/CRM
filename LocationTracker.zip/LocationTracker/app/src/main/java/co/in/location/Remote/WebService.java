package co.in.location.Remote;

import java.util.ArrayList;

import co.in.location.response.AccountUpdateResponse;
import co.in.location.response.CRMListResponse;
import co.in.location.response.CRMResponce;
import co.in.location.response.DeleteResponce;
import co.in.location.response.LiveLocationResponce;
import co.in.location.response.LocationUpdateResponce;
import co.in.location.response.Location_history_Response;
import co.in.location.response.LoginResponse;
import co.in.location.response.RegisterResponse;
import co.in.location.response.UserListResponse;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Url;


public interface WebService {


/*    @GET
    Call<AlterListResponse> getAlterList(@Url String url);


    @GET
    Call<ButtonResponse> getRepairButtonsList(@Url String url);

    @GET
    Call<CollarResponse> getRepairCollarsList(@Url String url);


    @GET
    Call<CuffsResponse> getRepairCuffsList(@Url String url);

    @GET
    Call<SleeveResponse> getRepairSleevesList(@Url String url);
    @GET
    Call<PocketResponse> getRepairPocketsList(@Url String url);
    @GET
    Call<PlacketResponse> getRepairPlacketsList(@Url String url);

    @FormUrlEncoded
    @POST
    Call<EditCartResponse> editCart(@Url String url, @FieldMap HashMap<String, Object> map);


    @FormUrlEncoded
    @POST
    Call<OTPRequestResponse> requestOTP(@Url String url, @Field("mobile") String mobile);*/


   /* @FormUrlEncoded
    @POST
    Call<LoginResponse> login_post(@Url String url, @Field("email") String email, @Field("password") String password, @Field("gcm_key") String gcm_key, @Field("device_id") String login_type);
    @FormUrlEncoded
    @POST
    Call<ForgotResponse> forget_pass_post(@Url String url, @Field("email") String email);
    @FormUrlEncoded
    @POST
    Call<UserRoleResponce> user_role(@Url String url, @Field("id") String id);
    @FormUrlEncoded
    @POST
    Call<UsersResponce> getUsers(@Url String url, @Field("role_id") String role_id);
    @FormUrlEncoded
    @POST
    Call<UserDetailsResponce> getUsersDetails(@Url String url, @Field("user_id") String user_id);
    @FormUrlEncoded
    @POST
    Call<UsersResponce> userDelete(@Url String url, @Field("user_id") String user_id);
*/
    /*@FormUrlEncoded
    @POST("profile-update")
    Call<LoginResponse> updateProfile(@FieldMap HashMap<String, RequestBody> map);
*/

    /*@Multipart
    @POST("profile-update")
    Call<LoginResponse> updateProfile(
            @PartMap() Map<String, RequestBody> partMap,
            @Part MultipartBody.Part file);*/
    @POST("admin_registration.php")
    Call<RegisterResponse> register(@Body RequestBody file);

    @POST("admin_profile_update.php")
    Call<RegisterResponse> update_admin_profile(@Body RequestBody file);


    @POST("registration.php")
    Call<RegisterResponse> user_register(@Body RequestBody file);

    @POST("profile-update")
    Call<UserListResponse> update_user(@Body RequestBody file);

    @POST("user-profile")
    Call<LoginResponse> update_profile(@Body RequestBody file);


    @FormUrlEncoded
    @POST
    Call<UserRoleResponce> user_role(@Url String url, @Field("id") String id);
    @FormUrlEncoded
    @POST
    Call<UserRoleResponce> department(@Url String url, @Field("id") String id);


    @POST("create-user")
    Call<RegisterResponse> createUser(@Body RequestBody file);

    @FormUrlEncoded
    @POST
    Call<LoginResponse> login(@Url String url, @Field("email") String email, @Field("password") String password);



    @FormUrlEncoded
    @POST
    Call<LoginResponse> login_post(@Url String url, @Field("email") String email, @Field("password") String password);

    @FormUrlEncoded
    @POST
    Call<LoginResponse> login_post(@Url String url, @Field("email") String email, @Field("password") String password, @Field("admin_id") String admin_id);

    @POST("location_updation")
    Call<LocationUpdateResponce> location_update(@Body RequestBody file);

    @FormUrlEncoded
    @POST
    Call<UserListResponse> getUser(@Url String url, @Field("admin_id") String admin_id);

    @FormUrlEncoded
    @POST
    Call<UserListResponse> getUserDetails(@Url String url, @Field("user_id") String user_id);



    @FormUrlEncoded
    @POST
    Call<Location_history_Response> getLocationHistory(@Url String url, @Field("user_id") String user_id);

    @FormUrlEncoded
    @POST
    Call<LiveLocationResponce> liveLocation(@Url String url, @Field("user_id") String user_id);


    @POST("sales-form-creation")
    Call<CRMResponce> sales_form(@Body RequestBody file);
    @POST("leads-update")
    Call<CRMResponce> sales_form_update(@Body RequestBody file);

    @FormUrlEncoded
    @POST
    Call<CRMListResponse> getCRMList(@Url String url, @Field("user_id") String user_id, @Field("type") String type, @Field("currentpage") String currentpage);
    @FormUrlEncoded
    @POST
    Call<CRMListResponse> getCRMLeadDetails(@Url String url, @Field("id") String id);
    @FormUrlEncoded
    @POST
    Call<DeleteResponce> delete_lead(@Url String url, @Field("user_id") String user_id,@Field("currentpage") int currentpage,@Field("id") String id);

    @FormUrlEncoded
    @POST
    Call<CRMListResponse> assign_to(@Url String url, @Field("assignbyId") String assignbyId, @Field("assigntoId") String assigntoId,@Field("assigned_id") String assigned_id,@Field("type") String type);

    @FormUrlEncoded
    @POST
    Call<CRMListResponse> get_filterCRMList(@Url String url, @Field("user_id") String user_id, @Field("type") String type,@Field("fromDate") String fromDate,@Field("toDate") String toDate, @Field("currentpage") String currentpage);

    /* @Multipart
    @POST("profile-update")
    Call<UpdateProfileResponce> updateProfile(@Part("user_id") RequestBody id,
                                              @Part("name") RequestBody name,
                                              @Part("email") RequestBody email,
                                              @Part("phone_number") RequestBody phone_number,
                                              @Part("password") RequestBody password,
                                              @Part("residential_address") RequestBody residential_address,
                                              @Part("business_address") RequestBody business_address,
                                              @Part("status") RequestBody status,
                                              @Part("approval") RequestBody approval,
                                              @Part("is_rate") RequestBody is_rate,
                                              @Part("is_comment") RequestBody is_comment,
                                              @Part("is_assign") RequestBody is_assign,
                                              @Part("roles") RequestBody roles,
                                              @Part MultipartBody.Part image);
    @FormUrlEncoded
    @POST
    Call<SocialAccountResponce> getSocialAccount(@Url String url, @Field("user_id") String user_type);

    @POST("user-send-message")
    Call<ReplyResponce> sendMessage(@Body RequestBody file);
    @POST("post-comment")
    Call<ReplyResponce> uploadMultiFile(@Body RequestBody file);
    @FormUrlEncoded
    @POST("social-account-add")
    Call<SocialAccountResponce> addSocialAccount(@FieldMap HashMap<String, Object> map);
    @FormUrlEncoded
    @POST("social-account-edit")
    Call<SocialAccountResponce> updateSocialAccount(@FieldMap HashMap<String, Object> map);
    @FormUrlEncoded
    @POST
    Call<SocialAccountResponce> deleteSocialAccount(@Url String url, @Field("user_id") String user_id, @Field("id") String id);




  //
    //

    @FormUrlEncoded
    @POST
    Call<AllPermissionResponce> getallRolePermission(@Url String url, @Field("id") String role_id);

    @FormUrlEncoded
    @POST
    Call<UserRoleDetailsResponce> getRolePermissions(@Url String url, @Field("id") String user_type);

    @FormUrlEncoded
    @POST("create-role")
    Call<RolePermissionUpdateResponce> createRole(@FieldMap HashMap<String, Object> map);

    @FormUrlEncoded
    @POST("role-update")
    Call<RolePermissionUpdateResponce> updateRole(@FieldMap HashMap<String, Object> map);
    @FormUrlEncoded
    @POST("role-delete")
    Call<UserRoleResponce> delete_role(@FieldMap HashMap<String, Object> map);





//    @FormUrlEncoded  role-delete
//    @POST
//    Call<UserRoleDetailsResponce> getUserRoleDetails(@Url String url, @Field("id") String user_type);

    @FormUrlEncoded
    @POST
    Call<PermissionsResponce> getall_Permission(@Url String url, @Field("user_id") String user_id);
    @FormUrlEncoded
    @POST("create-permission")
    Call<PermissionsResponce> create_permission(@FieldMap HashMap<String, Object> map);

    @FormUrlEncoded
    @POST("permission-update")
    Call<PermissionsResponce> update_permission(@FieldMap HashMap<String, Object> map);
    @FormUrlEncoded
    @POST("delete")
    Call<PermissionsResponce> delete_permission(@FieldMap HashMap<String, Object> map);








    @FormUrlEncoded
    @POST
    Call<GetMessageResponce> user_sent_message(@Url String url, @Field("user_id") String id);

    @GET
    Call<GetMessageResponce> user_message(@Url String url);


    @FormUrlEncoded
    @POST
    Call<MessageConversationResponce> user_message_details(@Url String url, @Field("user_id") String id, @Field("message_id") String message_id);


    @FormUrlEncoded
    @POST
    Call<SendMessageUserListResponce> getSendMessageUserList(@Url String url, @Field("user_id") String id);

    @FormUrlEncoded
    @POST
    Call<UserRoleResponce> getUserList(@Url String url, @Field("user_id") String id);

    @FormUrlEncoded
    @POST
    Call<KamClientResponce> getAssignClient(@Url String url, @Field("user_id") String user_id);

    @FormUrlEncoded
    @POST
    Call<KamClientResponce> removeAssignClient(@Url String url, @Field("user_id") String user_id, @Field("client_id") String client_id);

    @FormUrlEncoded
    @POST
    Call<AssignToClientListResponce> getUnassignClientList(@Url String url, @Field("user_id") String user_id);


    @FormUrlEncoded
    @POST("add-client-kam")
    Call<KamClientResponce> assign_client(@FieldMap HashMap<String, Object> map);

    @FormUrlEncoded
    @POST
    Call<RatingListResponce> client_rating(@Url String url, @Field("user_id") String id);

    @FormUrlEncoded
    @POST
    Call<RatingUserListResponce> rating_user_list(@Url String url, @Field("user_id") String id);

    @FormUrlEncoded
    @POST("create-rating")
    Call<RatingListResponce> addRatting(@FieldMap HashMap<String, Object> map);
    @FormUrlEncoded
    @POST("update-rating")
    Call<RatingListResponce> updateRatting(@FieldMap HashMap<String, Object> map);*/


   /* @FormUrlEncoded
    @POST("user-send-message")
    Call<LoginResponse> sendMessage(@FieldMap HashMap<String, Object> map);

    @FormUrlEncoded
    @POST("post-comment")
    Call<ReplyResponce> message_reply(@FieldMap HashMap<String, Object> map);*/

    /* @GET
    Call<GetCartItemsResponse> getCartItems(@Url String url);


    @FormUrlEncoded
    @POST
    Call<CheckoutResponse> checkOut(@Url String url, @Field("user_id") String userId);


    @FormUrlEncoded
    @POST
    Call<CheckoutResponse> get(@Url String url, @Field("user_id") String userId);

    @FormUrlEncoded
    @POST("user/transaction")
    Call<SaveTransactionResponse> saveTransaction(@FieldMap HashMap<String, Object> map);

    @GET
    Call<GetUserResponse> getUserProfile(@Url String url);

    @FormUrlEncoded
    @POST("user/clear-cart")
    Call<ClearCartResponse> clearCart(@Field("user_id") String userId);


    @FormUrlEncoded
    @POST("user/update-profile")
    Call<UpdateUserResponse> updateProfile(@FieldMap HashMap<String, Object> map);

    @GET
    Call<PreviousOrderResponce> getPreviousOrders(@Url String url);
    @FormUrlEncoded
    @POST("address/add-address")
    Call<AddAddressResponse> addAddress(@FieldMap HashMap<String, Object> map);


    @FormUrlEncoded
    @PUT("address/edit-address")
    Call<AddAddressResponse> editAddress(@FieldMap HashMap<String, Object> map);

    @FormUrlEncoded
    @HTTP(method = "DELETE", path = "address/delete-address", hasBody = true)
    Call<AddMeasurementResponse> deleteAddress(@FieldMap HashMap<String, Object> map);


    @GET
    Call<GetAddressResponse> getAddresses(@Url String url);

    @GET
    Call<GetMeasurementsResponse> getMeasurements(@Url String url);

    @FormUrlEncoded
    @POST("measurement/add-measurement")
    Call<AddMeasurementResponse> addMeasurement(@FieldMap HashMap<String, Object> map);


    @FormUrlEncoded
    @PUT("measurement/edit-measurement")
    Call<AddMeasurementResponse> editMeasurement(@FieldMap HashMap<String, Object> map);


    @FormUrlEncoded
    @HTTP(method = "DELETE", path = "measurement/delete-measurement", hasBody = true)
    Call<AddMeasurementResponse> deleteMeasurement(@FieldMap HashMap<String, Object> map);

    @GET
    Call<ColorResponce> getRepairColor(@Url String url);
    @GET
    Call<ShirtResponce> getGarments(@Url String url);
    @GET
    Call<ShirtResponce> getShirtBody(@Url String url);
    @GET
    Call<ColorResponce> getRepairFebric(@Url String url);

    @FormUrlEncoded
    @POST
    Call<EditCartResponse> createRenw(@Url String url, @FieldMap HashMap<String, Object> map);
    @GET
    Call<GetRenewResponce> getRenew(@Url String url);

    @FormUrlEncoded
    @HTTP(method = "DELETE", path = "user/delete-from-cart", hasBody = true)
    Call<DeleteCartResponce> deleteImage(@FieldMap HashMap<String, Object> map);

    @FormUrlEncoded
    @HTTP(method = "DELETE", path = "user/delete-from-cart", hasBody = true)
    Call<CheckoutResponse> deletecartItem(@FieldMap HashMap<String, Object> map);*/
}