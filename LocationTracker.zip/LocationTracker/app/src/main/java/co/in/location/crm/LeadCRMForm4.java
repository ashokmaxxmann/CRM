package co.in.location.crm;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import co.in.location.Helper;
import co.in.location.MainActivity;
import co.in.location.R;

public class LeadCRMForm4 extends Fragment implements View.OnClickListener {
    View view;
    EditText edt_keyword1, edt_keyword2, edt_keyword3, edt_keyword4, edt_keyword5, edt_keyword6, edt_keyword7,
            edt_gr1, edt_gr2, edt_gr3, edt_gr4, edt_gr5, edt_gr6, edt_gr7;
    TextView txt_next, txt1, txt2, txt3, txt4, txt5, txt6;
    int clickable = 0;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.sales_crm4, container, false);
        LeadCRMList.page4 = true;
        edt_keyword1 = (EditText) view.findViewById(R.id.edt_keyword1);
        edt_keyword2 = (EditText) view.findViewById(R.id.edt_keyword2);
        edt_keyword3 = (EditText) view.findViewById(R.id.edt_keyword3);
        edt_keyword4 = (EditText) view.findViewById(R.id.edt_keyword4);
        edt_keyword5 = (EditText) view.findViewById(R.id.edt_keyword5);
        edt_keyword6 = (EditText) view.findViewById(R.id.edt_keyword6);
        edt_keyword7 = (EditText) view.findViewById(R.id.edt_keyword7);
        edt_gr1 = (EditText) view.findViewById(R.id.edt_gr1);
        edt_gr2 = (EditText) view.findViewById(R.id.edt_gr2);
        edt_gr3 = (EditText) view.findViewById(R.id.edt_gr3);
        edt_gr4 = (EditText) view.findViewById(R.id.edt_gr4);
        edt_gr5 = (EditText) view.findViewById(R.id.edt_gr5);
        edt_gr6 = (EditText) view.findViewById(R.id.edt_gr6);
        edt_gr7 = (EditText) view.findViewById(R.id.edt_gr7);
        txt_next = (TextView) view.findViewById(R.id.txt_next);
        txt1 = (TextView) view.findViewById(R.id.txt1);
        txt2 = (TextView) view.findViewById(R.id.txt2);
        txt3 = (TextView) view.findViewById(R.id.txt3);
        txt4 = (TextView) view.findViewById(R.id.txt4);
        txt5 = (TextView) view.findViewById(R.id.txt5);
        txt6 = (TextView) view.findViewById(R.id.txt6);
        txt_next.setOnClickListener(this);
        txt1.setOnClickListener(this);
        txt2.setOnClickListener(this);
        txt3.setOnClickListener(this);
        txt4.setOnClickListener(this);
        txt5.setOnClickListener(this);
        txt6.setOnClickListener(this);
        if (LeadCRMForm1.from.equalsIgnoreCase("from_update")) {
            LeadCRMFormUpdate.update_page2=true;
        }
        else
        {
            MainActivity.add_page2=true;
        }
        executeMethode();
        return view;
    }

    @Override
    public void onClick(View v) {
        InputMethodManager inputManager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);

        inputManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        switch (v.getId()) {
            case R.id.txt_next:
                if (validation()) {
                    clickable = 5;
                    data_save();
                }
                break;
            case R.id.txt1:
                if (LeadCRMList.page1) {
                    clickable = 1;
                    data_save();
                }
                break;
            case R.id.txt2:
                if (LeadCRMList.page2) {
                    clickable = 2;
                    data_save();
                }
                break;
            case R.id.txt3:
                if (LeadCRMList.page3) {
                    clickable = 3;
                    data_save();
                }
                break;
            case R.id.txt4:
                if (LeadCRMList.page4) {
                    clickable = 4;
                    data_save();
                }
                break;
            case R.id.txt5:
                if (LeadCRMList.page5) {
                    clickable = 5;
                    data_save();
                }
                break;
            case R.id.txt6:
                if (LeadCRMList.page6) {
                    clickable = 6;
                    data_save();
                }
                break;
        }
    }

    public boolean validation() {

        return true;
    }

    public void data_save() {
        Helper.storeLocally(getActivity(), "Ranking_Keyword_1", edt_keyword1.getText().toString());
        Helper.storeLocally(getActivity(), "Global_Rank_Keyword_1", edt_gr1.getText().toString());
        Helper.storeLocally(getActivity(), "Ranking_Keyword_2", edt_keyword2.getText().toString());
        Helper.storeLocally(getActivity(), "Global_Rank_Keyword_2", edt_gr2.getText().toString());
        Helper.storeLocally(getActivity(), "Ranking_Keyword_3", edt_keyword3.getText().toString());
        Helper.storeLocally(getActivity(), "Global_Rank_Keyword_3", edt_gr3.getText().toString());
        Helper.storeLocally(getActivity(), "Ranking_Keyword_4", edt_keyword4.getText().toString());
        Helper.storeLocally(getActivity(), "Global_Rank_Keyword_4", edt_gr4.getText().toString());
        Helper.storeLocally(getActivity(), "Ranking_Keyword_5", edt_keyword5.getText().toString());
        Helper.storeLocally(getActivity(), "Global_Rank_Keyword_5", edt_gr5.getText().toString());
        Helper.storeLocally(getActivity(), "Ranking_Keyword_6", edt_keyword6.getText().toString());
        Helper.storeLocally(getActivity(), "Global_Rank_Keyword_6", edt_gr6.getText().toString());
        Helper.storeLocally(getActivity(), "Ranking_Keyword_7", edt_keyword7.getText().toString());
        Helper.storeLocally(getActivity(), "Global_Rank_Keyword_7", edt_gr7.getText().toString());

        if (clickable == 1) {
            Fragment fragment = new LeadCRMForm1();
            Bundle bundle = new Bundle();
            if (LeadCRMForm1.from.equalsIgnoreCase("from_update")) {
                bundle.putString("from", "from_update");
            }
            else
            {
                bundle.putString("from", "from_add");
            }
            fragment.setArguments(bundle);
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page1");
            ft.commit();
        } else if (clickable == 2) {
            Fragment fragment = new LeadCRMForm2();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page2");
            ft.commit();
        } else if (clickable == 3) {
            Fragment fragment = new LeadCRMForm3();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page3");
            ft.commit();
        } else if (clickable == 4) {
        } else if (clickable == 5) {
            Fragment fragment = new LeadCRMForm5();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page5");
            ft.commit();
        } else if (clickable == 6) {
            Fragment fragment = new LeadCRMForm6();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page6");
            ft.commit();
        }
    }

    public void executeMethode() {
        edt_keyword1.setText(Helper.getLocalValue(getActivity(), "Ranking_Keyword_1"));
        edt_gr1.setText(Helper.getLocalValue(getActivity(), "Global_Rank_Keyword_1"));
        edt_keyword2.setText(Helper.getLocalValue(getActivity(), "Ranking_Keyword_2"));
        edt_gr2.setText(Helper.getLocalValue(getActivity(), "Global_Rank_Keyword_2"));
        edt_keyword3.setText(Helper.getLocalValue(getActivity(), "Ranking_Keyword_3"));
        edt_gr3.setText(Helper.getLocalValue(getActivity(), "Global_Rank_Keyword_3"));
        edt_keyword4.setText(Helper.getLocalValue(getActivity(), "Ranking_Keyword_4"));
        edt_gr4.setText(Helper.getLocalValue(getActivity(), "Global_Rank_Keyword_4"));
        edt_keyword5.setText(Helper.getLocalValue(getActivity(), "Ranking_Keyword_5"));
        edt_gr5.setText(Helper.getLocalValue(getActivity(), "Global_Rank_Keyword_5"));
        edt_keyword6.setText(Helper.getLocalValue(getActivity(), "Ranking_Keyword_6"));
        edt_gr6.setText(Helper.getLocalValue(getActivity(), "Global_Rank_Keyword_6"));
        edt_keyword7.setText(Helper.getLocalValue(getActivity(), "Ranking_Keyword_7"));
        edt_gr7.setText(Helper.getLocalValue(getActivity(), "Global_Rank_Keyword_7"));
    }
}
