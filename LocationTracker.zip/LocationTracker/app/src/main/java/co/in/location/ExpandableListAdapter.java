package co.in.location;

import android.content.Context;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.HashMap;
import java.util.List;

public class ExpandableListAdapter extends BaseExpandableListAdapter {
    private Context context;
    private List<String> listDataHeader;
    private HashMap<String, List<String>> listDataChild;
    int[] icons;

    public ExpandableListAdapter(Context context, List<String> listDataHeader, HashMap<String, List<String>> listChildData, int[] icons) {
        this.context = context;
        this.listDataHeader = listDataHeader;
        this.listDataChild = listChildData;
        this.icons = icons;
    }

    @Override
    public String getChild(int groupPosition, int childPosititon) {
        return this.listDataChild.get(this.listDataHeader.get(groupPosition)).get(childPosititon);
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public View getChildView(int groupPosition, final int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {

        final String childText = getChild(groupPosition, childPosition);

        if (convertView == null) {
            LayoutInflater infalInflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = infalInflater.inflate(R.layout.list_group_child, null);
        }

        TextView txtListChild = (TextView) convertView.findViewById(R.id.lblListItem);
        ImageView img = (ImageView) convertView.findViewById(R.id.img);
        RelativeLayout rl_layout = (RelativeLayout) convertView.findViewById(R.id.rl_layout);
        txtListChild.setText(childText);
//        txtListChild.setTextColor(Color.parseColor("#000000"));
        if ((childPosition == MainActivity.selecte_childPosition) && (groupPosition == MainActivity.selected_groupPosition)) {
            txtListChild.setTextColor(ContextCompat.getColor(context, R.color.button));
            img.setBackgroundResource(R.drawable.ic_circle_selected);
            rl_layout.setBackgroundResource(R.color.menu_list);
        } else {
            txtListChild.setTextColor(ContextCompat.getColor(context, R.color.white));
            img.setBackgroundResource(R.drawable.ic_circle);
            rl_layout.setBackgroundResource(R.color.menu_list);
        }

        return convertView;
    }

    @Override
    public int getChildrenCount(int groupPosition) {

        if (this.listDataChild.get(this.listDataHeader.get(groupPosition)) == null) return 0;
        else return this.listDataChild.get(this.listDataHeader.get(groupPosition)).size();
    }

    @Override
    public String getGroup(int groupPosition) {
        return this.listDataHeader.get(groupPosition);
    }

    @Override
    public int getGroupCount() {
        return this.listDataHeader.size();

    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        String headerTitle = getGroup(groupPosition);
        if (convertView == null) {
            LayoutInflater infalInflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = infalInflater.inflate(R.layout.list_group_header, null);
        }

        TextView lblListHeader = (TextView) convertView.findViewById(R.id.lblListHeader);
        ImageView img = (ImageView) convertView.findViewById(R.id.img_parent);
//        lblListHeader.setTypeface(null, Typeface.BOLD);
        lblListHeader.setText(headerTitle);
        if (Helper.getLocalValue(context, "user_designation").equalsIgnoreCase("admin")) {
            if (headerTitle.equalsIgnoreCase("All Sales Rep.")) {
                img.setBackgroundResource(icons[0]);
            } else if (headerTitle.equalsIgnoreCase("Leads")) {
                img.setBackgroundResource(icons[1]);
            } else if (headerTitle.equalsIgnoreCase("Deals")) {
                img.setBackgroundResource(icons[2]);
            } else if (headerTitle.equalsIgnoreCase("Add Sales Rep.")) {
                img.setBackgroundResource(icons[3]);
            } else if (headerTitle.equalsIgnoreCase("Users Location")) {
                img.setBackgroundResource(icons[4]);
            } else if (headerTitle.equalsIgnoreCase("Edit Profile")) {
                img.setBackgroundResource(icons[5]);
            } else if (headerTitle.equalsIgnoreCase("Logout")) {
                img.setBackgroundResource(icons[6]);
            }
        } else {
            if (headerTitle.equalsIgnoreCase("My Location")) {
                img.setBackgroundResource(icons[0]);
            } /*else if (headerTitle.equalsIgnoreCase("Location History")) {
                img.setBackgroundResource(icons[1]);
            }*/ else if (headerTitle.equalsIgnoreCase("Leads")) {
                img.setBackgroundResource(icons[1]);
            } else if (headerTitle.equalsIgnoreCase("Deals")) {
                img.setBackgroundResource(icons[2]);
            } else if (headerTitle.equalsIgnoreCase("Edit Profile")) {
                img.setBackgroundResource(icons[3]);
            } else if (headerTitle.equalsIgnoreCase("Logout")) {
                img.setBackgroundResource(icons[4]);
            }
        }


//        img.setBackgroundResource(icons[groupPosition]);

       /* RelativeLayout rl_layout=(RelativeLayout)convertView.findViewById(R.id.rl_layout);
        if (groupPosition == MainActivity.selected_groupPosition)
        {
            rl_layout.setBackgroundResource(R.color.button);
            lblListHeader.setTextColor(context.getResources().getColor(R.color.white));
        }
        else
        {
            rl_layout.setBackgroundResource(R.color.white);
            lblListHeader.setTextColor(context.getResources().getColor(R.color.black));
        }
        if (listDataChild.get(this.listDataHeader.get(groupPosition)).size() > 0) {
            lblListHeader.setCompoundDrawablesWithIntrinsicBounds(0, 0, isExpanded ? R.mipmap.arrowdown : R.mipmap.arrowforword, 0);
        } else {
            lblListHeader.setCompoundDrawablesWithIntrinsicBounds(0, 0, isExpanded ? 0 : 0, 0);

        }*/

        RelativeLayout rl_layout = (RelativeLayout) convertView.findViewById(R.id.rl_layout);
        if (groupPosition == MainActivity.selected_groupPosition) {
            rl_layout.setBackgroundResource(R.color.white);
            lblListHeader.setTextColor(context.getResources().getColor(R.color.menu_image_color));
            img.getBackground().setColorFilter(context.getResources().getColor(R.color.menu_image_color), PorterDuff.Mode.SRC_IN);
            if (listDataChild.get(this.listDataHeader.get(groupPosition)).size() > 0) {
                lblListHeader.setCompoundDrawablesWithIntrinsicBounds(0, 0, isExpanded ? R.drawable.dropdown_active : R.drawable.right_arrow, 0);
            } else {
                lblListHeader.setCompoundDrawablesWithIntrinsicBounds(0, 0,0, 0);
            }
        } else {
            rl_layout.setBackgroundResource(R.color.menu_list);
            lblListHeader.setTextColor(context.getResources().getColor(R.color.white));
            if (listDataChild.get(this.listDataHeader.get(groupPosition)).size() > 0) {
                lblListHeader.setCompoundDrawablesWithIntrinsicBounds(0, 0, isExpanded ? R.drawable.dropdown_active : R.drawable.right_arrow_white, 0);
            } else {
                lblListHeader.setCompoundDrawablesWithIntrinsicBounds(0, 0,0, 0);
            }
            img.getBackground().setColorFilter(context.getResources().getColor(R.color.white), PorterDuff.Mode.SRC_IN);
        }
        return convertView;
    }


    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }
}