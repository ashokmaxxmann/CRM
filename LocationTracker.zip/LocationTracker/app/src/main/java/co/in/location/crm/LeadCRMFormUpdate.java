package co.in.location.crm;

import android.content.DialogInterface;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatDelegate;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.FrameLayout;

import co.in.location.Helper;
import co.in.location.R;

public class LeadCRMFormUpdate extends AppCompatActivity {
    FrameLayout frameLayout;
    public static LeadCRMFormUpdate leadCRMFormUpdate;
    public static Menu menu_value;
    public static boolean update_page2 = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        setContentView(R.layout.lead_crmform_update);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        frameLayout = (FrameLayout) findViewById(R.id.frame);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Lead Update");

        Fragment fragment = new LeadCRMForm1();
        Bundle bundle = new Bundle();
        bundle.putString("from", "from_update");
        fragment.setArguments(bundle);
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.frame, fragment);
//        ft.addToBackStack("update");
        ft.commit();
        leadCRMFormUpdate = this;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_cancel, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        menu_value = menu;
        if(update_page2)
        {
            menu.getItem(0).setVisible(true);
        }
        else
        {
            menu.getItem(0).setVisible(false);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // todo: goto back activity from here
//                LeadCRMFormUpdate.this.finish();
                android.support.v4.app.FragmentManager fm = getSupportFragmentManager();
                int size = fm.getBackStackEntryCount();
                if (size >= 1) {
                    getSupportFragmentManager().popBackStack();
                } else {
                    alert();
                }

                return true;
            case R.id.cancel_menu:
                alert();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void alert() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(LeadCRMFormUpdate.this);
        alertDialogBuilder.setTitle("Are you sure,You want to cancel?");
        alertDialogBuilder.setMessage("All updated data will be erased.");
        alertDialogBuilder.setCancelable(false);
        alertDialogBuilder.setPositiveButton("yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        Method_execute();
                    }
                });

        alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    public void Method_execute() {
        Helper.storeLocally(LeadCRMFormUpdate.this, "number", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "first_name", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "last_name", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "company_name", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "title", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "city_name", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "address", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "loction_name", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "state", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "pincode", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "phone", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "mobile", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "additonal_contact", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "email", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "lead_source", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "no_employee", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "annual_revenue", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "industry", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "lead_owner", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "sales_person", "");


        Helper.storeLocally(LeadCRMFormUpdate.this, "google_reviews", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Just_Dial_Reviews", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "facebook_reviews", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Other_Social_Channel_Reviews", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Fb_likes", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "FB_Followers", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Response_Rate", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Engagement_Rate", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Linkedin_Followers", "");

        Helper.storeLocally(LeadCRMFormUpdate.this, "Website", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Website_Technology", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Website_information", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Website_Type", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Overlook_and_Feels", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Website_Language", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Content_Quality", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Graphic_Quality", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Global_Rank", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "total_score", "");


        Helper.storeLocally(LeadCRMFormUpdate.this, "Ranking_Keyword_1", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Global_Rank_Keyword_1", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Ranking_Keyword_2", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Global_Rank_Keyword_2", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Ranking_Keyword_3", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Global_Rank_Keyword_3", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Ranking_Keyword_4", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Global_Rank_Keyword_4", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Ranking_Keyword_5", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Global_Rank_Keyword_5", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Ranking_Keyword_6", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Global_Rank_Keyword_6", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Ranking_Keyword_7", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Global_Rank_Keyword_7", "");


        Helper.storeLocally(LeadCRMFormUpdate.this, "First_Actions", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "First_Action_Remarks", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Second_Actions", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Second_Action_Remarks", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Third_Actions", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Third_Action_Remarks", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Fourth_Actions", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Fouth_Action_Remarks", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Fifth_Actions", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Fifth_Action_Remarks", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Final_Actions", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Final_Action_Remarks", "");


        Helper.storeLocally(LeadCRMFormUpdate.this, "Proposal_Sent_For", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Proposal_Sent_On", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Total_value", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Expected_Closure_Date", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Proposal_not_sent_for", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Reason", "");
        Helper.storeLocally(LeadCRMFormUpdate.this, "Status", "");

        LeadCRMFormUpdate.this.finish();
    }

    @Override
    public void onBackPressed() {
        android.support.v4.app.FragmentManager fm = getSupportFragmentManager();
        int size = fm.getBackStackEntryCount();
        if (size >= 1) {
            getSupportFragmentManager().popBackStack();
        } else {
            alert();
        }

    }
}
