package co.in.location.data;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class LocationData {
    @SerializedName("user_id")
    @Expose
    public String user_id;
    @SerializedName("name")
    @Expose
    public String name;
    @SerializedName("date")
    @Expose
    public String date;
    @SerializedName("latitude")
    @Expose
    public String latitude;
    @SerializedName("longitude")
    @Expose
    public String longitude;
    @SerializedName("location")
    @Expose
    public String location;
    @SerializedName("image_path")
    @Expose
    public String profile_image;
}
