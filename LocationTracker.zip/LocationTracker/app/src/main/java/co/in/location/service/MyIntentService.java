package co.in.location.service;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.widget.Toast;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import co.in.location.Helper;
import co.in.location.Remote.ApiUtils;
import co.in.location.response.LocationUpdateResponce;
import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MyIntentService extends Service {
    private Timer timer;
    private static final String TAG = "MyLocationService";
    final Handler handler = new Handler();

    Location location;
    private static final long MIN_DISTANCE_CHANGE_FOR_UPDATES = 10;
    private static final long MIN_TIME_BW_UPDATES = 60 * 1000;
    protected LocationManager locationManager;
    String currentAddress, duration, distance;

    private class LocationListener implements android.location.LocationListener {
        public LocationListener(String provider) {
            Log.e(TAG, "LocationListener " + provider);
            location = new Location(provider);
        }

        @Override
        public void onLocationChanged(Location locations) {
            Log.e(TAG, "onLocationChanged: " + locations);
            location.set(locations);
//            onLocationUpdate(location);
        }

        @Override
        public void onProviderDisabled(String provider) {
            Log.e(TAG, "onProviderDisabled: " + provider);
        }

        @Override
        public void onProviderEnabled(String provider) {
            Log.e(TAG, "onProviderEnabled: " + provider);
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
            Log.e(TAG, "onStatusChanged: " + provider);
        }
    }

    LocationListener[] mLocationListeners = new LocationListener[]{
            new LocationListener(LocationManager.PASSIVE_PROVIDER)
    };

    @Override
    public IBinder onBind(Intent arg0) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.e(TAG, "onStartCommand");
        super.onStartCommand(intent, flags, startId);
        return START_STICKY;
    }

    @Override
    public void onCreate() {
        timer = new Timer();
        timer.scheduleAtFixedRate(timerTask, 0, 60 * 1000);
        Log.e(TAG, "onCreate");
        try {
            getLocation();
        } catch (SecurityException ex) {
            Log.i(TAG, "fail to request location update, ignore", ex);
        } catch (IllegalArgumentException ex) {
            Log.d(TAG, "network provider does not exist, " + ex.getMessage());
        }


    }

    @Override
    public void onDestroy() {
        Log.e(TAG, "onDestroy");
        super.onDestroy();
        if (locationManager != null) {
            for (int i = 0; i < mLocationListeners.length; i++) {
                try {
                    if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        return;
                    }
                    locationManager.removeUpdates(mLocationListeners[i]);
                } catch (Exception ex) {
                    Log.i(TAG, "fail to remove location listener, ignore", ex);
                }
            }
        }
    }

    TimerTask timerTask = new TimerTask() {
        @Override
        public void run() {
            handler.post(new Runnable() {
                public void run() {
                    int duration = Toast.LENGTH_SHORT;
//                    Toast toast = Toast.makeText(getApplicationContext(), "ashok", duration);
                    if (Helper.getLocalValue(getApplicationContext(), "user_id") != null) {
                        if(!Helper.getLocalValue(getApplicationContext(), "user_designation") .equalsIgnoreCase("admin"))
                        {
                            onLocationUpdate(location);
                        }

                    }

//                    toast.show();
                }
            });


            Log.e("backgroundService", new Date().toString());
            Log.e("location", locationManager == null ? "null" : "latitude: " + location.getLatitude() + ", longitude: " + location.getLongitude());
        }
    };

    @SuppressLint("MissingPermission")
    public Location getLocation() {
        try {
            locationManager = (LocationManager) this.getSystemService(LOCATION_SERVICE);
            boolean isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            boolean isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            if (!isGPSEnabled && !isNetworkEnabled) {
            } else {
                if (isNetworkEnabled) {
                    locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, MIN_TIME_BW_UPDATES, MIN_DISTANCE_CHANGE_FOR_UPDATES, mLocationListeners[0]);
                    if (locationManager != null) {
                        location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                        if (location != null) {
//                            onLocationUpdate(location);
                        }
                    }
                }
                // If GPS enabled, get latitude/longitude using GPS Services
                if (isGPSEnabled) {
                    if (location == null) {
                        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, MIN_TIME_BW_UPDATES, MIN_DISTANCE_CHANGE_FOR_UPDATES, mLocationListeners[0]);
                        //    Log.d("GPS Enabled", "GPS Enabled");
                        if (locationManager != null) {
                            location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                            if (location != null) {
//                                onLocationUpdate(location);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return location;
    }

    private void onLocationUpdate(Location location) {
        Log.e("location", "Location changed: Latitude:" + location.getLatitude() + ", Longitude: " + location.getLongitude());
        if (location.getLatitude() > 0.0) {
            currentAddress = getCompleteAddressString(location.getLatitude(), location.getLongitude());
        } else {
            currentAddress = "Location not found";
            Toast.makeText(this, "Please enable gps", Toast.LENGTH_SHORT).show();

        }
            updateLocation();

//        Toast.makeText(this, "Location changed: Latitude:" + location.getLatitude() + ", Longitude: " + location.getLongitude(), Toast.LENGTH_SHORT).show();
    }

    public void updateLocation() {

        DateFormat df = new SimpleDateFormat("yyyy-MM-dd,HH:mm:ss");
        String date_time = df.format(Calendar.getInstance().getTime());
        MultipartBody.Builder builder = new MultipartBody.Builder();
        builder.setType(MultipartBody.FORM);

        builder.addFormDataPart("user_id", Helper.getLocalValue(this, "user_id"));
        builder.addFormDataPart("latitude", String.valueOf(location.getLatitude()));
        builder.addFormDataPart("longitude", String.valueOf(location.getLongitude()));
        builder.addFormDataPart("location", currentAddress);
        builder.addFormDataPart("currentDate", date_time);
        if (distance == null)
            distance = "Not getting";
        builder.addFormDataPart("distance", distance);
        if (duration == null)
            duration = "Not getting";
        builder.addFormDataPart("stop", duration);


        MultipartBody requestBody = builder.build();
        Call<LocationUpdateResponce> call = ApiUtils.getAlterationService().location_update(requestBody);
        call.enqueue(new Callback<LocationUpdateResponce>() {
            @Override
            public void onResponse(Call<LocationUpdateResponce> call, Response<LocationUpdateResponce> response) {

                /*   Toast.makeText(getApplicationContext(), "Success " + response.message(), Toast.LENGTH_LONG).show();*/
                try {
                    if (response.code() == 200) {
                        if (response.body().statusCode == 1) {
//                            Toast.makeText(getApplicationContext(), response.body().message, Toast.LENGTH_SHORT).show();
                        } else {
//                            Toast.makeText(getApplicationContext(), response.body().message, Toast.LENGTH_SHORT).show();
                        }
                    } else {
//                        Toast.makeText(getApplicationContext(), response.body().message, Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LocationUpdateResponce> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public String getCompleteAddressString(double LATITUDE, double LONGITUDE) {

        Geocoder geocoder;
        List<Address> addresses;
        String address = "not found";
        geocoder = new Geocoder(getApplicationContext(), Locale.ENGLISH);

        try {
            addresses = geocoder.getFromLocation(LATITUDE, LONGITUDE, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
            if (addresses != null) {
                address = addresses.get(0).getAddressLine(0);
            } else {
                address = "No Address returned!";
            }
             /* address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
            String city = addresses.get(0).getLocality();
            String state = addresses.get(0).getAdminArea();
            String country = addresses.get(0).getCountryName();
            String postalCode = addresses.get(0).getPostalCode();
            String knownName = addresses.get(0).getFeatureName();*/
        } catch (IOException e) {
            e.printStackTrace();
        }
        return address;
    }

}
