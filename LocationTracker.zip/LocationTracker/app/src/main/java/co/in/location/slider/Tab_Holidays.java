package co.in.location.slider;

import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import co.in.location.DBHelper;
import co.in.location.R;

public class Tab_Holidays extends Fragment {
    LinearLayout layout;
    LinearLayout.LayoutParams paramstext;
    TextView txtview;
    DBHelper mydb;
    Cursor c;
    int length;
    String name,date;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab_holidays, container, false);

        mydb = new DBHelper(getActivity());

        layout = (LinearLayout) view.findViewById(R.id.layout);
        layout.setPadding(0,20,0,30);
        paramstext = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        paramstext.gravity = Gravity.CENTER_HORIZONTAL;

        Methodexecute();

        return view;
    }
    public void Methodexecute() {
        c = mydb.getholidays();
       length = c.getCount();

        if (c != null) {
            c.moveToFirst();
        }

        if(length>0)
        {
            do {
                try {

                    name = c.getString(c.getColumnIndex("name"));
                    date = c.getString(c.getColumnIndex("date"));

                    txtview = new TextView(getActivity());
                    txtview.setSingleLine(true);
                    txtview.setText(name);
                    txtview.setBackgroundResource(R.color.marque);
                    txtview.setTextColor(Color.WHITE);
                    txtview.setTextSize(18);
                    txtview.setPadding(30,10,30, 10);
                    txtview.setLayoutParams(paramstext);
                    layout.addView(txtview);

                    txtview = new TextView(getActivity());
                    txtview.setSingleLine(true);
                    txtview.setText(date);
                    txtview.setTextColor(Color.BLACK);
                    txtview.setTextSize(17);
                    txtview.setPadding(0,10,0,20);
                    txtview.setLayoutParams(paramstext);
                    layout.addView(txtview);





                } catch (IndexOutOfBoundsException e) {

                } catch (OutOfMemoryError e) {

                } catch (Exception e) {
                    e.printStackTrace();
                }
            } while (c.moveToNext());

        }

    }
}
