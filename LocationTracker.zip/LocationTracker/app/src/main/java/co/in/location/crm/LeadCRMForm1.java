package co.in.location.crm;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListPopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import co.in.location.Helper;
import co.in.location.MainActivity;
import co.in.location.R;
import co.in.location.Utility;
import de.hdodenhof.circleimageview.CircleImageView;

public class LeadCRMForm1 extends Fragment implements View.OnClickListener {
    View view;
    EditText edt_serial_no, edt_f_name, edt_l_name, edt_company, edt_title, edt_address, edt_location, edt_city, edt_state, edt_pincode, edt_phone, edt_mobile, edt_contact,
            edt_email, edt_lead_source, edt_no_employee, edt_annual_revenue, edt_industry, edt_sales_person, edt_lead_owner;
    TextView txt_next, txt1, txt2, txt3, txt4, txt5, txt6;

    private String[] list_lead_source = new String[]{"Advertisement from Newspaper", "SMS", "Incoming Call", "Email", "Chat", "Email  Campaign", "Facebook", "Google+", "Personal References", "Self Visit", "Twitter", "Web Research", "Others"};
    private String[] list_industry = new String[]{"Agriculture and Allied Activities", "Travel Agents", "Coaching Institutes", "Electronic Goods Showrooms", "Education", "Mining & Quarrying", "Manufacturing", "Electricity, Gas & Water companies", "Construction", "Trading", "Transport, storage and Communications", "Finance", "Insurance", "Real Estate and Renting", "Business Services", "Community, personal & Social Services", "Beauty Parlours", "Chemist Shops", "Clothing Stores", "Cosmetics Dealers", "Government Organisations", "Gym", "Health Supplements", "Hospitals", "Immigration Consultants", "Jewellery", "Movie Theatre", "Night Clubs", "Pharmaceutical Industries", "Real Estate", "Shoe Dealers", "Shopping Malls", "Spectacles", "Tattoo parlours", "Video game Parlours", "Wrist watch dealers", "Others"};
    private String[] list_salesperson = new String[]{"Ankush", "Sushmita", "Swati", "Nazim", "Jaskirat"};
    private String[] list_lead_owner = new String[]{"Sushmita Chauhan,\nsushmita@maxxmann.com", "sales,\nsales@maxxmann.com"};
    private String[] list_sirname = new String[]{"Mr.", "Mrs.", "Ms.", "Dr.", "Prof."};

    private ListPopupWindow pw_lead_source;
    private ListPopupWindow pw_industry;
    private ListPopupWindow pw_salesperson;
    private ListPopupWindow pw_lead_owner;
    private ListPopupWindow pw_sir_name;
    CircleImageView profile_image;
    ImageView img_option;
    private int REQUEST_CAMERA = 0, SELECT_FILE = 1;
    public static String realPath;
    public static String from = "from_add";
    int clickable = 0;

    EditText edt_other_lead_source, edt_other_sales_person, edt_other_industry, edt_other_lead_owner;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        setHasOptionsMenu(true);
        view = inflater.inflate(R.layout.sales_crm1, container, false);
        LeadCRMList.page1 = true;
        edt_serial_no = (EditText) view.findViewById(R.id.edt_serial_no);
//        edt= (EditText) view.findViewById(R.id.edt);
        edt_f_name = (EditText) view.findViewById(R.id.edt_f_name);
        edt_l_name = (EditText) view.findViewById(R.id.edt_l_name);
        edt_company = (EditText) view.findViewById(R.id.edt_company);
        edt_title = (EditText) view.findViewById(R.id.edt_title);
        edt_address = (EditText) view.findViewById(R.id.edt_address);
        edt_location = (EditText) view.findViewById(R.id.edt_location);
        edt_city = (EditText) view.findViewById(R.id.edt_city);
        edt_state = (EditText) view.findViewById(R.id.edt_state);
        edt_pincode = (EditText) view.findViewById(R.id.edt_pincode);
        edt_phone = (EditText) view.findViewById(R.id.edt_phone);
        edt_mobile = (EditText) view.findViewById(R.id.edt_mobile);
        edt_contact = (EditText) view.findViewById(R.id.edt_contact);
        edt_email = (EditText) view.findViewById(R.id.edt_email);
        edt_lead_source = (EditText) view.findViewById(R.id.edt_lead_source);
        edt_no_employee = (EditText) view.findViewById(R.id.edt_no_employee);
        edt_annual_revenue = (EditText) view.findViewById(R.id.edt_annual_revenue);
        edt_industry = (EditText) view.findViewById(R.id.edt_industry);
        edt_sales_person = (EditText) view.findViewById(R.id.edt_sales_person);
        edt_lead_owner = (EditText) view.findViewById(R.id.edt_lead_owner);

        profile_image = (CircleImageView) view.findViewById(R.id.profile_image);
        profile_image.setOnClickListener(this);
        img_option = (ImageView) view.findViewById(R.id.img_option);
        img_option.setOnClickListener(this);
        txt_next = (TextView) view.findViewById(R.id.txt_next);
        txt1 = (TextView) view.findViewById(R.id.txt1);
        txt2 = (TextView) view.findViewById(R.id.txt2);
        txt3 = (TextView) view.findViewById(R.id.txt3);
        txt4 = (TextView) view.findViewById(R.id.txt4);
        txt5 = (TextView) view.findViewById(R.id.txt5);
        txt6 = (TextView) view.findViewById(R.id.txt6);

        edt_other_lead_source = (EditText) view.findViewById(R.id.edt_other_lead_source);
        edt_other_sales_person = (EditText) view.findViewById(R.id.edt_other_sales_person);
        edt_other_industry = (EditText) view.findViewById(R.id.edt_other_industry);
        edt_other_lead_owner = (EditText) view.findViewById(R.id.edt_other_lead_owner);


        pw_lead_source = new ListPopupWindow(getActivity());
        pw_lead_source.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_lead_source));
        pw_lead_source.setAnchorView(edt_lead_source);
        pw_lead_source.setModal(true);
        pw_lead_source.setHeight(500);
        pw_lead_source.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_lead_source.setText(list_lead_source[position]);
                pw_lead_source.dismiss();
                if (list_lead_source[position].equalsIgnoreCase("Others")) {
                    edt_other_lead_source.setVisibility(View.VISIBLE);
                } else {
                    edt_other_lead_source.setVisibility(View.GONE);
                }
            }
        });
        pw_industry = new ListPopupWindow(getActivity());
        pw_industry.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_industry));
        pw_industry.setAnchorView(edt_industry);
        pw_industry.setModal(true);
        pw_industry.setHeight(500);
        pw_industry.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_industry.setText(list_industry[position]);
                pw_industry.dismiss();
                if (list_industry[position].equalsIgnoreCase("Others")) {
                    edt_other_industry.setVisibility(View.VISIBLE);
                } else {
                    edt_other_industry.setVisibility(View.GONE);
                }
            }
        });

        pw_salesperson = new ListPopupWindow(getActivity());
        pw_salesperson.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_salesperson));
        pw_salesperson.setAnchorView(edt_sales_person);
        pw_salesperson.setModal(true);
        pw_salesperson.setHeight(500);
        pw_salesperson.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_sales_person.setText(list_salesperson[position]);
                pw_salesperson.dismiss();
                if (list_salesperson[position].equalsIgnoreCase("Others")) {
                    edt_other_sales_person.setVisibility(View.VISIBLE);
                } else {
                    edt_other_sales_person.setVisibility(View.GONE);
                }
            }
        });

        pw_lead_owner = new ListPopupWindow(getActivity());
        pw_lead_owner.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_lead_owner));
        pw_lead_owner.setAnchorView(edt_lead_owner);
        pw_lead_owner.setModal(true);
        pw_lead_owner.setHeight(500);
        pw_lead_owner.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_lead_owner.setText(list_lead_owner[position]);
                pw_lead_owner.dismiss();
                if (list_lead_owner[position].equalsIgnoreCase("Others")) {
                    edt_other_lead_owner.setVisibility(View.VISIBLE);
                } else {
                    edt_other_lead_owner.setVisibility(View.GONE);
                }
            }
        });
       /* pw_sir_name = new ListPopupWindow(getActivity());
        pw_sir_name.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_sirname));
        pw_sir_name.setAnchorView(edt);
        pw_sir_name.setModal(true);
        pw_sir_name.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt.setText(list_sirname[position]);
                pw_sir_name.dismiss();
            }
        });
        edt.setOnClickListener(this);*/
        edt_lead_source.setOnClickListener(this);
        edt_industry.setOnClickListener(this);
        edt_sales_person.setOnClickListener(this);
        edt_lead_owner.setOnClickListener(this);
        txt_next.setOnClickListener(this);

        txt1.setOnClickListener(this);
        txt2.setOnClickListener(this);
        txt3.setOnClickListener(this);
        txt4.setOnClickListener(this);
        txt5.setOnClickListener(this);
        txt6.setOnClickListener(this);


        from = getArguments().getString("from");
        if (from.equalsIgnoreCase("from_update")) {
            ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Edit Lead");
            LeadCRMFormUpdate.update_page2=false;
        } else if (from.equalsIgnoreCase("from_add")) {
            ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Create Lead");
            MainActivity.add_page2=false;
        }
        executeMethode();
        return view;
    }

    private int measureContentWidth(ListAdapter listAdapter) {
        ViewGroup mMeasureParent = null;
        int maxWidth = 0;
        View itemView = null;
        int itemType = 0;

        final ListAdapter adapter = listAdapter;
        final int widthMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        final int heightMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        final int count = adapter.getCount();
        for (int i = 0; i < count; i++) {
            final int positionType = adapter.getItemViewType(i);
            if (positionType != itemType) {
                itemType = positionType;
                itemView = null;
            }

            if (mMeasureParent == null) {
                mMeasureParent = new FrameLayout(getActivity());
            }

            itemView = adapter.getView(i, itemView, mMeasureParent);
            itemView.measure(widthMeasureSpec, heightMeasureSpec);

            final int itemWidth = itemView.getMeasuredWidth();

            if (itemWidth > maxWidth) {
                maxWidth = itemWidth;
            }
        }

        return maxWidth;
    }

    @Override
    public void onClick(View v) {
        InputMethodManager inputManager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);

        inputManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        switch (v.getId()) {
            case R.id.profile_image:
                boolean result = Utility.checkPermission(getActivity());
                if (result) {
                    selectImage();
                } else {
                    Toast.makeText(getActivity(), "Permission not granted", Toast.LENGTH_LONG).show();
                }
                break;
            case R.id.img_option:
                boolean results = Utility.checkPermission(getActivity());
                if (results) {
                    selectImage();
                } else {
                    Toast.makeText(getActivity(), "Permission not granted", Toast.LENGTH_LONG).show();
                }
                break;
            case R.id.txt_next:
                if (validation()) {
                    clickable = 2;
                    data_save();
                }
                break;
            case R.id.edt_lead_source:
                pw_lead_source.show();
                break;
            case R.id.edt_industry:
                pw_industry.show();
                break;
            case R.id.edt_sales_person:
                pw_salesperson.show();
                break;
            case R.id.edt_lead_owner:
                pw_lead_owner.show();
                break;
            case R.id.txt1:
                if (LeadCRMList.page1) {
//                    clickable = 1;
                }
                break;
            case R.id.txt2:
                if (LeadCRMList.page2) {
                    clickable = 2;
                    data_save();
                }
                break;
            case R.id.txt3:
                if (LeadCRMList.page3) {
                    clickable = 3;
                    data_save();
                }
                break;
            case R.id.txt4:
                if (LeadCRMList.page4) {
                    clickable = 4;
                    data_save();
                }
                break;
            case R.id.txt5:
                if (LeadCRMList.page5) {
                    clickable = 5;
                    data_save();
                }
                break;
            case R.id.txt6:
                if (LeadCRMList.page6) {
                    clickable = 6;
                    data_save();
                }
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        //super.onActivityResult(requestCode, resultCode, data); comment this unless you want to pass your result to the activity.
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_FILE) {
                get_path(data);
            } else if (requestCode == REQUEST_CAMERA) {
                onCaptureImageResult(data);
            }

        }


    }

    public void get_path(Intent data) {
        realPath = null;

        Uri uri = data.getData();
        if (realPath == null) {
            realPath = getRealPathFromURI_BelowAPI11(getActivity(), uri);
            if (realPath == null) {
                realPath = getRealPathFromURI_API11to18(getActivity(), uri);
                if (realPath == null) {
                    realPath = getRealPathFromURI_API19(getActivity(), uri);
                    if (realPath == null) {
                        Toast.makeText(getActivity(), "Image Path not getting", Toast.LENGTH_LONG).show();
                    } else {
                        onSelectFromGalleryResult(data, realPath);
                    }
                } else {
                    onSelectFromGalleryResult(data, realPath);
                }
            } else {
                onSelectFromGalleryResult(data, realPath);
            }
        } else {
            onSelectFromGalleryResult(data, realPath);
        }
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);

        File destination = new File(Environment.getExternalStorageDirectory(), System.currentTimeMillis() + ".jpg");
        realPath = destination.toString();
        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        profile_image.setImageBitmap(thumbnail);
    }

    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data, String path) {

        Bitmap bm = null;
        if (data != null) {
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), data.getData());
                // Log.d(TAG, String.valueOf(bitmap));

                profile_image.setImageBitmap(bitmap);
                /*txt_filename.setText(path.substring(path.lastIndexOf("/") + 1));*/
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @SuppressLint("NewApi")
    public String getRealPathFromURI_API19(Context context, Uri uri) {
        String filePath = "";
        String wholeID = DocumentsContract.getDocumentId(uri);

        // Split at colon, use second item in the array
        String id = wholeID.split(":")[1];

        String[] column = {MediaStore.Images.Media.DATA};

        // where id is equal to
        String sel = MediaStore.Images.Media._ID + "=?";

        Cursor cursor = context.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, column, sel, new String[]{id}, null);

        int columnIndex = cursor.getColumnIndex(column[0]);

        if (cursor.moveToFirst()) {
            filePath = cursor.getString(columnIndex);
        }
        cursor.close();
//        source_file = new File(filePath);
        return filePath;
    }

    @SuppressLint("NewApi")
    public String getRealPathFromURI_API11to18(Context context, Uri contentUri) {
        String[] proj = {MediaStore.Images.Media.DATA};
        String result = null;

        CursorLoader cursorLoader = new CursorLoader(context, contentUri, proj, null, null, null);
        Cursor cursor = cursorLoader.loadInBackground();

        if (cursor != null) {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            result = cursor.getString(column_index);
            cursor.close();
//            source_file = new File(result);
        }
        return result;
    }

    public String getRealPathFromURI_BelowAPI11(Context context, Uri contentUri) {
        String[] proj = {MediaStore.Images.Media.DATA};
        String result = null;
        Cursor cursor = context.getContentResolver().query(contentUri, proj, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        result = cursor.getString(column_index);
        cursor.close();
//        source_file = new File(result);
        return result;
    }

    private void galleryIntent() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);//
        startActivityForResult(Intent.createChooser(intent, "Select File"), SELECT_FILE);
    }

    private void cameraIntent() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, REQUEST_CAMERA);
    }

    private void selectImage() {
        final CharSequence[] items = {"Take Photo", "Choose from Library", "Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Upload Photo!");
        builder.setCancelable(false);
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                boolean result = Utility.checkPermission(getActivity());

                if (items[item].equals("Take Photo")) {
                    if (result) cameraIntent();

                } else if (items[item].equals("Choose from Library")) {
                    if (result) galleryIntent();

                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    public boolean validation() {
        if (TextUtils.isEmpty(edt_company.getText().toString())) {
            edt_company.requestFocus();
            edt_company.setError("Please fill company name");
            return false;
        }
        if (TextUtils.isEmpty(edt_f_name.getText().toString())) {
            edt_f_name.requestFocus();
            edt_f_name.setError("Please fill first name");
            return false;
        }
        if (TextUtils.isEmpty(edt_l_name.getText().toString())) {
            edt_l_name.requestFocus();
            edt_l_name.setError("Please fill last name");
            return false;
        }

        if (!TextUtils.isEmpty(edt_email.getText().toString())) {
            if (!Patterns.EMAIL_ADDRESS.matcher(edt_email.getText().toString()).matches()) {
                edt_email.requestFocus();
                edt_email.setError("Please fill correct email");
                return false;
            }
        }

        if (!TextUtils.isEmpty(edt_phone.getText().toString())) {
            if (edt_phone.getText().toString().length() < 10) {
                edt_phone.requestFocus();
                edt_phone.setError("Please fill minmum 10 digit number");
                return false;
            }
        }
        if (!TextUtils.isEmpty(edt_mobile.getText().toString())) {
            if (edt_mobile.getText().toString().length() < 10) {
                edt_mobile.requestFocus();
                edt_mobile.setError("Please fill minmum 10 digit number");
                return false;
            }
        }
        if (!TextUtils.isEmpty(edt_contact.getText().toString())) {
            if (edt_contact.getText().toString().length() < 10) {
                edt_contact.requestFocus();
                edt_contact.setError("Please fill minmum 10 digit number");
                return false;
            }
        }
        return true;
    }

    public void data_save() {
        Helper.storeLocally(getActivity(), "number", edt_serial_no.getText().toString());
        Helper.storeLocally(getActivity(), "first_name", edt_f_name.getText().toString());
        Helper.storeLocally(getActivity(), "last_name", edt_l_name.getText().toString());
        Helper.storeLocally(getActivity(), "company_name", edt_company.getText().toString());
        Helper.storeLocally(getActivity(), "title", edt_title.getText().toString());
        Helper.storeLocally(getActivity(), "city_name", edt_city.getText().toString());
        Helper.storeLocally(getActivity(), "address", edt_address.getText().toString());
        Helper.storeLocally(getActivity(), "loction_name", edt_location.getText().toString());
        Helper.storeLocally(getActivity(), "state", edt_state.getText().toString());
        Helper.storeLocally(getActivity(), "pincode", edt_pincode.getText().toString());
        Helper.storeLocally(getActivity(), "phone", edt_phone.getText().toString());
        Helper.storeLocally(getActivity(), "mobile", edt_mobile.getText().toString());
        Helper.storeLocally(getActivity(), "additonal_contact", edt_contact.getText().toString());
        Helper.storeLocally(getActivity(), "email", edt_email.getText().toString());
        Helper.storeLocally(getActivity(), "lead_source", edt_lead_source.getText().toString());
        Helper.storeLocally(getActivity(), "lead_source_other", edt_other_lead_source.getText().toString());
        Helper.storeLocally(getActivity(), "no_employee", edt_no_employee.getText().toString());
        Helper.storeLocally(getActivity(), "annual_revenue", edt_annual_revenue.getText().toString());
        Helper.storeLocally(getActivity(), "industry", edt_industry.getText().toString());
        Helper.storeLocally(getActivity(), "industry_other", edt_other_industry.getText().toString());
        Helper.storeLocally(getActivity(), "lead_owner", edt_lead_owner.getText().toString());
        Helper.storeLocally(getActivity(), "sales_person", edt_sales_person.getText().toString());
        if (clickable == 1) {

        } else if (clickable == 2) {
//            MainActivity.add_lead=true;
            Fragment fragment = new LeadCRMForm2();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page2");
            ft.commit();
        } else if (clickable == 3) {
            Fragment fragment = new LeadCRMForm3();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page3");
            ft.commit();
        } else if (clickable == 4) {
            Fragment fragment = new LeadCRMForm4();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page4");
            ft.commit();
        } else if (clickable == 5) {
            Fragment fragment = new LeadCRMForm5();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page5");
            ft.commit();
        } else if (clickable == 6) {
            Fragment fragment = new LeadCRMForm6();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page6");
            ft.commit();
        }

    }

    public void executeMethode() {
        edt_serial_no.setText(Helper.getLocalValue(getActivity(), "number"));
        edt_f_name.setText(Helper.getLocalValue(getActivity(), "first_name"));
        edt_l_name.setText(Helper.getLocalValue(getActivity(), "last_name"));
        edt_company.setText(Helper.getLocalValue(getActivity(), "company_name"));
        edt_title.setText(Helper.getLocalValue(getActivity(), "title"));
        edt_address.setText(Helper.getLocalValue(getActivity(), "address"));
        edt_location.setText(Helper.getLocalValue(getActivity(), "loction_name"));
        edt_city.setText(Helper.getLocalValue(getActivity(), "city_name"));
        edt_state.setText(Helper.getLocalValue(getActivity(), "state"));
        edt_pincode.setText(Helper.getLocalValue(getActivity(), "pincode"));
        edt_phone.setText(Helper.getLocalValue(getActivity(), "phone"));
        edt_mobile.setText(Helper.getLocalValue(getActivity(), "mobile"));
        edt_email.setText(Helper.getLocalValue(getActivity(), "email"));
        edt_contact.setText(Helper.getLocalValue(getActivity(), "additonal_contact"));
        edt_annual_revenue.setText(Helper.getLocalValue(getActivity(), "annual_revenue"));
        edt_no_employee.setText(Helper.getLocalValue(getActivity(), "no_employee"));
        edt_lead_source.setText(Helper.getLocalValue(getActivity(), "lead_source"));
        if(Helper.getLocalValue(getActivity(), "lead_source").equalsIgnoreCase("Others"))
        {
            edt_other_lead_source.setVisibility(View.VISIBLE);
        }
        edt_other_lead_source.setText(Helper.getLocalValue(getActivity(), "lead_source_other"));
        edt_sales_person.setText(Helper.getLocalValue(getActivity(), "sales_person"));
        edt_industry.setText(Helper.getLocalValue(getActivity(), "industry"));
        if(Helper.getLocalValue(getActivity(), "industry").equalsIgnoreCase("Others"))
        {
            edt_other_industry.setVisibility(View.VISIBLE);
        }
        edt_other_industry.setText(Helper.getLocalValue(getActivity(), "industry_other"));
        edt_lead_owner.setText(Helper.getLocalValue(getActivity(), "lead_owner"));
    }
}
