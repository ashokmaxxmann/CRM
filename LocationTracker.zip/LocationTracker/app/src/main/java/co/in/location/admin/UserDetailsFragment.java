package co.in.location.admin;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import co.in.location.Helper;
import co.in.location.R;
import co.in.location.slider.SlidingTabLayout;

public class UserDetailsFragment extends Fragment {

    private ViewPager pager;
    private UserViewPagerAdapter adapter;
    private SlidingTabLayout tabs;
    public CharSequence Titles[];// =new CharSequence[3];
    int Numboftabs;
    public static String user_id, name, email, personal_number, address, Designation, Department, Designation_id, Department_id, image_path;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.view_pager, container, false);
        if (Helper.getLocalValue(getActivity(), "user_designation").equalsIgnoreCase("admin")) {
            Numboftabs = 3;
            Titles = new CharSequence[3];
            Titles[0] = "Personal\n Information";
            Titles[1] = "Log\n Information";
            Titles[2] = "Conversation\n Data";
        } else if (!Helper.getLocalValue(getActivity(), "user_designation").equalsIgnoreCase("admin")) {
            Numboftabs = 2;
            Titles = new CharSequence[2];
            Titles[0] = "HOLIDAYS";
            Titles[1] = "ALL FESTIVAL";
        }
        user_id = getArguments().getString("user_id");
        name = getArguments().getString("name");
        email = getArguments().getString("email");
        personal_number = getArguments().getString("personal_number");
        address = getArguments().getString("address");
        Designation = getArguments().getString("Designation");
        Department = getArguments().getString("Department");
        Designation_id = getArguments().getString("Designation_id");
        Department_id = getArguments().getString("Department_id");
        image_path = getArguments().getString("image_path");


        adapter = new UserViewPagerAdapter(getActivity().getSupportFragmentManager(), Titles,
                Numboftabs);

        // Assigning ViewPager View and setting the adapter
        pager = (ViewPager) view.findViewById(R.id.pager);
        pager.setAdapter(adapter);

        // Assiging the Sliding Tab Layout View
        tabs = (SlidingTabLayout) view.findViewById(R.id.tabLayout);
        tabs.setDistributeEvenly(true);
        tabs.setViewPager(pager);

        return view;
    }


    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("User Details");
    }
}
