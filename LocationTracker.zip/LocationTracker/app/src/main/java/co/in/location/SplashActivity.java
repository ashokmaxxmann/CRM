package co.in.location;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import co.in.location.service.MyIntentService;

public class SplashActivity extends AppCompatActivity {
    boolean doubleBackToExitPressedOnce = false;
    Handler handler;
    Runnable rn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);
       /* boolean result = Utility.checkPermission(SplashActivity.this);*/
        if (MyApp.getInstance().isConnectingToInternet()) {
            handler = new Handler();
            rn = new Runnable() {
                @Override
                public void run() {
                    boolean isLoggedIn = Helper.getLocalValue(SplashActivity.this, "user_id") != null;
//                Toast.makeText(SplashScreen.this,""+isLoggedIn,Toast.LENGTH_LONG).show();
                    if (isLoggedIn) {
                        if(!Helper.getLocalValue(getApplicationContext(), "user_designation") .equalsIgnoreCase("admin"))
                        {
                            start_Service();
                        }

                        startActivity(new Intent(SplashActivity.this, MainActivity.class));
                    } else {
                        startActivity(new Intent(SplashActivity.this, Login.class));
                    }
                    overridePendingTransition(R.anim.slide_in_top, R.anim.stay);
                    SplashActivity.this.finish();
                }
            };
            handler.postDelayed(rn, 2000);
        } else {

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Please connect to working internet connection.").setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
//                    startActivityForResult(new Intent(android.provider.Settings.ACTION_SETTINGS), 0);
                    SplashActivity.this.finish();
                }
            });
            AlertDialog alert = builder.create();
            alert.show();
        }
    }
    public void start_Service() {
        if (MyApp.getInstance().isConnectingToInternet()) {
            startService(new Intent(SplashActivity.this, MyIntentService.class));
        }
    }
    @Override
    public void onBackPressed() {
        FragmentManager manager = getSupportFragmentManager();
        if (manager.getBackStackEntryCount() > 0) {
            // If there are back-stack entries, leave the FragmentActivity
            // implementation take care of them.
            manager.popBackStack();

        } else {
            // Otherwise, ask user if he wants to leave :)
            if (doubleBackToExitPressedOnce) {
                super.onBackPressed();
                this.finishAffinity();
                return;
            }

            this.doubleBackToExitPressedOnce = true;
            Toast.makeText(this, "Please click back again to exit", Toast.LENGTH_SHORT).show();

            new Handler().postDelayed(new Runnable() {

                @Override
                public void run() {
                    doubleBackToExitPressedOnce = false;
                }
            }, 2000);
        }
    }
}
