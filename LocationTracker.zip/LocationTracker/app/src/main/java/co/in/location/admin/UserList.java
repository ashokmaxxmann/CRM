package co.in.location.admin;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AppCompatDialog;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListPopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.futuremind.recyclerviewfastscroll.FastScroller;
import com.futuremind.recyclerviewfastscroll.SectionTitleProvider;
import com.google.android.gms.maps.model.LatLng;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.text.DecimalFormat;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import co.in.location.GifImageView;
import co.in.location.MainActivity;
import co.in.location.R;
import co.in.location.Remote.ApiUtils;
import co.in.location.customview.CustomScrollerViewProvider;
import co.in.location.data.UserListData;
import co.in.location.response.UserListResponse;
import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserList extends Fragment implements View.OnClickListener {
    View view;
    RecyclerView recyclerView;
    String user_id, name, email, personal_number, address, designation, departments, designation_id, departments_id, image_path;
    public static boolean execute = false;
    ImageView img_add_account;
    public static boolean add_account = false;
    private String[] list_approve;
    UserRoleAdapter ur_adapter;
    private ListPopupWindow lpw2;
    TextView txt_message, prog_message;
    String option;
    public static UserListResponse responce;
    MyCustomAdapter adapter;
    public static boolean update_user_profile = false;
    AppCompatDialog progressDialog;
    private FastScroller fastScroller;
    public UserListResponse responce_filter = new UserListResponse();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.user_list, container, false);
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        recyclerView = (RecyclerView) view.findViewById(R.id.user_list);
        fastScroller = (FastScroller) view.findViewById(R.id.fastscroll);
        fastScroller.setRecyclerView(recyclerView);
        txt_message = (TextView) view.findViewById(R.id.txt_message);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setNestedScrollingEnabled(true);
        img_add_account = (ImageView) view.findViewById(R.id.img_add_account);
        img_add_account.setOnClickListener(this);
        progressDialog = new AppCompatDialog(getActivity());
        progressDialog.setCancelable(false);
        progressDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progressDialog.setContentView(R.layout.progress_loading);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        prog_message = progressDialog.findViewById(R.id.tv_progress_message);
        prog_message.setText("Please wait..");
        GifImageView gifImageView = (GifImageView) progressDialog.findViewById(R.id.GifImageView);
        gifImageView.setGifImageResource(R.drawable.loadinggif);

        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("All Sales Representative");

//        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);

//        ((AppCompatActivity) getActivity()).getSupportActionBar().setHomeAsUpIndicator(R.mipmap.marker);
//        ((AppCompatActivity) getActivity()).getSupportActionBar().setIcon(R.mipmap.marker);

        getUserList();
        lpw2 = new ListPopupWindow(getActivity());
//        lpw2.setAdapter(new ArrayAdapter<String>(SocialAccount.this, android.R.layout.simple_list_item_1, list_approve));
        list_approve = new String[]{"Edit", "Location"};
        ur_adapter = (new UserRoleAdapter(getActivity(), list_approve));
        lpw2.setAdapter(ur_adapter);

        return view;
    }

    public double CalculationByDistance(LatLng StartP, LatLng EndP) {
        int Radius = 6371;// radius of earth in Km
        double lat1 = StartP.latitude;
        double lat2 = EndP.latitude;
        double lon1 = StartP.longitude;
        double lon2 = EndP.longitude;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1))
                * Math.cos(Math.toRadians(lat2)) * Math.sin(dLon / 2)
                * Math.sin(dLon / 2);
        double c = 2 * Math.asin(Math.sqrt(a));
        double valueResult = Radius * c;
        double km = valueResult / 1;
        DecimalFormat newFormat = new DecimalFormat("####");
        int kmInDec = Integer.valueOf(newFormat.format(km));
        double meter = valueResult % 1000;
        int meterInDec = Integer.valueOf(newFormat.format(meter));
        Log.i("Radius Value", "" + valueResult + "   KM  " + kmInDec
                + " Meter   " + meterInDec);

        return Radius * c;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_add_account:
                Fragment fragment = new AddEmployee();
                android.support.v4.app.FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.frame, fragment);
                ft.commit();
                MainActivity.selected_groupPosition = 0;
                MainActivity.expListView.setAdapter(MainActivity.expandableListAdapter);
                break;
        }
    }

    private void getUserList() {
        if (progressDialog != null) progressDialog.show();
        ApiUtils.getAlterationService().getUser("user-list", "").enqueue(new Callback<UserListResponse>() {
            @Override
            public void onResponse(Call<UserListResponse> call, Response<UserListResponse> response) {
                try {
                    if (response.code() == 200) {
                        if (response.body().statusCode == 1) {
                            if (response.body() != null) {
                                responce = response.body();
                                for (int i = 0; i < responce.userListData.size(); i++) {
                                    if (!responce.userListData.get(i).designation.equalsIgnoreCase("admin")) {
                                        responce_filter.userListData.add(i, responce.userListData.get(i));
                                    }
                                }
                                adapter = null;
                                adapter = new MyCustomAdapter(responce_filter.userListData);// new MyCustomAdapter(SocialAccount.this, response.body().socialdata);
                                recyclerView.setAdapter(adapter);

                                fastScroller.setRecyclerView(recyclerView);
                                if (responce_filter.userListData.size() > 0) {
                                    txt_message.setVisibility(View.GONE);
                                } else {
                                    txt_message.setVisibility(View.VISIBLE);
                                }
                            } else {

                                Toast.makeText(getActivity(), response.body().message, Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(getActivity(), response.body().message, Toast.LENGTH_SHORT).show();
                        }
                    }
                    progressDialog.dismiss();
                } catch (Exception e) {
                    progressDialog.dismiss();
                    e.printStackTrace();
                    Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<UserListResponse> call, Throwable t) {
                progressDialog.dismiss();
                t.printStackTrace();
                Toast.makeText(getActivity(), call.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public class MyCustomAdapter extends RecyclerView.Adapter<MyCustomAdapter.ItemViewHolder> implements SectionTitleProvider {

        List<UserListData> list;

        public MyCustomAdapter(List<UserListData> list) {
            this.list = list;
        }


        @Override
        public MyCustomAdapter.ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

            return new MyCustomAdapter.ItemViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.user_list_items, parent, false));
        }

        public void onBindViewHolder(final MyCustomAdapter.ItemViewHolder holder, final int position) {

            try {

                final UserListData userListData = list.get(position);
                holder.txt_name.setText(userListData.name);
                holder.txt_email.setText(userListData.email);
                holder.txt_phone.setText(userListData.personal_number);
                holder.txt_designation.setText(userListData.designation);
                if (!userListData.image_path.isEmpty()) {
                    Picasso.with(getActivity()).load(ApiUtils.BASE_URL + userListData.image_path).networkPolicy(NetworkPolicy.NO_CACHE).into(holder.img_profile_image);
                } else {
                    Picasso.with(getActivity()).load(R.mipmap.profilepic).into(holder.img_profile_image);
                }


                holder.img_option.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        user_id = userListData.id;
                        name = userListData.name;
                        email = userListData.email;
                        personal_number = userListData.personal_number;
                        address = userListData.address;
                        designation = userListData.designation;
                        departments = userListData.departments;
                        designation_id = userListData.designation_id;
                        departments_id = userListData.departments_id;
                        image_path = userListData.image_path;
                        lpw2.setAnchorView(holder.txt);
                        lpw2.setModal(true);
                        lpw2.show();
                    }
                });
                holder.card_view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent in = new Intent(getActivity(), UserDetailsActivity.class);
                        in.putExtra("user_id", userListData.id);
                        in.putExtra("name", userListData.name);
                        in.putExtra("email", userListData.email);
                        in.putExtra("personal_number", userListData.personal_number);
                        in.putExtra("address", userListData.address);
                        in.putExtra("designation", userListData.designation);
                        in.putExtra("departments", userListData.departments);
                        in.putExtra("designation_id", userListData.designation_id);
                        in.putExtra("departments_id", userListData.departments_id);
                        in.putExtra("image_path", userListData.image_path);
                        startActivity(in);
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public int getItemCount() {
            return list != null ? list.size() : 0;
        }

        class ItemViewHolder extends RecyclerView.ViewHolder {
            TextView txt_name, txt_email, txt_phone, txt_designation, txt;
            CircleImageView img_profile_image;
            ImageView img_option;
            CardView card_view;

            public ItemViewHolder(View itemView) {
                super(itemView);
                txt_name = (TextView) itemView.findViewById(R.id.txt_name);
                txt_email = (TextView) itemView.findViewById(R.id.txt_email);
                txt_phone = (TextView) itemView.findViewById(R.id.txt_phone);
                txt_designation = (TextView) itemView.findViewById(R.id.txt_designation);
                img_profile_image = (CircleImageView) itemView.findViewById(R.id.img_profile_image);
                img_option = (ImageView) itemView.findViewById(R.id.img_option);
                txt = (TextView) itemView.findViewById(R.id.txt);
                card_view=(CardView)itemView.findViewById(R.id.card_view);
            }
        }

        @Override
        public String getSectionTitle(int position) {
            return list.get(position).name.substring(0, 1);
        }
    }

    class UserRoleAdapter extends BaseAdapter {

        LayoutInflater inflater;
        String[] list;

        public UserRoleAdapter(FragmentActivity fragmentActivity, String[] list) {
            inflater = LayoutInflater.from(fragmentActivity);
            this.list = list;
        }

        @Override
        public int getCount() {
            return list.length;
        }

        @Override
        public Object getItem(int paramInt) {
            return paramInt;
        }

        class ViewHolder {
            TextView txt_option;
        }

        @Override
        public long getItemId(int paramInt) {
            return paramInt;
        }

        @Override
        public View getView(final int paramInt, View itemView, ViewGroup paramViewGroup) {

            UserRoleAdapter.ViewHolder holder;
            if (itemView == null) {
                itemView = inflater.inflate(R.layout.option_list, paramViewGroup, false);
                holder = new ViewHolder();

                holder.txt_option = (TextView) itemView.findViewById(R.id.txt_option);
                if (list[paramInt].equalsIgnoreCase("Edit")) {
                    /*holder.txt_option.setCompoundDrawablesWithIntrinsicBounds(R.drawable.edit_black, 0, 0, 0);*/
                } else {
                    /* holder.txt_option.setCompoundDrawablesWithIntrinsicBounds(R.drawable.marker_option, 0, 0, 0);*/
                }

                itemView.setTag(holder);
            } else {
                holder = (UserRoleAdapter.ViewHolder) itemView.getTag();
            }
            holder.txt_option.setText(capitalize(list[paramInt]));
            holder.txt_option.setTag(paramInt);
            holder.txt_option.setOnClickListener(new View.OnClickListener() {

                @SuppressWarnings("deprecation")
                @Override
                public void onClick(View vv) {
                    // TODO Auto-generated method stub
                    int pos1 = (Integer) vv.getTag();
//                    RoleData roleData = list.get(pos1);

//                    User_type = roleData.name;
//                    edt_user_type.setText(User_type);
                    option = list[paramInt];
                    if (option.equalsIgnoreCase("Edit")) {
                        Intent in = new Intent(getActivity(), Edit_Account.class);
                        in.putExtra("user_id", user_id);
                        in.putExtra("name", name);
                        in.putExtra("email", email);
                        in.putExtra("personal_number", personal_number);
                        in.putExtra("address", address);
                        in.putExtra("designation", designation);
                        in.putExtra("departments", departments);
                        in.putExtra("designation_id", designation_id);
                        in.putExtra("departments_id", departments_id);
                        in.putExtra("image_path", image_path);
                        startActivity(in);
                    } else if (option.equalsIgnoreCase("Location")) {
                        Intent in = new Intent(getActivity(), LocationHistory.class);
                        in.putExtra("user_id", user_id);
                        startActivity(in);
                    }
                    lpw2.dismiss();
                }
            });
            return itemView;
        }
    }

    private String capitalize(String capString) {
        StringBuffer capBuffer = new StringBuffer();
        Matcher capMatcher = Pattern.compile("([a-z])([a-z]*)", Pattern.CASE_INSENSITIVE).matcher(capString);
        while (capMatcher.find()) {
            capMatcher.appendReplacement(capBuffer, capMatcher.group(1).toUpperCase() + capMatcher.group(2).toLowerCase());
        }
        return capMatcher.appendTail(capBuffer).toString();
    }

    @Override
    public void onResume() {
        super.onResume();
        getFastScroller().setViewProvider(new CustomScrollerViewProvider());
        if (update_user_profile) {
            update_user_profile = false;
            responce_filter.userListData.clear();
            for (int i = 0; i < responce.userListData.size(); i++) {
                if (!responce.userListData.get(i).designation.equalsIgnoreCase("admin")) {
                    responce_filter.userListData.add(i, responce.userListData.get(i));
                }
            }
            adapter = null;
            adapter = new MyCustomAdapter(responce_filter.userListData);// new MyCustomAdapter(SocialAccount.this, response.body().socialdata);
            recyclerView.setAdapter(adapter);
            fastScroller.setRecyclerView(recyclerView);
        }
    }

    public FastScroller getFastScroller() {
        return fastScroller;
    }
}