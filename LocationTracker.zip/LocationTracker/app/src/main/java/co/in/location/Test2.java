package co.in.location;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import co.in.location.Remote.ApiUtils;
import co.in.location.admin.Edit_Account;
import de.hdodenhof.circleimageview.CircleImageView;

public class Test2 extends AppCompatActivity implements View.OnClickListener {
    TextView txt_name, txt_phone, txt_email, txt_add, txt_degignation, txt_department;
    CircleImageView profile_image;
    String Designation, Department,Designation_id, Department_id, user_id, name, email, personal_number, address, image_path;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        getLayoutInflater().inflate(R.layout.activity_view_user_details, frameLayout);
        setContentView(R.layout.activity_view_user_details);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("User Details");

        txt_name = (TextView) findViewById(R.id.txt_name);
        txt_email = (TextView) findViewById(R.id.txt_email);
        txt_phone = (TextView) findViewById(R.id.txt_phone);
        txt_add = (TextView) findViewById(R.id.txt_add);
        txt_degignation = (TextView) findViewById(R.id.txt_degignation);
        profile_image = (CircleImageView) findViewById(R.id.profile_image);
        txt_department = (TextView) findViewById(R.id.txt_department);
        getUserDetails();
    }

    private void getUserDetails() {
        Intent in = getIntent();
        user_id = in.getStringExtra("user_id");
        name = in.getStringExtra("name");
        email = in.getStringExtra("email");
        personal_number = in.getStringExtra("personal_number");
        address = in.getStringExtra("address");
        Designation = in.getStringExtra("designation");
        Department = in.getStringExtra("departments");
        Designation_id = in.getStringExtra("designation_id");
        Department_id = in.getStringExtra("departments_id");
        image_path = in.getStringExtra("image_path");
        if (!image_path.isEmpty()) {
            Picasso.with(Test2.this).load(ApiUtils.BASE_URL + image_path).networkPolicy(NetworkPolicy.NO_CACHE).into(profile_image);
        } else {
            Picasso.with(Test2.this).load(R.mipmap.profilepic).into(profile_image);
        }

       /* if (!userListData.image_path.isEmpty()) {
            Picasso.with(getActivity()).load(ApiUtils.BASE_URL + userListData.image_path).networkPolicy(NetworkPolicy.NO_CACHE).into(holder.img_profile_image);
        } else {
            Picasso.with(getActivity()).load(R.mipmap.profilepic).into(holder.img_profile_image);

        }*/

        txt_name.setText(name);
        txt_phone.setText(personal_number);
        txt_email.setText(email);
        txt_add.setText(address);
        txt_degignation.setText(Designation);
        txt_department.setText(Department);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
           /* case R.id.txt_manage_account:
                if ((selected_userRole.equalsIgnoreCase("kam lead")) || (selected_userRole.equalsIgnoreCase("Kam Team"))) {
                    Intent in = new Intent(UserDetailsActivity.this, AssignClient.class);
                    in.putExtra("selected_user", selected_userId);
                    startActivity(in);
                } else if (selected_userRole.equalsIgnoreCase("Client")) {
                    Intent in = new Intent(UserDetailsActivity.this, SocialAccount.class);
                    in.putExtra("selected_user", selected_userId);
                    in.putExtra("profile_pic", profile_pic);
                    startActivity(in);
                }
                break;*/
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.edit_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // todo: goto back activity from here
                Test2.this.finish();
                return true;
            case R.id.edit_menu:
                Intent in = new Intent(Test2.this, Edit_Account.class);
                in.putExtra("user_id", user_id);
                in.putExtra("name", name);
                in.putExtra("email", email);
                in.putExtra("personal_number", personal_number);
                in.putExtra("address", address);
                in.putExtra("designation", Designation);
                in.putExtra("departments", Department);
                in.putExtra("designation_id", Designation_id);
                in.putExtra("departments_id", Department_id);
                in.putExtra("image_path", image_path);
                startActivity(in);
                return true;
            default:
                break;
        }
        return true;
    }
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        menu.getItem(0).setVisible(true);
        return true;
    }
}
