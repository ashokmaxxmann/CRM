package co.in.location.deals;

import android.os.Bundle;
import android.support.percent.PercentRelativeLayout;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import co.in.location.R;
import co.in.location.response.CRMListResponse;

public class Account_Tab extends Fragment {
    TextView txt_account_owner, txt_rating, txt_account_site, txt_parent_account, txt_website, txt_account_number, txt_ticker_symbol, txt_account_type, txt_ownership, txt_industry, txt_employees, txt_annual_revenue, txt_sic_code;
    public static CRMListResponse respose;
    PercentRelativeLayout prl27, prl28, prl29, prl30, prl31, prl32, prl33, prl34, prl35, prl36, v7, prl37, prl38, prl39;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.deals_account, container, false);
        txt_account_owner = (TextView) view.findViewById(R.id.txt_account_owner);
        txt_rating = (TextView) view.findViewById(R.id.txt_rating);
        txt_account_site = (TextView) view.findViewById(R.id.txt_account_site);
        txt_parent_account = (TextView) view.findViewById(R.id.txt_parent_account);
        txt_website = (TextView) view.findViewById(R.id.txt_website);
        txt_account_number = (TextView) view.findViewById(R.id.txt_account_number);
        txt_ticker_symbol = (TextView) view.findViewById(R.id.txt_ticker_symbol);
        txt_account_type = (TextView) view.findViewById(R.id.txt_account_type);
        txt_ownership = (TextView) view.findViewById(R.id.txt_ownership);
        txt_industry = (TextView) view.findViewById(R.id.txt_industry);
        txt_employees = (TextView) view.findViewById(R.id.txt_employees);
        txt_annual_revenue = (TextView) view.findViewById(R.id.txt_annual_revenue);
        txt_sic_code = (TextView) view.findViewById(R.id.txt_sic_code);


        prl27 = (PercentRelativeLayout) view.findViewById(R.id.prl27);
        prl28 = (PercentRelativeLayout) view.findViewById(R.id.prl28);
        prl29 = (PercentRelativeLayout) view.findViewById(R.id.prl29);
        prl30 = (PercentRelativeLayout) view.findViewById(R.id.prl30);
        prl31 = (PercentRelativeLayout) view.findViewById(R.id.prl31);
        prl32 = (PercentRelativeLayout) view.findViewById(R.id.prl32);
        prl33 = (PercentRelativeLayout) view.findViewById(R.id.prl33);
        prl34 = (PercentRelativeLayout) view.findViewById(R.id.prl34);
        prl35 = (PercentRelativeLayout) view.findViewById(R.id.prl35);
        prl36 = (PercentRelativeLayout) view.findViewById(R.id.prl36);
        prl37 = (PercentRelativeLayout) view.findViewById(R.id.prl37);
        prl38 = (PercentRelativeLayout) view.findViewById(R.id.prl38);
        prl39 = (PercentRelativeLayout) view.findViewById(R.id.prl39);


//        id = getIntent().getStringExtra("id");
//        currentpage = getIntent().getIntExtra("currentpage", 0);
//        txt_mobile.setOnClickListener(this);
//        getDetails();
//        dealCRMDetails = this;
        executeMethode();
        return view;
    }
    public void executeMethode() {

        txt_account_owner.setText(DealsDetails.respose.crmListData.get(0).Response_Rate);
        txt_rating.setText(DealsDetails.respose.crmListData.get(0).Engagement_Rate);
        txt_account_site.setText(DealsDetails.respose.crmListData.get(0).Linkedin_Followers);
        txt_parent_account.setText(DealsDetails.respose.crmListData.get(0).Website);
        txt_website.setText(DealsDetails.respose.crmListData.get(0).Website_Technology);
        txt_account_number.setText(DealsDetails.respose.crmListData.get(0).Website_information);
        txt_ticker_symbol.setText(DealsDetails.respose.crmListData.get(0).Website_Type);
        txt_account_type.setText(DealsDetails.respose.crmListData.get(0).Overlook_and_Feels);
        txt_ownership.setText(DealsDetails.respose.crmListData.get(0).Website_Language);
        txt_industry.setText(DealsDetails.respose.crmListData.get(0).Content_Quality);
        txt_employees.setText(DealsDetails.respose.crmListData.get(0).Graphic_Quality);
        txt_annual_revenue.setText(DealsDetails.respose.crmListData.get(0).Global_Rank);
        txt_sic_code.setText(DealsDetails.respose.crmListData.get(0).total_score);
    }

}
