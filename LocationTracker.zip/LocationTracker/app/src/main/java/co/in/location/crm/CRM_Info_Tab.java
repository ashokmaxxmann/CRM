package co.in.location.crm;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.app.AppCompatDialog;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.SectionIndexer;
import android.widget.TextView;
import android.widget.Toast;

import co.in.location.GifImageView;
import co.in.location.Helper;
import co.in.location.R;
import co.in.location.Remote.ApiUtils;
import co.in.location.response.CRMListResponse;
import co.in.location.response.DeleteResponce;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CRM_Info_Tab extends Fragment implements View.OnClickListener {
    TextView txt_number, txt_company, txt_first_name, txt_last_name, txt_title, txt_address, txt_city, txt_location, txt_state, txt_pincode, txt_phone, txt_mobile, txt_email, txt_ad_contact, txt_annual_revenue, txt_no_employee, txt_lead_source, txt_sales_person, txt_industry, txt_lead_owner;
    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.crm_info, container, false);
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        txt_number = (TextView) view.findViewById(R.id.txt_number);
        txt_company = (TextView) view.findViewById(R.id.txt_company);
        txt_first_name = (TextView) view.findViewById(R.id.txt_first_name);
        txt_last_name = (TextView) view.findViewById(R.id.txt_last_name);
        txt_title = (TextView) view.findViewById(R.id.txt_title);
        txt_address = (TextView) view.findViewById(R.id.txt_address);
        txt_city = (TextView) view.findViewById(R.id.txt_city);
        txt_location = (TextView) view.findViewById(R.id.txt_location);
        txt_state = (TextView) view.findViewById(R.id.txt_state);
        txt_pincode = (TextView) view.findViewById(R.id.txt_pincode);
        txt_phone = (TextView) view.findViewById(R.id.txt_phone);
        txt_mobile = (TextView) view.findViewById(R.id.txt_mobile);
        txt_email = (TextView) view.findViewById(R.id.txt_email);
        txt_ad_contact = (TextView) view.findViewById(R.id.txt_ad_contact);
        txt_annual_revenue = (TextView) view.findViewById(R.id.txt_annual_revenue);
        txt_no_employee = (TextView) view.findViewById(R.id.txt_no_employee);
        txt_lead_source = (TextView) view.findViewById(R.id.txt_lead_source);
        txt_sales_person = (TextView) view.findViewById(R.id.txt_sales_person);
        txt_industry = (TextView) view.findViewById(R.id.txt_industry);
        txt_lead_owner = (TextView) view.findViewById(R.id.txt_lead_owner);

//        id = LeadCRMDetailsFragment.id;
//        currentpage = LeadCRMDetailsFragment.currentpage;
        txt_mobile.setOnClickListener(this);
        executeMethode();
//        leadCRMDetails1111 = this;
        return view;
    }

    @Override
    public void onClick(View v) {
     switch (v.getId())
     {
         case R.id.txt_mobile:
             try {
                 Intent callIntent = new Intent(Intent.ACTION_CALL);
                 callIntent.setData(Uri.parse("tel:" + txt_mobile.getText().toString()));
                 startActivity(callIntent);
                 // If package resolves to an app, send intent.
             } catch (SecurityException e) {
                 Toast.makeText(getActivity(), "Can't resolve app for ACTION_DIAL Intent", Toast.LENGTH_LONG).show();
             }
     }
    }

    public void executeMethode() {
        txt_number.setText(LeadCRMDetails.respose.crmListData.get(0).number);
        txt_company.setText(LeadCRMDetails.respose.crmListData.get(0).company);
        txt_first_name.setText(LeadCRMDetails.respose.crmListData.get(0).f_name);
        txt_last_name.setText(LeadCRMDetails.respose.crmListData.get(0).l_name);
        txt_title.setText(LeadCRMDetails.respose.crmListData.get(0).title);
        txt_address.setText(LeadCRMDetails.respose.crmListData.get(0).address);
        txt_city.setText(LeadCRMDetails.respose.crmListData.get(0).city);
        txt_location.setText(LeadCRMDetails.respose.crmListData.get(0).location);
        txt_state.setText(LeadCRMDetails.respose.crmListData.get(0).state);
        txt_pincode.setText(LeadCRMDetails.respose.crmListData.get(0).pincode);
        txt_phone.setText(LeadCRMDetails.respose.crmListData.get(0).phone);
        txt_mobile.setText(LeadCRMDetails.respose.crmListData.get(0).mobile);
        txt_email.setText(LeadCRMDetails.respose.crmListData.get(0).email);
        txt_ad_contact.setText(LeadCRMDetails.respose.crmListData.get(0).additonal_contact);
        txt_annual_revenue.setText(LeadCRMDetails.respose.crmListData.get(0).annual_revenue);
        txt_no_employee.setText(LeadCRMDetails.respose.crmListData.get(0).no_employee);
        txt_lead_source.setText(LeadCRMDetails.respose.crmListData.get(0).lead_source);
        txt_sales_person.setText(LeadCRMDetails.respose.crmListData.get(0).sales_person);
        txt_industry.setText(LeadCRMDetails.respose.crmListData.get(0).industry);
        txt_lead_owner.setText(LeadCRMDetails.respose.crmListData.get(0).lead_owner);
    }
}
