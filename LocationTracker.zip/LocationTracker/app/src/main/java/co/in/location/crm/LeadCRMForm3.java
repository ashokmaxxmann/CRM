package co.in.location.crm;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListPopupWindow;
import android.widget.TextView;

import co.in.location.Helper;
import co.in.location.MainActivity;
import co.in.location.R;

public class LeadCRMForm3 extends Fragment implements View.OnClickListener {
    View view;
    EditText edt_website, edt_website_input, edt_website_technology, edt_website_type, edt_website_language, edt_global_rank, edt_overlookfeel, edt_content_quality, edt_graphics_quality, edt_total_score;
    TextView txt_next, txt1, txt2, txt3, txt4, txt5, txt6;

    EditText edt_other_website, edt_other_website_technology, edt_other_website_type, edt_other_website_language, edt_other_global_rank, edt_other_overlookfeel, edt_other_content_quality, edt_other_graphics_quality;

    private String[] list_website = new String[]{"0", "10", "Others"};
    private String[] list_website_technology = new String[]{"Magento", "Volusion", "MailChimp", "Shopify", "WooCommerce", "Cart Functionality", "Ruby on Rails", "WordPress", "Google App for Business", "Amazon", "ASP.Net", "PHP", "Google Analytics", "osCommerce", "Others"};
    private String[] list_website_type = new String[]{"Personal Websites", "Photo Sharing Websites", "Writers / Authors Websites", "Community Building Websites", "Mobile Device Websites", "Blogs", "Informational Websites", "Online Business Brochure/Catalog", "Directory Websites", "E-commerce Websites", "Others"};
    private String[] list_website_language = new String[]{"JavaScript", "Java", "Python", "CSS", "PHP", "Ruby", "C++", "C", "Shell", "Objective C", "R", "VimL", "Go", "Perl", "Others"};
    private String[] list_overlook_feel = new String[]{"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Others"};
    private String[] list_content_quality = new String[]{"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Others"};
    private String[] list_graphic_quality = new String[]{"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Others"};
    private String[] list_global_rank = new String[]{"0", "10", "20", "30", "40", "50", "60", "70", "80", "90", "100", "Others"};


    private ListPopupWindow pw_website;
    private ListPopupWindow pw_website_technology;
    private ListPopupWindow pw_website_type;
    private ListPopupWindow pw_website_language;
    private ListPopupWindow pw_overlook_feel;
    private ListPopupWindow pw_content_quality;
    private ListPopupWindow pw_graphic_quality;
    private ListPopupWindow pw_global_rank;
    int clickable = 0;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.sales_crm3, container, false);
        LeadCRMList.page3 = true;
        edt_website = (EditText) view.findViewById(R.id.edt_website);
        edt_website_input = (EditText) view.findViewById(R.id.edt_website_input);
        edt_website_technology = (EditText) view.findViewById(R.id.edt_website_technology);
        edt_website_type = (EditText) view.findViewById(R.id.edt_website_type);
        edt_website_language = (EditText) view.findViewById(R.id.edt_website_language);
        edt_global_rank = (EditText) view.findViewById(R.id.edt_global_rank);
        edt_overlookfeel = (EditText) view.findViewById(R.id.edt_overlookfeel);
        edt_content_quality = (EditText) view.findViewById(R.id.edt_content_quality);
        edt_graphics_quality = (EditText) view.findViewById(R.id.edt_graphics_quality);
        edt_total_score = (EditText) view.findViewById(R.id.edt_total_score);

        edt_other_website = (EditText) view.findViewById(R.id.edt_other_website);
        edt_other_website_technology = (EditText) view.findViewById(R.id.edt_other_website_technology);
        edt_other_website_type = (EditText) view.findViewById(R.id.edt_other_website_type);
        edt_other_website_language = (EditText) view.findViewById(R.id.edt_other_website_language);
        edt_other_global_rank = (EditText) view.findViewById(R.id.edt_other_global_rank);
        edt_other_overlookfeel = (EditText) view.findViewById(R.id.edt_other_overlookfeel);
        edt_other_content_quality = (EditText) view.findViewById(R.id.edt_other_content_quality);
        edt_other_graphics_quality = (EditText) view.findViewById(R.id.edt_other_graphics_quality);

        txt_next = (TextView) view.findViewById(R.id.txt_next);
        txt1 = (TextView) view.findViewById(R.id.txt1);
        txt2 = (TextView) view.findViewById(R.id.txt2);
        txt3 = (TextView) view.findViewById(R.id.txt3);
        txt4 = (TextView) view.findViewById(R.id.txt4);
        txt5 = (TextView) view.findViewById(R.id.txt5);
        txt6 = (TextView) view.findViewById(R.id.txt6);
        pw_website = new ListPopupWindow(getActivity());
        pw_website.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_website));
        pw_website.setAnchorView(edt_website);
        pw_website.setModal(true);
        pw_website.setHeight(500);
        pw_website.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_website.setText(list_website[position]);
                pw_website.dismiss();
                edt_other_website.setText("");
                if (list_website[position].equalsIgnoreCase("Others")) {

                    edt_other_website.setVisibility(View.VISIBLE);
                } else {
                    edt_other_website.setVisibility(View.GONE);
                }
            }
        });
        pw_website_technology = new ListPopupWindow(getActivity());
        pw_website_technology.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_website_technology));
        pw_website_technology.setAnchorView(edt_website_technology);
        pw_website_technology.setModal(true);
        pw_website_technology.setHeight(500);
        pw_website_technology.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_website_technology.setText(list_website_technology[position]);
                pw_website_technology.dismiss();
                edt_other_website_technology.setText("");
                if (list_website_technology[position].equalsIgnoreCase("Others")) {

                    edt_other_website_technology.setVisibility(View.VISIBLE);
                } else {
                    edt_other_website_technology.setVisibility(View.GONE);
                }
            }
        });
        pw_website_type = new ListPopupWindow(getActivity());
        pw_website_type.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_website_type));
        pw_website_type.setAnchorView(edt_website_type);
        pw_website_type.setModal(true);
        pw_website_type.setHeight(500);
        pw_website_type.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_website_type.setText(list_website_type[position]);
                pw_website_type.dismiss();
                edt_other_website_type.setText("");
                if (list_website_type[position].equalsIgnoreCase("Others")) {

                    edt_other_website_type.setVisibility(View.VISIBLE);
                } else {
                    edt_other_website_type.setVisibility(View.GONE);
                }
            }
        });
        pw_website_language = new ListPopupWindow(getActivity());
        pw_website_language.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_website_language));
        pw_website_language.setAnchorView(edt_website_language);
        pw_website_language.setModal(true);
        pw_website_language.setHeight(500);
        pw_website_language.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_website_language.setText(list_website_language[position]);
                pw_website_language.dismiss();
                edt_other_website_language.setText("");
                if (list_website_language[position].equalsIgnoreCase("Others")) {

                    edt_other_website_language.setVisibility(View.VISIBLE);
                } else {
                    edt_other_website_language.setVisibility(View.GONE);
                }
            }
        });

        pw_overlook_feel = new ListPopupWindow(getActivity());
        pw_overlook_feel.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_overlook_feel));
        pw_overlook_feel.setAnchorView(edt_overlookfeel);
        pw_overlook_feel.setModal(true);
        pw_overlook_feel.setHeight(500);
        pw_overlook_feel.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_overlookfeel.setText(list_overlook_feel[position]);
                pw_overlook_feel.dismiss();
                edt_other_overlookfeel.setText("");
                if (list_overlook_feel[position].equalsIgnoreCase("Others")) {

                    edt_other_overlookfeel.setVisibility(View.VISIBLE);
                } else {
                    edt_other_overlookfeel.setVisibility(View.GONE);
                }
            }
        });

        pw_content_quality = new ListPopupWindow(getActivity());
        pw_content_quality.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_content_quality));
        pw_content_quality.setAnchorView(edt_content_quality);
        pw_content_quality.setModal(true);
        pw_content_quality.setHeight(500);
        pw_content_quality.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_content_quality.setText(list_content_quality[position]);
                pw_content_quality.dismiss();
                edt_other_content_quality.setText("");
                if (list_content_quality[position].equalsIgnoreCase("Others")) {

                    edt_other_content_quality.setVisibility(View.VISIBLE);
                } else {
                    edt_other_content_quality.setVisibility(View.GONE);
                }
            }
        });

        pw_graphic_quality = new ListPopupWindow(getActivity());
        pw_graphic_quality.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_graphic_quality));
        pw_graphic_quality.setAnchorView(edt_graphics_quality);
        pw_graphic_quality.setModal(true);
        pw_graphic_quality.setHeight(500);
        pw_graphic_quality.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_graphics_quality.setText(list_graphic_quality[position]);
                pw_graphic_quality.dismiss();
                edt_other_graphics_quality.setText("");
                if (list_graphic_quality[position].equalsIgnoreCase("Others")) {

                    edt_other_graphics_quality.setVisibility(View.VISIBLE);
                } else {
                    edt_other_graphics_quality.setVisibility(View.GONE);
                }
            }
        });
        pw_global_rank = new ListPopupWindow(getActivity());
        pw_global_rank.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_global_rank));
        pw_global_rank.setAnchorView(edt_global_rank);
        pw_global_rank.setModal(true);
        pw_global_rank.setHeight(500);
        pw_global_rank.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_global_rank.setText(list_global_rank[position]);
                pw_global_rank.dismiss();
                edt_other_global_rank.setText("");
                if (list_global_rank[position].equalsIgnoreCase("Others")) {

                    edt_other_global_rank.setVisibility(View.VISIBLE);
                } else {
                    edt_other_global_rank.setVisibility(View.GONE);
                }
            }
        });

        edt_website.setOnClickListener(this);
        edt_website_technology.setOnClickListener(this);
        edt_website_type.setOnClickListener(this);
        edt_website_language.setOnClickListener(this);
        edt_overlookfeel.setOnClickListener(this);
        edt_content_quality.setOnClickListener(this);
        edt_graphics_quality.setOnClickListener(this);
        edt_global_rank.setOnClickListener(this);

        txt_next.setOnClickListener(this);
        txt1.setOnClickListener(this);
        txt2.setOnClickListener(this);
        txt3.setOnClickListener(this);
        txt4.setOnClickListener(this);
        txt5.setOnClickListener(this);
        txt6.setOnClickListener(this);
        if (LeadCRMForm1.from.equalsIgnoreCase("from_update")) {
            LeadCRMFormUpdate.update_page2 = true;
        } else {
            MainActivity.add_page2 = true;
        }
        executeMethode();
        return view;
    }

    @Override
    public void onClick(View v) {
        InputMethodManager inputManager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);

        inputManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        switch (v.getId()) {
            case R.id.txt_next:
                if (validation()) {
                    clickable = 4;
                    data_save();
                }
                break;

            case R.id.edt_website:
                pw_website.show();
                break;
            case R.id.edt_website_technology:
                pw_website_technology.show();
                break;
            case R.id.edt_website_type:
                pw_website_type.show();
                break;
            case R.id.edt_website_language:
                pw_website_language.show();
                break;

            case R.id.edt_overlookfeel:
                pw_overlook_feel.show();
                break;
            case R.id.edt_content_quality:
                pw_content_quality.show();
                break;
            case R.id.edt_graphics_quality:
                pw_graphic_quality.show();
                break;
            case R.id.edt_global_rank:
                pw_global_rank.show();
                break;
            case R.id.txt1:
                if (LeadCRMList.page1) {
                    clickable = 1;
                    data_save();
                }
                break;
            case R.id.txt2:
                if (LeadCRMList.page2) {
                    clickable = 2;
                    data_save();
                }
                break;
            case R.id.txt3:
                if (LeadCRMList.page3) {
                    clickable = 3;
                    data_save();
                }
                break;
            case R.id.txt4:
                if (LeadCRMList.page4) {
                    clickable = 4;
                    data_save();
                }
                break;
            case R.id.txt5:
                if (LeadCRMList.page5) {
                    clickable = 5;
                    data_save();
                }
                break;
            case R.id.txt6:
                if (LeadCRMList.page6) {
                    clickable = 6;
                    data_save();
                }
                break;
        }
    }

    public boolean validation() {

        return true;
    }

    public void data_save() {
        Helper.storeLocally(getActivity(), "Website", edt_website.getText().toString());
        Helper.storeLocally(getActivity(), "website_other", edt_other_website.getText().toString());
        Helper.storeLocally(getActivity(), "Website_Technology", edt_website_technology.getText().toString());
        Helper.storeLocally(getActivity(), "website_technology_other", edt_other_website_technology.getText().toString());
        Helper.storeLocally(getActivity(), "Website_information", edt_website_input.getText().toString());
        Helper.storeLocally(getActivity(), "Website_Type", edt_website_type.getText().toString());
        Helper.storeLocally(getActivity(), "website_type_other", edt_other_website_type.getText().toString());
        Helper.storeLocally(getActivity(), "Overlook_and_Feels", edt_overlookfeel.getText().toString());
        Helper.storeLocally(getActivity(), "overlook_and_feel_other", edt_other_overlookfeel.getText().toString());
        Helper.storeLocally(getActivity(), "Website_Language", edt_website_language.getText().toString());
        Helper.storeLocally(getActivity(), "website_language_other", edt_other_website_language.getText().toString());
        Helper.storeLocally(getActivity(), "Content_Quality", edt_content_quality.getText().toString());
        Helper.storeLocally(getActivity(), "content_quality_other", edt_other_content_quality.getText().toString());
        Helper.storeLocally(getActivity(), "Graphic_Quality", edt_graphics_quality.getText().toString());
        Helper.storeLocally(getActivity(), "graphic_quality_other", edt_other_graphics_quality.getText().toString());
        Helper.storeLocally(getActivity(), "Global_Rank", edt_global_rank.getText().toString());
        Helper.storeLocally(getActivity(), "global_rank_other", edt_other_global_rank.getText().toString());
        Helper.storeLocally(getActivity(), "total_score", edt_total_score.getText().toString());

        if (clickable == 1) {
            Fragment fragment = new LeadCRMForm1();
            Bundle bundle = new Bundle();
            if (LeadCRMForm1.from.equalsIgnoreCase("from_update")) {
                bundle.putString("from", "from_update");
            } else {
                bundle.putString("from", "from_add");
            }
            fragment.setArguments(bundle);
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page1");
            ft.commit();
        } else if (clickable == 2) {
            Fragment fragment = new LeadCRMForm2();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page2");
            ft.commit();
        } else if (clickable == 3) {

        } else if (clickable == 4) {
            Fragment fragment = new LeadCRMForm4();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page4");
            ft.commit();
        } else if (clickable == 5) {
            Fragment fragment = new LeadCRMForm5();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page5");
            ft.commit();
        } else if (clickable == 6) {
            Fragment fragment = new LeadCRMForm6();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page6");
            ft.commit();
        }
    }

    public void executeMethode() {
        edt_website.setText(Helper.getLocalValue(getActivity(), "Website"));
        if (Helper.getLocalValue(getActivity(), "Website").equalsIgnoreCase("Others")) {
            edt_other_website.setVisibility(View.VISIBLE);
        }
        edt_other_website.setText(Helper.getLocalValue(getActivity(), "website_other"));
        edt_website_technology.setText(Helper.getLocalValue(getActivity(), "Website_Technology"));
        if (Helper.getLocalValue(getActivity(), "Website_Technology").equalsIgnoreCase("Others")) {
            edt_other_website_technology.setVisibility(View.VISIBLE);
        }
        edt_other_website_technology.setText(Helper.getLocalValue(getActivity(), "website_technology_other"));
        edt_website_input.setText(Helper.getLocalValue(getActivity(), "Website_information"));
        edt_website_type.setText(Helper.getLocalValue(getActivity(), "Website_Type"));
        if (Helper.getLocalValue(getActivity(), "Website_Type").equalsIgnoreCase("Others")) {
            edt_other_website_type.setVisibility(View.VISIBLE);
        }
        edt_other_website_type.setText(Helper.getLocalValue(getActivity(), "website_type_other"));
        edt_overlookfeel.setText(Helper.getLocalValue(getActivity(), "Overlook_and_Feels"));
        if (Helper.getLocalValue(getActivity(), "Overlook_and_Feels").equalsIgnoreCase("Others")) {
            edt_other_overlookfeel.setVisibility(View.VISIBLE);
        }
        edt_other_overlookfeel.setText(Helper.getLocalValue(getActivity(), "overlook_and_feel_other"));
        edt_website_language.setText(Helper.getLocalValue(getActivity(), "Website_Language"));
        if (Helper.getLocalValue(getActivity(), "Website_Language").equalsIgnoreCase("Others")) {
            edt_other_website_language.setVisibility(View.VISIBLE);
        }
        edt_other_website_language.setText(Helper.getLocalValue(getActivity(), "website_language_other"));
        edt_content_quality.setText(Helper.getLocalValue(getActivity(), "Content_Quality"));
        if (Helper.getLocalValue(getActivity(), "Content_Quality").equalsIgnoreCase("Others")) {
            edt_other_content_quality.setVisibility(View.VISIBLE);
        }
        edt_other_content_quality.setText(Helper.getLocalValue(getActivity(), "content_quality_other"));
        edt_graphics_quality.setText(Helper.getLocalValue(getActivity(), "Graphic_Quality"));
        if (Helper.getLocalValue(getActivity(), "Graphic_Quality").equalsIgnoreCase("Others")) {
            edt_other_graphics_quality.setVisibility(View.VISIBLE);
        }
        edt_other_graphics_quality.setText(Helper.getLocalValue(getActivity(), "graphic_quality_other"));
        edt_global_rank.setText(Helper.getLocalValue(getActivity(), "Global_Rank"));
        if (Helper.getLocalValue(getActivity(), "Global_Rank").equalsIgnoreCase("Others")) {
            edt_other_global_rank.setVisibility(View.VISIBLE);
        }
        edt_other_global_rank.setText(Helper.getLocalValue(getActivity(), "global_rank_other"));
        edt_total_score.setText(Helper.getLocalValue(getActivity(), "total_score"));
    }
}
