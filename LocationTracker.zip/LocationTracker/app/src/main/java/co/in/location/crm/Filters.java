package co.in.location.crm;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListPopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import co.in.location.R;
import co.in.location.Remote.ApiUtils;
import co.in.location.data.UserListData;
import co.in.location.response.UserListResponse;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Filters extends AppCompatActivity implements View.OnClickListener {
    EditText edt_assign_user, edt_from_date, edt_to_date;
    TextView txt_apply, txt_reset;
    private int mYear, mMonth, mDay, mHour, mMinute;
    ListPopupWindow lpw2;
    public static String type = "", user_id = "", from_date = "", to_date = "";
    ImageView img_back;
    SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat sdf3 = new SimpleDateFormat("dd-MM-yyyy");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filters);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        type = "";
        user_id = "";
        from_date = "";
        to_date = "";
        txt_apply = (TextView) findViewById(R.id.txt_apply);
        txt_reset = (TextView) findViewById(R.id.txt_reset);
        edt_assign_user = (EditText) findViewById(R.id.edt_assign_user);
        edt_from_date = (EditText) findViewById(R.id.edt_from_date);
        edt_to_date = (EditText) findViewById(R.id.edt_to_date);
        img_back = (ImageView) findViewById(R.id.img_back);
        edt_assign_user.setVisibility(View.GONE);
        edt_assign_user.setOnClickListener(this);
        edt_from_date.setOnClickListener(this);
        edt_to_date.setOnClickListener(this);
        txt_reset.setOnClickListener(this);
        txt_apply.setOnClickListener(this);
        img_back.setOnClickListener(this);
        lpw2 = new ListPopupWindow(Filters.this);

        getUserList();

    }

    @Override
    public void onClick(View v) {
        final Calendar c = Calendar.getInstance();
        switch (v.getId()) {
            case R.id.edt_from_date:

                // Get Current Date
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);
                edt_from_date.getBackground().setColorFilter(getResources().getColor(R.color.w_input), PorterDuff.Mode.SRC_ATOP);
                DatePickerDialog datePickerDialog = new DatePickerDialog(Filters.this, new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        /*if ((dayOfMonth < mDay) && (monthOfYear + 1 <= mMonth + 1) && (year <= mYear)) {
                            edt_receive_date.setText("");
                            Toast.makeText(Filters.this, "please select date after current date", Toast.LENGTH_LONG).show();
                        } else {*/
                        try {
                            String from = sdf2.format(sdf3.parse(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year));
                            edt_from_date.setText(from);
                        } catch (Exception e) {

                        }

                        /*  }*/
                        from_date = edt_from_date.getText().toString();

                    }
                }, mYear, mMonth, mDay);
                datePickerDialog.show();
                break;
            case R.id.edt_to_date:

                // Get Current Date
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);
                edt_to_date.getBackground().setColorFilter(getResources().getColor(R.color.w_input), PorterDuff.Mode.SRC_ATOP);
                DatePickerDialog datePickerDialog2 = new DatePickerDialog(Filters.this, new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        /*if ((dayOfMonth < mDay) && (monthOfYear + 1 <= mMonth + 1) && (year <= mYear)) {
                            edt_receive_date.setText("");
                            Toast.makeText(Filters.this, "please select date after current date", Toast.LENGTH_LONG).show();
                        } else {*/
                        try {
                            String to = sdf2.format(sdf3.parse(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year));
                            edt_to_date.setText(to);
                        } catch (Exception e) {

                        }
                        /*  }*/
                        to_date = edt_from_date.getText().toString();

                    }
                }, mYear, mMonth, mDay);
                datePickerDialog2.show();
                break;
            case R.id.edt_assign_user:
                lpw2.show();
                break;
            case R.id.txt_reset:
                edt_assign_user.setText("");
                edt_from_date.setText("");
                edt_to_date.setText("");
                break;
            case R.id.txt_apply:
//                Inbox.message_filter = true;
                Intent in = new Intent(Filters.this, FilteredLeads.class);
                in.putExtra("user_id", user_id);
                in.putExtra("type", type);
                in.putExtra("fromDate", from_date);
                in.putExtra("toDate", to_date);
                startActivity(in);
                Filters.this.finish();
                break;
            case R.id.img_back:
                Filters.this.finish();
                break;
        }

    }

    private void getUserList() {
        ApiUtils.getAlterationService().getUser("user-list", "").enqueue(new Callback<UserListResponse>() {
            @Override
            public void onResponse(Call<UserListResponse> call, Response<UserListResponse> response) {
                try {
                    if (response.code() == 200) {
                        if (response.body().statusCode == 1) {
                            edt_assign_user.setVisibility(View.VISIBLE);
                            lpw2.setAdapter(new UserTypeAdapter(Filters.this, response.body().userListData));
                            lpw2.setAnchorView(edt_assign_user);
                            lpw2.setModal(true);
                        } else {
                            Toast.makeText(Filters.this, response.body().message, Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(Filters.this, response.body().message, Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(Filters.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<UserListResponse> call, Throwable t) {
                t.printStackTrace();
                Toast.makeText(Filters.this, call.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    class UserTypeAdapter extends BaseAdapter {

        LayoutInflater inflater;
        List<UserListData> list;

        public UserTypeAdapter(FragmentActivity fragmentActivity, List<UserListData> list) {
            inflater = LayoutInflater.from(fragmentActivity);
            this.list = list;
        }

        @Override
        public int getCount() {
            return list.size() + 1;
        }

        @Override
        public Object getItem(int paramInt) {
            return paramInt;
        }

        class ViewHolder {
            TextView txt_role;
        }

        @Override
        public long getItemId(int paramInt) {
            return paramInt;
        }

        @Override
        public View getView(final int paramInt, View itemView, ViewGroup paramViewGroup) {

            final UserTypeAdapter.ViewHolder holder;
            if (itemView == null) {
                itemView = inflater.inflate(R.layout.user_role_list, paramViewGroup, false);
                holder = new UserTypeAdapter.ViewHolder();

                holder.txt_role = (TextView) itemView.findViewById(R.id.txt_role);
                itemView.setTag(holder);
            } else {
                holder = (UserTypeAdapter.ViewHolder) itemView.getTag();
            }
            if (paramInt == 0) {
                holder.txt_role.setText(capitalize("All"));
            } else {

                final UserListData roleData = list.get(paramInt - 1);
                holder.txt_role.setText(capitalize(roleData.name));
            }

            holder.txt_role.setTag(paramInt);
            holder.txt_role.setOnClickListener(new View.OnClickListener() {

                @SuppressWarnings("deprecation")
                @Override
                public void onClick(View vv) {
                    // TODO Auto-generated method stub
                    int pos1 = (Integer) vv.getTag();
                    final UserListData roleData = list.get(pos1);
                    edt_assign_user.getBackground().setColorFilter(getResources().getColor(R.color.w_input), PorterDuff.Mode.SRC_ATOP);
                    if (pos1 == 0) {
                        user_id = "0";
                        edt_assign_user.setText("All");
                    } else {
                        user_id = list.get(pos1 - 1).id;
                        edt_assign_user.setText(roleData.name);
                    }
                    lpw2.dismiss();
                }
            });
            return itemView;
        }
    }

    private String capitalize(String capString) {
        StringBuffer capBuffer = new StringBuffer();
        Matcher capMatcher = Pattern.compile("([a-z])([a-z]*)", Pattern.CASE_INSENSITIVE).matcher(capString);
        while (capMatcher.find()) {
            capMatcher.appendReplacement(capBuffer, capMatcher.group(1).toUpperCase() + capMatcher.group(2).toLowerCase());
        }
        return capMatcher.appendTail(capBuffer).toString();
    }

}
