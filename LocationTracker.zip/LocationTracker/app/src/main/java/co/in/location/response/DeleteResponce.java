package co.in.location.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DeleteResponce {
    @SerializedName("status")
    @Expose
    public int statusCode;
    @SerializedName("message")
    @Expose
    public String message;
}
