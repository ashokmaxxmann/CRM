package co.in.location.crm;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.percent.PercentRelativeLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListPopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import co.in.location.Helper;
import co.in.location.MainActivity;
import co.in.location.R;

public class LeadCRMForm5 extends Fragment implements View.OnClickListener {
    View view;
    EditText edt_first_action, edt_first_action_remarks, edt_second_action, edt_second_action_remarks, edt_third_action, edt_third_action_remarks, edt_fourth_action,
            edt_fourth_action_remarks, edt_fifth_action, edt_fifth_action_remarks, edt_final_action, edt_final_action_remarks;
    TextView txt_next, txt1, txt2, txt3, txt4, txt5, txt6;

    private String[] list_first_action = new String[]{"Call", "Visit", "Email", "SMS", "Others"};
    private String[] list_first_action_remark = new String[]{"Ringing", "Call Back", "Wrong Number", "Not Interested", "Call Back Again", "Meeting Fixed", "Meeting Done", "Proposal Sent", "Proposal to be sent", "Company Profile Sent", "Others"};
    private String[] list_second_action = new String[]{"Call", "Email", "SMS", "Visit", "Others"};
    private String[] list_second_action_remark = new String[]{"Meeting Reschedule", "Not Interested", "Call Back Again", "Meeting Fixed", "Meeting Done", "Proposal Sent", "Proposal Cancelled", "Others"};
    private String[] list_third_action = new String[]{"Call", "Visit", "Email", "Client Visit our Office", "Others"};
    private String[] list_third_action_remark = new String[]{"Meeting Reschedule", "Not Interested", "Call Back Again", "Meeting Fixed", "Meeting Done", "Proposal Sent", "Proposal Cancelled", "Budget issue", "Follow Up", "Others"};
    private String[] list_fourth_action = new String[]{"Call", "Email", "Visit", "Client Visit Our Office", "Others"};
    private String[] list_fourth_action_remark = new String[]{"Prospecting and Qualifying", "Presentation", "Handling Objections", "Call Back Again", "Proposal Sent", "Proposal Cancelled", "Budget issue", "Follow Up", "Sale Closed", "Others"};
    private String[] list_fifth_action = new String[]{"Call", "Visit", "Client Visited Our Office", "Email", "Others"};
    private String[] list_fifth_action_remark = new String[]{"Option 2", "Prospecting and Qualifying", "Presentation", "Negotiation", "Handling Objections", "Follow Up", "Budget Issue", "Proposal Cancelled", "Sale Closed", "Other Issue", "Review Competition Quote", "Others"};
    private String[] list_final_action = new String[]{"Call", "Email", "Visit", "Client Visited Our Office", "Others"};
    private String[] list_final_action_remark = new String[]{"Prospecting and Qualifying", "Presentation", "Negotiation", "Handling Objections", "Follow Up", "Budget Issue", "Proposal Cancelled", "Sale Closed", "Other Issue", "Review Competition Quote", "Others"};

    private ListPopupWindow pw_first_action;
    private ListPopupWindow pw_first_action_remark;
    private ListPopupWindow pw_second_action;
    private ListPopupWindow pw_second_action_remark;
    private ListPopupWindow pw_third_action;
    private ListPopupWindow pw_third_action_remark;
    private ListPopupWindow pw_fourth_action;
    private ListPopupWindow pw_fourth_action_remark;
    private ListPopupWindow pw_fifth_action;
    private ListPopupWindow pw_fifth_action_remark;
    private ListPopupWindow pw_final_action;
    private ListPopupWindow pw_final_action_remark;
    int clickable = 0;

    RelativeLayout rl_other_first_action, rl_other_first_action_remarks, rl_other_second_action, rl_other_second_action_remarks, rl_other_third_action, rl_other_third_action_remarks, rl_other_fourth_action,
            rl_other_fourth_action_remarks, rl_other_fifth_action, rl_other_fifth_action_remarks, rl_other_final_action, rl_other_final_action_remarks;
    PercentRelativeLayout rl_other_first_action_time, rl_other_first_action_remarks_time, rl_other_second_action_time, rl_other_second_action_remarks_time, rl_other_third_action_time, rl_other_third_action_remarks_time, rl_other_fourth_action_time,
            rl_other_fourth_action_remarks_time, rl_other_fifth_action_time, rl_other_fifth_action_remarks_time, rl_other_final_action_time, rl_other_final_action_remarks_time;

    EditText edt_other_first_action, edt_other_first_action_remarks, edt_other_second_action, edt_other_second_action_remarks, edt_other_third_action, edt_other_third_action_remarks, edt_other_fourth_action,
            edt_other_fourth_action_remarks, edt_other_fifth_action, edt_other_fifth_action_remarks, edt_other_final_action, edt_other_final_action_remarks;
    TextView txt_now_first_action, txt_now_first_action_remarks, txt_now_second_action, txt_now_second_action_remarks, txt_now_third_action, txt_now_third_action_remarks, txt_now_fourth_action,
            txt_now_fourth_action_remarks, txt_now_fifth_action, txt_now_fifth_action_remarks, txt_now_final_action, txt_now_final_action_remarks,
            txt_later_first_action, txt_later_first_action_remarks, txt_later_second_action, txt_later_second_action_remarks, txt_later_third_action, txt_later_third_action_remarks, txt_later_fourth_action,
            txt_later_fourth_action_remarks, txt_later_fifth_action, txt_later_fifth_action_remarks, txt_later_final_action, txt_later_final_action_remarks;
    SimpleDateFormat df;
    Date currentTime;
    TextView txt_first_action, txt_first_action_remarks, txt_second_action, txt_second_action_remarks, txt_third_action, txt_third_action_remarks, txt_fourth_action,
            txt_fourth_action_remarks, txt_fifth_action, txt_fifth_action_remarks, txt_final_action, txt_final_action_remarks;

    private int mYear, mMonth, mDay, mHour, mMinute;
    DatePickerDialog datePickerDialog;
    Calendar c;
    TextInputLayout first_action_txt_input_layout, first_action_remarks_txt_input_layout, second_action_txt_input_layout, second_action_remarks_txt_input_layout, third_action_txt_input_layout, third_action_remarks_txt_input_layout, fourth_action_txt_input_layout, fourth_action_remarks_txt_input_layout, fifth_action_txt_input_layout, fifth_action_remarks_txt_input_layout, final_action_txt_input_layout, final_action_remarks_txt_input_layout;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.sales_crm5, container, false);
        LeadCRMList.page5 = true;
        edt_first_action = (EditText) view.findViewById(R.id.edt_first_action);
        edt_first_action_remarks = (EditText) view.findViewById(R.id.edt_first_action_remarks);
        edt_second_action = (EditText) view.findViewById(R.id.edt_second_action);
        edt_second_action_remarks = (EditText) view.findViewById(R.id.edt_second_action_remarks);
        edt_third_action = (EditText) view.findViewById(R.id.edt_third_action);
        edt_third_action_remarks = (EditText) view.findViewById(R.id.edt_third_action_remarks);
        edt_fourth_action = (EditText) view.findViewById(R.id.edt_fourth_action);
        edt_fourth_action_remarks = (EditText) view.findViewById(R.id.edt_fourth_action_remarks);
        edt_fifth_action = (EditText) view.findViewById(R.id.edt_fifth_action);
        edt_fifth_action_remarks = (EditText) view.findViewById(R.id.edt_fifth_action_remarks);
        edt_final_action = (EditText) view.findViewById(R.id.edt_final_action);
        edt_final_action_remarks = (EditText) view.findViewById(R.id.edt_final_action_remarks);


        first_action_txt_input_layout = (TextInputLayout) view.findViewById(R.id.first_action_txt_input_layout);
        first_action_remarks_txt_input_layout = (TextInputLayout) view.findViewById(R.id.first_action_remarks_txt_input_layout);
        second_action_txt_input_layout = (TextInputLayout) view.findViewById(R.id.second_action_txt_input_layout);
        second_action_remarks_txt_input_layout = (TextInputLayout) view.findViewById(R.id.second_action_remarks_txt_input_layout);
        third_action_txt_input_layout = (TextInputLayout) view.findViewById(R.id.third_action_txt_input_layout);
        third_action_remarks_txt_input_layout = (TextInputLayout) view.findViewById(R.id.third_action_remarks_txt_input_layout);
        fourth_action_txt_input_layout = (TextInputLayout) view.findViewById(R.id.fourth_action_txt_input_layout);
        fourth_action_remarks_txt_input_layout = (TextInputLayout) view.findViewById(R.id.fourth_action_remarks_txt_input_layout);
        fifth_action_txt_input_layout = (TextInputLayout) view.findViewById(R.id.fifth_action_txt_input_layout);
        fifth_action_remarks_txt_input_layout = (TextInputLayout) view.findViewById(R.id.fifth_action_remarks_txt_input_layout);
        final_action_txt_input_layout = (TextInputLayout) view.findViewById(R.id.final_action_txt_input_layout);
        final_action_remarks_txt_input_layout = (TextInputLayout) view.findViewById(R.id.final_action_remarks_txt_input_layout);

        txt_next = (TextView) view.findViewById(R.id.txt_next);
        txt1 = (TextView) view.findViewById(R.id.txt1);
        txt2 = (TextView) view.findViewById(R.id.txt2);
        txt3 = (TextView) view.findViewById(R.id.txt3);
        txt4 = (TextView) view.findViewById(R.id.txt4);
        txt5 = (TextView) view.findViewById(R.id.txt5);
        txt6 = (TextView) view.findViewById(R.id.txt6);

        rl_other_first_action = (RelativeLayout) view.findViewById(R.id.rl_other_first_action);
        rl_other_first_action_time = (PercentRelativeLayout) view.findViewById(R.id.rl_other_first_action_time);
        edt_other_first_action = (EditText) view.findViewById(R.id.edt_other_first_action);
        txt_now_first_action = (TextView) view.findViewById(R.id.txt_now_first_action);
        txt_later_first_action = (TextView) view.findViewById(R.id.txt_later_first_action);

        rl_other_second_action = (RelativeLayout) view.findViewById(R.id.rl_other_second_action);
        rl_other_second_action_time = (PercentRelativeLayout) view.findViewById(R.id.rl_other_second_action_time);
        edt_other_second_action = (EditText) view.findViewById(R.id.edt_other_second_action);
        txt_now_second_action = (TextView) view.findViewById(R.id.txt_now_second_action);
        txt_later_second_action = (TextView) view.findViewById(R.id.txt_later_second_action);

        rl_other_third_action = (RelativeLayout) view.findViewById(R.id.rl_other_third_action);
        rl_other_third_action_time = (PercentRelativeLayout) view.findViewById(R.id.rl_other_third_action_time);
        edt_other_third_action = (EditText) view.findViewById(R.id.edt_other_third_action);
        txt_now_third_action = (TextView) view.findViewById(R.id.txt_now_third_action);
        txt_later_third_action = (TextView) view.findViewById(R.id.txt_later_third_action);

        rl_other_fourth_action = (RelativeLayout) view.findViewById(R.id.rl_other_fourth_action);
        rl_other_fourth_action_time = (PercentRelativeLayout) view.findViewById(R.id.rl_other_fourth_action_time);
        edt_other_fourth_action = (EditText) view.findViewById(R.id.edt_other_fourth_action);
        txt_now_fourth_action = (TextView) view.findViewById(R.id.txt_now_fourth_action);
        txt_later_fourth_action = (TextView) view.findViewById(R.id.txt_later_fourth_action);

        rl_other_fifth_action = (RelativeLayout) view.findViewById(R.id.rl_other_fifth_action);
        rl_other_fifth_action_time = (PercentRelativeLayout) view.findViewById(R.id.rl_other_fifth_action_time);
        edt_other_fifth_action = (EditText) view.findViewById(R.id.edt_other_fifth_action);
        txt_now_fifth_action = (TextView) view.findViewById(R.id.txt_now_fifth_action);
        txt_later_fifth_action = (TextView) view.findViewById(R.id.txt_later_fifth_action);

        rl_other_final_action = (RelativeLayout) view.findViewById(R.id.rl_other_final_action);
        rl_other_final_action_time = (PercentRelativeLayout) view.findViewById(R.id.rl_other_final_action_time);
        edt_other_final_action = (EditText) view.findViewById(R.id.edt_other_final_action);
        txt_now_final_action = (TextView) view.findViewById(R.id.txt_now_final_action);
        txt_later_final_action = (TextView) view.findViewById(R.id.txt_later_final_action);

        rl_other_first_action_remarks = (RelativeLayout) view.findViewById(R.id.rl_other_first_action);
        rl_other_first_action_remarks_time = (PercentRelativeLayout) view.findViewById(R.id.rl_other_first_action_remarks_time);
        edt_other_first_action_remarks = (EditText) view.findViewById(R.id.edt_other_first_action_remarks);
        txt_now_first_action_remarks = (TextView) view.findViewById(R.id.txt_now_first_action_remarks);
        txt_later_first_action_remarks = (TextView) view.findViewById(R.id.txt_later_first_action_remarks);

        rl_other_second_action_remarks = (RelativeLayout) view.findViewById(R.id.rl_other_second_action_remarks);
        rl_other_second_action_remarks_time = (PercentRelativeLayout) view.findViewById(R.id.rl_other_second_action_remarks_time);
        edt_other_second_action_remarks = (EditText) view.findViewById(R.id.edt_other_second_action_remarks);
        txt_now_second_action_remarks = (TextView) view.findViewById(R.id.txt_now_second_action_remarks);
        txt_later_second_action_remarks = (TextView) view.findViewById(R.id.txt_later_second_action_remarks);

        rl_other_third_action_remarks = (RelativeLayout) view.findViewById(R.id.rl_other_third_action_remarks);
        rl_other_third_action_remarks_time = (PercentRelativeLayout) view.findViewById(R.id.rl_other_third_action_remarks_time);
        edt_other_third_action_remarks = (EditText) view.findViewById(R.id.edt_other_third_action_remarks);
        txt_now_third_action_remarks = (TextView) view.findViewById(R.id.txt_now_third_action_remarks);
        txt_later_third_action_remarks = (TextView) view.findViewById(R.id.txt_later_third_action_remarks);

        rl_other_fourth_action_remarks = (RelativeLayout) view.findViewById(R.id.rl_other_fourth_action_remarks);
        rl_other_fourth_action_remarks_time = (PercentRelativeLayout) view.findViewById(R.id.rl_other_fourth_action_remarks_time);
        edt_other_fourth_action_remarks = (EditText) view.findViewById(R.id.edt_other_fourth_action_remarks);
        txt_now_fourth_action_remarks = (TextView) view.findViewById(R.id.txt_now_fourth_action_remarks);
        txt_later_fourth_action_remarks = (TextView) view.findViewById(R.id.txt_later_fourth_action_remarks);

        rl_other_fifth_action_remarks = (RelativeLayout) view.findViewById(R.id.rl_other_fifth_action_remarks);
        rl_other_fifth_action_remarks_time = (PercentRelativeLayout) view.findViewById(R.id.rl_other_fifth_action_remarks_time);
        edt_other_fifth_action_remarks = (EditText) view.findViewById(R.id.edt_other_fifth_action_remarks);
        txt_now_fifth_action_remarks = (TextView) view.findViewById(R.id.txt_now_fifth_action_remarks);
        txt_later_fifth_action_remarks = (TextView) view.findViewById(R.id.txt_later_fifth_action_remarks);

        rl_other_final_action_remarks = (RelativeLayout) view.findViewById(R.id.rl_other_final_action_remarks);
        rl_other_final_action_remarks_time = (PercentRelativeLayout) view.findViewById(R.id.rl_other_final_action_remarks_time);
        edt_other_final_action_remarks = (EditText) view.findViewById(R.id.edt_other_final_action_remarks);
        txt_now_final_action_remarks = (TextView) view.findViewById(R.id.txt_now_final_action_remarks);
        txt_later_final_action_remarks = (TextView) view.findViewById(R.id.txt_later_final_action_remarks);


        txt_first_action = (TextView) view.findViewById(R.id.txt_first_action);
        txt_first_action_remarks = (TextView) view.findViewById(R.id.txt_first_action_remarks);
        txt_second_action = (TextView) view.findViewById(R.id.txt_second_action);
        txt_second_action_remarks = (TextView) view.findViewById(R.id.txt_second_action_remarks);
        txt_third_action = (TextView) view.findViewById(R.id.txt_third_action);
        txt_third_action_remarks = (TextView) view.findViewById(R.id.txt_third_action_remarks);
        txt_fourth_action = (TextView) view.findViewById(R.id.txt_fourth_action);
        txt_fourth_action_remarks = (TextView) view.findViewById(R.id.txt_fourth_action_remarks);
        txt_fifth_action = (TextView) view.findViewById(R.id.txt_fifth_action);
        txt_fifth_action_remarks = (TextView) view.findViewById(R.id.txt_fifth_action_remarks);
        txt_final_action = (TextView) view.findViewById(R.id.txt_final_action);
        txt_final_action_remarks = (TextView) view.findViewById(R.id.txt_final_action_remarks);

        df = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

        pw_first_action = new ListPopupWindow(getActivity());
        pw_first_action.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_first_action));
        pw_first_action.setAnchorView(edt_first_action);
        pw_first_action.setModal(true);
        pw_first_action.setHeight(500);
        pw_first_action.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_first_action.setText(list_first_action[position]);
                pw_first_action.dismiss();
                txt_first_action.setVisibility(View.GONE);
                txt_first_action.setText("");
                edt_other_first_action.setText("");
                first_action_remarks_txt_input_layout.setVisibility(View.VISIBLE);
                if (list_first_action[position].equalsIgnoreCase("Others")) {

                    rl_other_first_action_time.setVisibility(View.GONE);
                    edt_other_first_action.setVisibility(View.VISIBLE);
                } else if (list_first_action[position].equalsIgnoreCase("Call")) {
                    rl_other_first_action_time.setVisibility(View.VISIBLE);
                    edt_other_first_action.setVisibility(View.GONE);
                } else {
                    rl_other_first_action_time.setVisibility(View.GONE);
                    edt_other_first_action.setVisibility(View.GONE);
                }
            }
        });
        pw_first_action_remark = new ListPopupWindow(getActivity());
        pw_first_action_remark.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_first_action_remark));
        pw_first_action_remark.setAnchorView(edt_first_action_remarks);
        pw_first_action_remark.setModal(true);
        pw_first_action_remark.setHeight(500);
        pw_first_action_remark.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_first_action_remarks.setText(list_first_action_remark[position]);
                pw_first_action_remark.dismiss();
                txt_first_action_remarks.setVisibility(View.GONE);
                txt_first_action_remarks.setText("");
                edt_other_first_action_remarks.setText("");
                second_action_txt_input_layout.setVisibility(View.VISIBLE);
                if (list_first_action_remark[position].equalsIgnoreCase("Others")) {
                    rl_other_first_action_remarks_time.setVisibility(View.GONE);
                    edt_other_first_action_remarks.setVisibility(View.VISIBLE);
                } else if ((list_first_action_remark[position].equalsIgnoreCase("Call Back")) || (list_first_action_remark[position].equalsIgnoreCase("Call Back Again")) || (list_first_action_remark[position].equalsIgnoreCase("Meeting Fixed")) || (list_first_action_remark[position].equalsIgnoreCase("Meeting Done")) || (list_first_action_remark[position].equalsIgnoreCase("Proposal Sent"))) {
                    rl_other_first_action_remarks_time.setVisibility(View.VISIBLE);
                    edt_other_first_action_remarks.setVisibility(View.GONE);
                } else {
                    rl_other_first_action_remarks_time.setVisibility(View.GONE);
                    edt_other_first_action_remarks.setVisibility(View.GONE);
                }
            }
        });
        pw_second_action = new ListPopupWindow(getActivity());
        pw_second_action.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_second_action));
        pw_second_action.setAnchorView(edt_second_action);
        pw_second_action.setModal(true);
        pw_second_action.setHeight(500);
        pw_second_action.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_second_action.setText(list_second_action[position]);
                pw_second_action.dismiss();
                txt_second_action.setVisibility(View.GONE);
                txt_second_action.setText("");
                edt_other_second_action.setText("");
                second_action_remarks_txt_input_layout.setVisibility(View.VISIBLE);
                if (list_second_action[position].equalsIgnoreCase("Others")) {

                    rl_other_second_action_time.setVisibility(View.GONE);
                    edt_other_second_action.setVisibility(View.VISIBLE);
                } else if (list_second_action[position].equalsIgnoreCase("Call")) {
                    rl_other_second_action_time.setVisibility(View.VISIBLE);
                    edt_other_second_action.setVisibility(View.GONE);
                } else {
                    rl_other_second_action_time.setVisibility(View.GONE);
                    edt_other_second_action.setVisibility(View.GONE);
                }
            }
        });
        pw_second_action_remark = new ListPopupWindow(getActivity());
        pw_second_action_remark.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_second_action_remark));
        pw_second_action_remark.setAnchorView(edt_second_action_remarks);
        pw_second_action_remark.setModal(true);
        pw_second_action_remark.setHeight(500);
        pw_second_action_remark.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_second_action_remarks.setText(list_second_action_remark[position]);
                pw_second_action_remark.dismiss();
                txt_second_action_remarks.setVisibility(View.GONE);
                txt_second_action_remarks.setText("");
                edt_other_second_action_remarks.setText("");
                third_action_txt_input_layout.setVisibility(View.VISIBLE);
                if (list_second_action_remark[position].equalsIgnoreCase("Others")) {

                    rl_other_second_action_remarks_time.setVisibility(View.GONE);
                    edt_other_second_action_remarks.setVisibility(View.VISIBLE);
                } else if ((list_second_action_remark[position].equalsIgnoreCase("Meeting Reschedule")) || (list_second_action_remark[position].equalsIgnoreCase("Call Back Again")) || (list_second_action_remark[position].equalsIgnoreCase("Meeting Fixed")) || (list_second_action_remark[position].equalsIgnoreCase("Meeting Done")) || (list_second_action_remark[position].equalsIgnoreCase("Proposal Sent")) || (list_second_action_remark[position].equalsIgnoreCase("Proposal Cancelled"))) {
                    rl_other_second_action_remarks_time.setVisibility(View.VISIBLE);
                    edt_other_second_action_remarks.setVisibility(View.GONE);
                } else {
                    rl_other_second_action_remarks_time.setVisibility(View.GONE);
                    edt_other_second_action_remarks.setVisibility(View.GONE);
                }
            }
        });
        pw_third_action = new ListPopupWindow(getActivity());
        pw_third_action.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_third_action));
        pw_third_action.setAnchorView(edt_third_action);
        pw_third_action.setModal(true);
        pw_third_action.setHeight(500);
        pw_third_action.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_third_action.setText(list_third_action[position]);
                pw_third_action.dismiss();
                txt_third_action.setVisibility(View.GONE);
                txt_third_action.setText("");
                edt_other_third_action.setText("");
                third_action_remarks_txt_input_layout.setVisibility(View.VISIBLE);
                if (list_third_action[position].equalsIgnoreCase("Others")) {

                    rl_other_third_action_time.setVisibility(View.GONE);
                    edt_other_third_action.setVisibility(View.VISIBLE);
                } else if (list_third_action[position].equalsIgnoreCase("Call")) {
                    rl_other_third_action_time.setVisibility(View.VISIBLE);
                    edt_other_third_action.setVisibility(View.GONE);
                } else {
                    rl_other_third_action_time.setVisibility(View.GONE);
                    edt_other_third_action.setVisibility(View.GONE);
                }
            }
        });
        pw_third_action_remark = new ListPopupWindow(getActivity());
        pw_third_action_remark.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_third_action_remark));
        pw_third_action_remark.setAnchorView(edt_third_action_remarks);
        pw_third_action_remark.setModal(true);
        pw_third_action_remark.setHeight(500);
        pw_third_action_remark.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_third_action_remarks.setText(list_third_action_remark[position]);
                pw_third_action_remark.dismiss();
                txt_third_action_remarks.setVisibility(View.GONE);
                txt_third_action_remarks.setText("");
                edt_other_third_action_remarks.setText("");
                fourth_action_txt_input_layout.setVisibility(View.VISIBLE);
                if (list_third_action_remark[position].equalsIgnoreCase("Others")) {

                    rl_other_third_action_remarks_time.setVisibility(View.GONE);
                    edt_other_third_action_remarks.setVisibility(View.VISIBLE);
                } else if ((list_third_action_remark[position].equalsIgnoreCase("Metting Reschedule")) || (list_third_action_remark[position].equalsIgnoreCase("Call Back Again")) || (list_third_action_remark[position].equalsIgnoreCase("Meeting Fixed")) || (list_third_action_remark[position].equalsIgnoreCase("Meeting Done")) || (list_third_action_remark[position].equalsIgnoreCase("Proposal Sent")) || (list_third_action_remark[position].equalsIgnoreCase("Proposal Cancelled")) || (list_third_action_remark[position].equalsIgnoreCase("Follow Up"))) {
                    rl_other_third_action_remarks_time.setVisibility(View.VISIBLE);
                    edt_other_third_action_remarks.setVisibility(View.GONE);
                } else {
                    rl_other_third_action_remarks_time.setVisibility(View.VISIBLE);
                    edt_other_third_action_remarks.setVisibility(View.GONE);
                }
            }
        });
        pw_fourth_action = new ListPopupWindow(getActivity());
        pw_fourth_action.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_fourth_action));
        pw_fourth_action.setAnchorView(edt_fourth_action);
        pw_fourth_action.setModal(true);
        pw_fourth_action.setHeight(500);
        pw_fourth_action.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_fourth_action.setText(list_fourth_action[position]);
                pw_fourth_action.dismiss();
                txt_fourth_action.setVisibility(View.GONE);
                txt_fourth_action.setText("");
                edt_other_fourth_action.setText("");
                fourth_action_remarks_txt_input_layout.setVisibility(View.VISIBLE);
                if (list_fourth_action[position].equalsIgnoreCase("Others")) {

                    rl_other_fourth_action_time.setVisibility(View.GONE);
                    edt_other_fourth_action.setVisibility(View.VISIBLE);
                } else if (list_fourth_action[position].equalsIgnoreCase("Call")) {
                    rl_other_fourth_action_time.setVisibility(View.VISIBLE);
                    edt_other_fourth_action.setVisibility(View.GONE);
                } else {
                    rl_other_fourth_action_time.setVisibility(View.GONE);
                    edt_other_fourth_action.setVisibility(View.GONE);
                }
            }
        });
        pw_fourth_action_remark = new ListPopupWindow(getActivity());
        pw_fourth_action_remark.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_fourth_action_remark));
        pw_fourth_action_remark.setAnchorView(edt_fourth_action_remarks);
        pw_fourth_action_remark.setModal(true);
        pw_fourth_action_remark.setHeight(500);
        pw_fourth_action_remark.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_fourth_action_remarks.setText(list_fourth_action_remark[position]);
                pw_fourth_action_remark.dismiss();
                txt_fourth_action_remarks.setVisibility(View.GONE);
                txt_fourth_action_remarks.setText("");
                edt_other_fourth_action_remarks.setText("");
                fifth_action_txt_input_layout.setVisibility(View.VISIBLE);
                if (list_fourth_action_remark[position].equalsIgnoreCase("Others")) {
                    rl_other_fourth_action_remarks_time.setVisibility(View.GONE);
                    edt_other_fourth_action_remarks.setVisibility(View.VISIBLE);
                } else if ((list_fourth_action_remark[position].equalsIgnoreCase("Presentation")) || (list_fourth_action_remark[position].equalsIgnoreCase("Call Back Again")) || (list_fourth_action_remark[position].equalsIgnoreCase("Proposal Sent")) || (list_fourth_action_remark[position].equalsIgnoreCase("Follow Up")) || (list_fourth_action_remark[position].equalsIgnoreCase("Sale Closed"))) {
                    rl_other_fourth_action_remarks_time.setVisibility(View.VISIBLE);
                    edt_other_fourth_action_remarks.setVisibility(View.GONE);
                } else {
                    rl_other_fourth_action_remarks_time.setVisibility(View.VISIBLE);
                    edt_other_fourth_action_remarks.setVisibility(View.GONE);
                }
            }
        });
        pw_fifth_action = new ListPopupWindow(getActivity());
        pw_fifth_action.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_fifth_action));
        pw_fifth_action.setAnchorView(edt_fifth_action);
        pw_fifth_action.setModal(true);
        pw_fifth_action.setHeight(500);
        pw_fifth_action.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_fifth_action.setText(list_fifth_action[position]);
                pw_fifth_action.dismiss();
                txt_fifth_action.setVisibility(View.GONE);
                txt_fifth_action.setText("");
                edt_other_fifth_action.setText("");
                fifth_action_remarks_txt_input_layout.setVisibility(View.VISIBLE);
                if (list_fifth_action[position].equalsIgnoreCase("Others")) {

                    rl_other_fifth_action_time.setVisibility(View.GONE);
                    edt_other_fifth_action.setVisibility(View.VISIBLE);
                } else if (list_fifth_action[position].equalsIgnoreCase("Call")) {
                    rl_other_fifth_action_time.setVisibility(View.VISIBLE);
                    edt_other_fifth_action.setVisibility(View.GONE);
                } else {
                    rl_other_fifth_action_time.setVisibility(View.GONE);
                    edt_other_fifth_action.setVisibility(View.GONE);
                }
            }
        });
        pw_fifth_action_remark = new ListPopupWindow(getActivity());
        pw_fifth_action_remark.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_fifth_action_remark));
        pw_fifth_action_remark.setAnchorView(edt_fifth_action_remarks);
        pw_fifth_action_remark.setModal(true);
        pw_fifth_action_remark.setHeight(500);
        pw_fifth_action_remark.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_fifth_action_remarks.setText(list_fifth_action_remark[position]);
                pw_fifth_action_remark.dismiss();
                txt_fifth_action_remarks.setVisibility(View.GONE);
                txt_fifth_action_remarks.setText("");
                edt_other_fifth_action_remarks.setText("");
                final_action_txt_input_layout.setVisibility(View.VISIBLE);
                if (list_fifth_action_remark[position].equalsIgnoreCase("Others")) {

                    rl_other_fifth_action_remarks_time.setVisibility(View.GONE);
                    edt_other_fifth_action_remarks.setVisibility(View.VISIBLE);
                } else if ((list_fifth_action_remark[position].equalsIgnoreCase("Presentation")) || (list_fifth_action_remark[position].equalsIgnoreCase("Follow Up")) || (list_fifth_action_remark[position].equalsIgnoreCase("Proposal Cancelled")) || (list_fifth_action_remark[position].equalsIgnoreCase("Sale Closed"))) {
                    rl_other_fifth_action_remarks_time.setVisibility(View.VISIBLE);
                    edt_other_fifth_action_remarks.setVisibility(View.GONE);
                } else {
                    rl_other_fifth_action_remarks_time.setVisibility(View.VISIBLE);
                    edt_other_fifth_action_remarks.setVisibility(View.GONE);
                }
            }
        });
        pw_final_action = new ListPopupWindow(getActivity());
        pw_final_action.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_final_action));
        pw_final_action.setAnchorView(edt_final_action);
        pw_final_action.setModal(true);
        pw_final_action.setHeight(500);
        pw_final_action.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_final_action.setText(list_final_action[position]);
                pw_final_action.dismiss();
                txt_final_action.setVisibility(View.GONE);
                txt_final_action.setText("");
                edt_other_final_action.setText("");
                final_action_remarks_txt_input_layout.setVisibility(View.VISIBLE);
                if (list_final_action[position].equalsIgnoreCase("Others")) {

                    rl_other_final_action_time.setVisibility(View.GONE);
                    edt_other_final_action.setVisibility(View.VISIBLE);
                } else if (list_final_action[position].equalsIgnoreCase("Call")) {
                    rl_other_final_action_time.setVisibility(View.VISIBLE);
                    edt_other_final_action.setVisibility(View.GONE);
                } else {
                    rl_other_final_action_time.setVisibility(View.GONE);
                    edt_other_final_action.setVisibility(View.GONE);
                }
            }
        });
        pw_final_action_remark = new ListPopupWindow(getActivity());
        pw_final_action_remark.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, list_final_action_remark));
        pw_final_action_remark.setAnchorView(edt_final_action_remarks);
        pw_final_action_remark.setModal(true);
        pw_final_action_remark.setHeight(500);
        pw_final_action_remark.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                edt_final_action_remarks.setText(list_final_action_remark[position]);
                pw_final_action_remark.dismiss();
                txt_final_action_remarks.setVisibility(View.GONE);
                txt_final_action_remarks.setText("");
                edt_other_final_action_remarks.setText("");
                txt_next.setVisibility(View.VISIBLE);
                if (list_final_action_remark[position].equalsIgnoreCase("Others")) {

                    rl_other_final_action_remarks_time.setVisibility(View.GONE);
                    edt_other_final_action_remarks.setVisibility(View.VISIBLE);
                } else if ((list_final_action_remark[position].equalsIgnoreCase("Presentation")) || (list_final_action_remark[position].equalsIgnoreCase("Follow Up")) || (list_final_action_remark[position].equalsIgnoreCase("Proposal Cancelled")) || (list_final_action_remark[position].equalsIgnoreCase("Sale Closed"))) {
                    rl_other_final_action_remarks_time.setVisibility(View.VISIBLE);
                    edt_other_final_action_remarks.setVisibility(View.GONE);
                } else {
                    rl_other_final_action_remarks_time.setVisibility(View.VISIBLE);
                    edt_other_final_action_remarks.setVisibility(View.GONE);
                }
            }
        });

        edt_first_action.setOnClickListener(this);
        edt_first_action_remarks.setOnClickListener(this);
        edt_second_action.setOnClickListener(this);
        edt_second_action_remarks.setOnClickListener(this);
        edt_third_action.setOnClickListener(this);
        edt_third_action_remarks.setOnClickListener(this);
        edt_fourth_action.setOnClickListener(this);
        edt_fourth_action_remarks.setOnClickListener(this);
        edt_fifth_action.setOnClickListener(this);
        edt_fifth_action_remarks.setOnClickListener(this);
        edt_final_action.setOnClickListener(this);
        edt_final_action_remarks.setOnClickListener(this);

        txt_now_first_action.setOnClickListener(this);
        txt_now_first_action_remarks.setOnClickListener(this);
        txt_now_second_action.setOnClickListener(this);
        txt_now_second_action_remarks.setOnClickListener(this);
        txt_now_third_action.setOnClickListener(this);
        txt_now_third_action_remarks.setOnClickListener(this);
        txt_now_fourth_action.setOnClickListener(this);
        txt_now_fourth_action_remarks.setOnClickListener(this);
        txt_now_fifth_action.setOnClickListener(this);
        txt_now_fifth_action_remarks.setOnClickListener(this);
        txt_now_final_action.setOnClickListener(this);
        txt_now_final_action_remarks.setOnClickListener(this);
        txt_later_first_action.setOnClickListener(this);
        txt_later_first_action_remarks.setOnClickListener(this);
        txt_later_second_action.setOnClickListener(this);
        txt_later_second_action_remarks.setOnClickListener(this);
        txt_later_third_action.setOnClickListener(this);
        txt_later_third_action_remarks.setOnClickListener(this);
        txt_later_fourth_action.setOnClickListener(this);
        txt_later_fourth_action_remarks.setOnClickListener(this);
        txt_later_fifth_action.setOnClickListener(this);
        txt_later_fifth_action_remarks.setOnClickListener(this);
        txt_later_final_action.setOnClickListener(this);
        txt_later_final_action_remarks.setOnClickListener(this);

        txt_next.setOnClickListener(this);
        txt1.setOnClickListener(this);
        txt2.setOnClickListener(this);
        txt3.setOnClickListener(this);
        txt4.setOnClickListener(this);
        txt5.setOnClickListener(this);
        txt6.setOnClickListener(this);
        if (LeadCRMForm1.from.equalsIgnoreCase("from_update")) {
            LeadCRMFormUpdate.update_page2 = true;
        } else {
            first_action_txt_input_layout.setVisibility(View.GONE);
            first_action_remarks_txt_input_layout.setVisibility(View.GONE);
            second_action_txt_input_layout.setVisibility(View.GONE);
            second_action_remarks_txt_input_layout.setVisibility(View.GONE);
            third_action_txt_input_layout.setVisibility(View.GONE);
            third_action_remarks_txt_input_layout.setVisibility(View.GONE);
            fourth_action_txt_input_layout.setVisibility(View.GONE);
            fourth_action_remarks_txt_input_layout.setVisibility(View.GONE);
            fifth_action_txt_input_layout.setVisibility(View.GONE);
            fifth_action_remarks_txt_input_layout.setVisibility(View.GONE);
            final_action_txt_input_layout.setVisibility(View.GONE);
            final_action_remarks_txt_input_layout.setVisibility(View.GONE);

            MainActivity.add_page2 = true;
        }
        executeMethode();
        return view;
    }

    @Override
    public void onClick(View v) {
        InputMethodManager inputManager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);

        inputManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        switch (v.getId()) {
            case R.id.txt_next:
                if (validation()) {
                    clickable = 6;
                    data_save();
                }
                break;

            case R.id.edt_first_action:
                pw_first_action.show();
                break;
            case R.id.edt_first_action_remarks:
                pw_first_action_remark.show();
                break;
            case R.id.edt_second_action:
                pw_second_action.show();
                break;
            case R.id.edt_second_action_remarks:
                pw_second_action_remark.show();
                break;
            case R.id.edt_third_action:
                pw_third_action.show();
                break;
            case R.id.edt_third_action_remarks:
                pw_third_action_remark.show();
                break;
            case R.id.edt_fourth_action:
                pw_fourth_action.show();
                break;
            case R.id.edt_fourth_action_remarks:
                pw_fourth_action_remark.show();
                break;
            case R.id.edt_fifth_action:
                pw_fifth_action.show();
                break;
            case R.id.edt_fifth_action_remarks:
                pw_fifth_action_remark.show();
                break;
            case R.id.edt_final_action:
                pw_final_action.show();
                break;
            case R.id.edt_final_action_remarks:
                pw_final_action_remark.show();
                break;
            case R.id.txt1:
                if (LeadCRMList.page1) {
                    clickable = 1;
                    data_save();
                }
                break;
            case R.id.txt2:
                if (LeadCRMList.page2) {
                    clickable = 2;
                    data_save();
                }
                break;
            case R.id.txt3:
                if (LeadCRMList.page3) {
                    clickable = 3;
                    data_save();
                }
                break;
            case R.id.txt4:
                if (LeadCRMList.page4) {
                    clickable = 4;
                    data_save();
                }
                break;
            case R.id.txt5:
                if (LeadCRMList.page5) {
                    clickable = 5;
                    data_save();
                }
                break;
            case R.id.txt6:
                if (LeadCRMList.page6) {
                    clickable = 6;
                    data_save();
                }
                break;
            case R.id.txt_now_first_action:
                currentTime = Calendar.getInstance().getTime();
                txt_first_action.setVisibility(View.VISIBLE);
                txt_first_action.setText(df.format(currentTime));
                rl_other_first_action_time.setVisibility(View.GONE);
                break;
            case R.id.txt_now_first_action_remarks:
                currentTime = Calendar.getInstance().getTime();
                txt_first_action_remarks.setVisibility(View.VISIBLE);
                txt_first_action_remarks.setText(df.format(currentTime));
                rl_other_first_action_remarks_time.setVisibility(View.GONE);
                break;
            case R.id.txt_now_second_action:
                currentTime = Calendar.getInstance().getTime();

                txt_second_action.setVisibility(View.VISIBLE);
                txt_second_action.setText(df.format(currentTime));
                rl_other_second_action_time.setVisibility(View.GONE);
                break;
            case R.id.txt_now_second_action_remarks:
                currentTime = Calendar.getInstance().getTime();

                txt_second_action_remarks.setVisibility(View.VISIBLE);
                txt_second_action_remarks.setText(df.format(currentTime));
                rl_other_second_action_remarks_time.setVisibility(View.GONE);
                break;
            case R.id.txt_now_third_action:
                currentTime = Calendar.getInstance().getTime();

                txt_third_action.setVisibility(View.VISIBLE);
                txt_third_action.setText(df.format(currentTime));
                rl_other_third_action_time.setVisibility(View.GONE);
                break;
            case R.id.txt_now_third_action_remarks:
                currentTime = Calendar.getInstance().getTime();

                txt_third_action_remarks.setVisibility(View.VISIBLE);
                txt_third_action_remarks.setText(df.format(currentTime));
                rl_other_third_action_remarks_time.setVisibility(View.GONE);
                break;
            case R.id.txt_now_fourth_action:
                currentTime = Calendar.getInstance().getTime();

                txt_fourth_action.setVisibility(View.VISIBLE);
                txt_fourth_action.setText(df.format(currentTime));
                rl_other_fourth_action_time.setVisibility(View.GONE);
                break;
            case R.id.txt_now_fourth_action_remarks:
                currentTime = Calendar.getInstance().getTime();

                txt_fourth_action_remarks.setVisibility(View.VISIBLE);
                txt_fourth_action_remarks.setText(df.format(currentTime));
                rl_other_fourth_action_remarks_time.setVisibility(View.GONE);
                break;
            case R.id.txt_now_fifth_action:
                currentTime = Calendar.getInstance().getTime();

                txt_fifth_action.setVisibility(View.VISIBLE);
                txt_fifth_action.setText(df.format(currentTime));
                rl_other_fifth_action_time.setVisibility(View.GONE);
                break;
            case R.id.txt_now_fifth_action_remarks:
                currentTime = Calendar.getInstance().getTime();

                txt_fifth_action_remarks.setVisibility(View.VISIBLE);
                txt_fifth_action_remarks.setText(df.format(currentTime));
                rl_other_fifth_action_remarks_time.setVisibility(View.GONE);
                break;
            case R.id.txt_now_final_action:
                currentTime = Calendar.getInstance().getTime();

                txt_final_action.setVisibility(View.VISIBLE);
                txt_final_action.setText(df.format(currentTime));
                rl_other_final_action_time.setVisibility(View.GONE);
                break;
            case R.id.txt_now_final_action_remarks:
                currentTime = Calendar.getInstance().getTime();

                txt_final_action_remarks.setVisibility(View.VISIBLE);
                txt_final_action_remarks.setText(df.format(currentTime));
                rl_other_final_action_remarks_time.setVisibility(View.GONE);
                break;
            case R.id.txt_later_first_action:
                date_time_Method("first_action");
                break;
            case R.id.txt_later_first_action_remarks:
                date_time_Method("first_action_remarks");
                break;
            case R.id.txt_later_second_action:
                date_time_Method("second_action");
                break;
            case R.id.txt_later_second_action_remarks:
                date_time_Method("second_action_remarks");
                break;
            case R.id.txt_later_third_action:
                date_time_Method("third_action");
                break;
            case R.id.txt_later_third_action_remarks:
                date_time_Method("third_action_remarks");
                break;
            case R.id.txt_later_fourth_action:
                date_time_Method("fourth_action");
                break;
            case R.id.txt_later_fourth_action_remarks:
                date_time_Method("fourth_action_remarks");
                break;
            case R.id.txt_later_fifth_action:
                date_time_Method("fifth_action");
                break;
            case R.id.txt_later_fifth_action_remarks:
                date_time_Method("fifth_action_remarks");
                break;
            case R.id.txt_later_final_action:
                date_time_Method("final_action");
                break;
            case R.id.txt_later_final_action_remarks:
                date_time_Method("final_action_remarks");
                break;
        }
    }

    public boolean validation() {

        return true;
    }

    public void date_time_Method(final String selected) {

        c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);


        datePickerDialog = new DatePickerDialog(getActivity(),
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, final int year,
                                          final int monthOfYear, final int dayOfMonth) {

                        final Calendar c = Calendar.getInstance();
                        mHour = c.get(Calendar.HOUR_OF_DAY);
                        mMinute = c.get(Calendar.MINUTE);

                        // Launch Time Picker Dialog
                        TimePickerDialog timePickerDialog = new TimePickerDialog(getActivity(),
                                new TimePickerDialog.OnTimeSetListener() {

                                    @Override
                                    public void onTimeSet(TimePicker view, int hourOfDay,
                                                          int minute) {
                                        if (selected.equalsIgnoreCase("first_action")) {
                                            txt_first_action.setVisibility(View.VISIBLE);
                                            txt_first_action.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year + " " + hourOfDay + ":" + minute + ":00");
                                            rl_other_first_action_time.setVisibility(View.GONE);
                                        } else if (selected.equalsIgnoreCase("first_action_remarks")) {
                                            txt_first_action_remarks.setVisibility(View.VISIBLE);
                                            txt_first_action_remarks.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year + " " + hourOfDay + ":" + minute + ":00");
                                            rl_other_first_action_remarks_time.setVisibility(View.GONE);
                                        } else if (selected.equalsIgnoreCase("second_action")) {
                                            txt_second_action.setVisibility(View.VISIBLE);
                                            txt_second_action.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year + " " + hourOfDay + ":" + minute + ":00");
                                            rl_other_second_action_time.setVisibility(View.GONE);
                                        } else if (selected.equalsIgnoreCase("second_action_remarks")) {
                                            txt_second_action_remarks.setVisibility(View.VISIBLE);
                                            txt_second_action_remarks.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year + " " + hourOfDay + ":" + minute + ":00");
                                            rl_other_second_action_remarks_time.setVisibility(View.GONE);
                                        } else if (selected.equalsIgnoreCase("third_action")) {
                                            txt_third_action.setVisibility(View.VISIBLE);
                                            txt_third_action.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year + " " + hourOfDay + ":" + minute + ":00");
                                            rl_other_third_action_time.setVisibility(View.GONE);
                                        } else if (selected.equalsIgnoreCase("third_action_remarks")) {
                                            txt_third_action_remarks.setVisibility(View.VISIBLE);
                                            txt_third_action_remarks.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year + " " + hourOfDay + ":" + minute + ":00");
                                            rl_other_third_action_remarks_time.setVisibility(View.GONE);
                                        } else if (selected.equalsIgnoreCase("fourth_action")) {
                                            txt_fourth_action.setVisibility(View.VISIBLE);
                                            txt_fourth_action.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year + " " + hourOfDay + ":" + minute + ":00");
                                            rl_other_fourth_action_time.setVisibility(View.GONE);
                                        } else if (selected.equalsIgnoreCase("fourth_action_remarks")) {
                                            txt_fourth_action_remarks.setVisibility(View.VISIBLE);
                                            txt_fourth_action_remarks.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year + " " + hourOfDay + ":" + minute + ":00");
                                            rl_other_fourth_action_remarks_time.setVisibility(View.GONE);
                                        } else if (selected.equalsIgnoreCase("fifth_action")) {
                                            txt_fifth_action.setVisibility(View.VISIBLE);
                                            txt_fifth_action.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year + " " + hourOfDay + ":" + minute + ":00");
                                            rl_other_fifth_action_time.setVisibility(View.GONE);
                                        } else if (selected.equalsIgnoreCase("fifth_action_remarks")) {
                                            txt_fifth_action_remarks.setVisibility(View.VISIBLE);
                                            txt_fifth_action_remarks.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year + " " + hourOfDay + ":" + minute + ":00");
                                            rl_other_fifth_action_remarks_time.setVisibility(View.GONE);
                                        } else if (selected.equalsIgnoreCase("final_action")) {
                                            txt_final_action.setVisibility(View.VISIBLE);
                                            txt_final_action.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year + " " + hourOfDay + ":" + minute + ":00");
                                            rl_other_final_action_time.setVisibility(View.GONE);
                                        } else if (selected.equalsIgnoreCase("final_action_remarks")) {
                                            txt_final_action_remarks.setVisibility(View.VISIBLE);
                                            txt_final_action_remarks.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year + " " + hourOfDay + ":" + minute + ":00");
                                            rl_other_final_action_remarks_time.setVisibility(View.GONE);
                                        }
                                    }
                                }, mHour, mMinute, false);
                        timePickerDialog.show();


                    }
                }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }

    public void data_save() {
        Helper.storeLocally(getActivity(), "First_Actions", edt_first_action.getText().toString());
        if (edt_first_action.getText().toString().equalsIgnoreCase("Call")) {
            Helper.storeLocally(getActivity(), "first_action_other", txt_first_action.getText().toString());
        } else {
            Helper.storeLocally(getActivity(), "first_action_other", edt_other_first_action.getText().toString());
        }
        Helper.storeLocally(getActivity(), "First_Action_Remarks", edt_first_action_remarks.getText().toString());
        if ((edt_first_action_remarks.getText().toString().equalsIgnoreCase("Call Back")) || (edt_first_action_remarks.getText().toString().equalsIgnoreCase("Call Back Again")) || (edt_first_action_remarks.getText().toString().equalsIgnoreCase("Meeting Fixed")) || (edt_first_action_remarks.getText().toString().equalsIgnoreCase("Meeting Done")) || (edt_first_action_remarks.getText().toString().equalsIgnoreCase("Proposal Sent"))) {
            Helper.storeLocally(getActivity(), "first_action_remarks_other", txt_first_action_remarks.getText().toString());
        } else {
            Helper.storeLocally(getActivity(), "first_action_remarks_other", edt_other_first_action_remarks.getText().toString());
        }
        Helper.storeLocally(getActivity(), "Second_Actions", edt_second_action.getText().toString());
        if (edt_second_action.getText().toString().equalsIgnoreCase("Call")) {
            Helper.storeLocally(getActivity(), "second_action_other", txt_second_action.getText().toString());
        } else {
            Helper.storeLocally(getActivity(), "second_action_other", edt_other_second_action.getText().toString());
        }
        Helper.storeLocally(getActivity(), "Second_Action_Remarks", edt_second_action_remarks.getText().toString());
        if ((edt_second_action_remarks.getText().toString().equalsIgnoreCase("Meeting Reschedule")) || (edt_second_action_remarks.getText().toString().equalsIgnoreCase("Call Back Again")) || (edt_second_action_remarks.getText().toString().equalsIgnoreCase("Meeting Fixed")) || (edt_second_action_remarks.getText().toString().equalsIgnoreCase("Meeting Done")) || (edt_second_action_remarks.getText().toString().equalsIgnoreCase("Proposal Sent")) || (edt_second_action_remarks.getText().toString().equalsIgnoreCase("Proposal Cancelled"))) {
            Helper.storeLocally(getActivity(), "second_action_remarks_other", txt_second_action_remarks.getText().toString());
        } else {
            Helper.storeLocally(getActivity(), "second_action_remarks_other", edt_other_second_action_remarks.getText().toString());
        }
        Helper.storeLocally(getActivity(), "Third_Actions", edt_third_action.getText().toString());
        if (edt_third_action.getText().toString().equalsIgnoreCase("Call")) {
            Helper.storeLocally(getActivity(), "third_action_other", txt_third_action.getText().toString());
        } else {
            Helper.storeLocally(getActivity(), "third_action_other", edt_other_third_action.getText().toString());
        }
        Helper.storeLocally(getActivity(), "Third_Action_Remarks", edt_third_action_remarks.getText().toString());
        if ((edt_third_action_remarks.getText().toString().equalsIgnoreCase("Metting Reschedule")) || (edt_third_action_remarks.getText().toString().equalsIgnoreCase("Call Back Again")) || (edt_third_action_remarks.getText().toString().equalsIgnoreCase("Meeting Fixed")) || (edt_third_action_remarks.getText().toString().equalsIgnoreCase("Meeting Done")) || (edt_third_action_remarks.getText().toString().equalsIgnoreCase("Proposal Sent")) || (edt_third_action_remarks.getText().toString().equalsIgnoreCase("Proposal Cancelled")) || (edt_third_action_remarks.getText().toString().equalsIgnoreCase("Follow Up"))) {
            Helper.storeLocally(getActivity(), "third_action_remarks_other", txt_third_action_remarks.getText().toString());
        } else {
            Helper.storeLocally(getActivity(), "third_action_remarks_other", edt_other_third_action_remarks.getText().toString());
        }
        Helper.storeLocally(getActivity(), "Fourth_Actions", edt_fourth_action.getText().toString());
        if (edt_fourth_action.getText().toString().equalsIgnoreCase("Call")) {
            Helper.storeLocally(getActivity(), "fourth_action_other", txt_fourth_action.getText().toString());
        } else {
            Helper.storeLocally(getActivity(), "fourth_action_other", edt_other_fourth_action.getText().toString());
        }
        Helper.storeLocally(getActivity(), "Fouth_Action_Remarks", edt_fourth_action_remarks.getText().toString());
        if ((edt_fourth_action_remarks.getText().toString().equalsIgnoreCase("Presentation")) || (edt_fourth_action_remarks.getText().toString().equalsIgnoreCase("Follow Up")) || (edt_fourth_action_remarks.getText().toString().equalsIgnoreCase("Proposal Cancelled")) || (edt_fourth_action_remarks.getText().toString().equalsIgnoreCase("Sale Closed"))) {
            Helper.storeLocally(getActivity(), "fourth_action_remarks_other", txt_fourth_action_remarks.getText().toString());
        } else {
            Helper.storeLocally(getActivity(), "fourth_action_remarks_other", edt_other_fourth_action_remarks.getText().toString());
        }
        Helper.storeLocally(getActivity(), "Fifth_Actions", edt_fifth_action.getText().toString());
        if (edt_fifth_action.getText().toString().equalsIgnoreCase("Call")) {
            Helper.storeLocally(getActivity(), "fifth_action_other", txt_fifth_action.getText().toString());
        } else {
            Helper.storeLocally(getActivity(), "fifth_action_other", edt_other_fifth_action.getText().toString());
        }

        Helper.storeLocally(getActivity(), "Fifth_Action_Remarks", edt_fifth_action_remarks.getText().toString());
        if ((edt_fifth_action_remarks.getText().toString().equalsIgnoreCase("Presentation")) || (edt_fifth_action_remarks.getText().toString().equalsIgnoreCase("Follow Up")) || (edt_fifth_action_remarks.getText().toString().equalsIgnoreCase("Proposal Cancelled")) || (edt_fifth_action_remarks.getText().toString().equalsIgnoreCase("Sale Closed"))) {
            Helper.storeLocally(getActivity(), "fifth_action_remarks_other", txt_fifth_action_remarks.getText().toString());
        } else {
            Helper.storeLocally(getActivity(), "fifth_action_remarks_other", edt_other_fifth_action_remarks.getText().toString());
        }
        Helper.storeLocally(getActivity(), "Final_Actions", edt_final_action.getText().toString());
        if (edt_final_action.getText().toString().equalsIgnoreCase("Call")) {
            Helper.storeLocally(getActivity(), "final_action_other", txt_final_action.getText().toString());
        } else {
            Helper.storeLocally(getActivity(), "final_action_other", edt_other_final_action.getText().toString());
        }
        Helper.storeLocally(getActivity(), "Final_Action_Remarks", edt_final_action_remarks.getText().toString());
        if ((edt_final_action_remarks.getText().toString().equalsIgnoreCase("Presentation")) || (edt_final_action_remarks.getText().toString().equalsIgnoreCase("Follow Up")) || (edt_final_action_remarks.getText().toString().equalsIgnoreCase("Proposal Cancelled")) || (edt_final_action_remarks.getText().toString().equalsIgnoreCase("Sale Closed"))) {
            Helper.storeLocally(getActivity(), "final_action_remarks_other", txt_final_action_remarks.getText().toString());
        } else {
            Helper.storeLocally(getActivity(), "final_action_remarks_other", edt_other_final_action_remarks.getText().toString());
        }

        if (clickable == 1) {
            Fragment fragment = new LeadCRMForm1();
            Bundle bundle = new Bundle();
            if (LeadCRMForm1.from.equalsIgnoreCase("from_update")) {
                bundle.putString("from", "from_update");
            } else {
                bundle.putString("from", "from_add");
            }
            fragment.setArguments(bundle);
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page1");
            ft.commit();
        } else if (clickable == 2) {
            Fragment fragment = new LeadCRMForm2();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page2");
            ft.commit();
        } else if (clickable == 3) {
            Fragment fragment = new LeadCRMForm3();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page3");
            ft.commit();
        } else if (clickable == 4) {
            Fragment fragment = new LeadCRMForm4();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page4");
            ft.commit();
        } else if (clickable == 5) {
        } else if (clickable == 6) {
            Fragment fragment = new LeadCRMForm6();
            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame, fragment);
            ft.addToBackStack("page6");
            ft.commit();
        }
    }

    public void executeMethode() {
        edt_first_action.setText(Helper.getLocalValue(getActivity(), "First_Actions"));
        if (Helper.getLocalValue(getActivity(), "First_Actions").equalsIgnoreCase("Others")) {
            edt_other_first_action.setVisibility(View.VISIBLE);
            edt_other_first_action.setText(Helper.getLocalValue(getActivity(), "first_action_other"));
        } else if (Helper.getLocalValue(getActivity(), "First_Actions").equalsIgnoreCase("Call")) {
            txt_first_action.setVisibility(View.VISIBLE);
            txt_first_action.setText(Helper.getLocalValue(getActivity(), "first_action_other"));
        }

        edt_first_action_remarks.setText(Helper.getLocalValue(getActivity(), "First_Action_Remarks"));
        if (Helper.getLocalValue(getActivity(), "First_Action_Remarks").equalsIgnoreCase("Others")) {
            edt_other_first_action_remarks.setVisibility(View.VISIBLE);
            edt_other_first_action_remarks.setText(Helper.getLocalValue(getActivity(), "first_action_remarks_other"));
        } else if ((Helper.getLocalValue(getActivity(), "First_Action_Remarks").equalsIgnoreCase("Call Back")) || (Helper.getLocalValue(getActivity(), "First_Action_Remarks").equalsIgnoreCase("Call Back Again")) || (Helper.getLocalValue(getActivity(), "First_Action_Remarks").equalsIgnoreCase("Meeting Fixed")) || (Helper.getLocalValue(getActivity(), "First_Action_Remarks").equalsIgnoreCase("Meeting Done")) || (Helper.getLocalValue(getActivity(), "First_Action_Remarks").equalsIgnoreCase("Proposal Sent"))) {
            txt_first_action_remarks.setVisibility(View.VISIBLE);
            txt_first_action_remarks.setText(Helper.getLocalValue(getActivity(), "first_action_remarks_other"));
        }

        edt_second_action.setText(Helper.getLocalValue(getActivity(), "Second_Actions"));
        if (Helper.getLocalValue(getActivity(), "Second_Actions").equalsIgnoreCase("Others")) {
            edt_other_second_action.setVisibility(View.VISIBLE);
            edt_other_second_action.setText(Helper.getLocalValue(getActivity(), "second_action_other"));
        } else if (Helper.getLocalValue(getActivity(), "Second_Actions").equalsIgnoreCase("Call")) {
            txt_second_action.setVisibility(View.VISIBLE);
            txt_second_action.setText(Helper.getLocalValue(getActivity(), "second_action_other"));
        }

        edt_second_action_remarks.setText(Helper.getLocalValue(getActivity(), "Second_Action_Remarks"));
        if (Helper.getLocalValue(getActivity(), "Second_Action_Remarks").equalsIgnoreCase("Others")) {
            edt_other_second_action_remarks.setVisibility(View.VISIBLE);
            edt_other_second_action_remarks.setText(Helper.getLocalValue(getActivity(), "second_action_remarks_other"));
        } else if ((Helper.getLocalValue(getActivity(), "Second_Action_Remarks").equalsIgnoreCase("Meeting Reschedule")) || (Helper.getLocalValue(getActivity(), "Second_Action_Remarks").equalsIgnoreCase("Call Back Again")) || (Helper.getLocalValue(getActivity(), "Second_Action_Remarks").equalsIgnoreCase("Meeting Fixed")) || (Helper.getLocalValue(getActivity(), "Second_Action_Remarks").equalsIgnoreCase("Meeting Done")) || (Helper.getLocalValue(getActivity(), "Second_Action_Remarks").equalsIgnoreCase("Proposal Sent")) || (Helper.getLocalValue(getActivity(), "Second_Action_Remarks").equalsIgnoreCase("Proposal Cancelled"))) {
            txt_second_action_remarks.setVisibility(View.VISIBLE);
            txt_second_action_remarks.setText(Helper.getLocalValue(getActivity(), "second_action_remarks_other"));
        }

        edt_third_action.setText(Helper.getLocalValue(getActivity(), "Third_Actions"));
        if (Helper.getLocalValue(getActivity(), "Third_Actions").equalsIgnoreCase("Others")) {
            edt_other_third_action.setVisibility(View.VISIBLE);
            edt_other_third_action.setText(Helper.getLocalValue(getActivity(), "third_action_other"));
        } else if (Helper.getLocalValue(getActivity(), "Third_Actions").equalsIgnoreCase("Call")) {
            txt_third_action.setVisibility(View.VISIBLE);
            txt_third_action.setText(Helper.getLocalValue(getActivity(), "third_action_other"));
        }

        edt_third_action_remarks.setText(Helper.getLocalValue(getActivity(), "Third_Action_Remarks"));
        if (Helper.getLocalValue(getActivity(), "Third_Action_Remarks").equalsIgnoreCase("Others")) {
            edt_other_third_action_remarks.setVisibility(View.VISIBLE);
            edt_other_third_action_remarks.setText(Helper.getLocalValue(getActivity(), "third_action_remarks_other"));
        } else if ((Helper.getLocalValue(getActivity(), "Third_Action_Remarks").equalsIgnoreCase("Metting Reschedule")) || (Helper.getLocalValue(getActivity(), "Third_Action_Remarks").equalsIgnoreCase("Call Back Again")) || (Helper.getLocalValue(getActivity(), "Third_Action_Remarks").equalsIgnoreCase("Meeting Fixed")) || (Helper.getLocalValue(getActivity(), "Third_Action_Remarks").equalsIgnoreCase("Meeting Done")) || (Helper.getLocalValue(getActivity(), "Third_Action_Remarks").equalsIgnoreCase("Proposal Sent")) || (Helper.getLocalValue(getActivity(), "Third_Action_Remarks").equalsIgnoreCase("Proposal Cancelled")) || (Helper.getLocalValue(getActivity(), "Third_Action_Remarks").equalsIgnoreCase("Follow Up"))) {
            txt_third_action_remarks.setVisibility(View.VISIBLE);
            txt_third_action_remarks.setText(Helper.getLocalValue(getActivity(), "third_action_remarks_other"));
        }

        edt_fourth_action.setText(Helper.getLocalValue(getActivity(), "Fourth_Actions"));
        if (Helper.getLocalValue(getActivity(), "Fourth_Actions").equalsIgnoreCase("Others")) {
            edt_other_fourth_action.setVisibility(View.VISIBLE);
            edt_other_fourth_action.setText(Helper.getLocalValue(getActivity(), "fourth_action_other"));
        } else if (Helper.getLocalValue(getActivity(), "Fourth_Actions").equalsIgnoreCase("Call")) {
            txt_fourth_action.setVisibility(View.VISIBLE);
            txt_fourth_action.setText(Helper.getLocalValue(getActivity(), "fourth_action_other"));
        }

        edt_fourth_action_remarks.setText(Helper.getLocalValue(getActivity(), "Fouth_Action_Remarks"));
        if (Helper.getLocalValue(getActivity(), "Fouth_Action_Remarks").equalsIgnoreCase("Others")) {
            edt_other_fourth_action_remarks.setVisibility(View.VISIBLE);
            edt_other_fourth_action_remarks.setText(Helper.getLocalValue(getActivity(), "fourth_action_remarks_other"));
        } else if ((Helper.getLocalValue(getActivity(), "Fouth_Action_Remarks").equalsIgnoreCase("Presentation")) || (Helper.getLocalValue(getActivity(), "Fouth_Action_Remarks").equalsIgnoreCase("Follow Up")) || (Helper.getLocalValue(getActivity(), "Fouth_Action_Remarks").equalsIgnoreCase("Proposal Cancelled")) || (Helper.getLocalValue(getActivity(), "Fouth_Action_Remarks").equalsIgnoreCase("Sale Closed"))) {
            txt_fourth_action_remarks.setVisibility(View.VISIBLE);
            txt_fourth_action_remarks.setText(Helper.getLocalValue(getActivity(), "fourth_action_remarks_other"));
        }

        edt_fifth_action.setText(Helper.getLocalValue(getActivity(), "Fifth_Actions"));
        if (Helper.getLocalValue(getActivity(), "Fifth_Actions").equalsIgnoreCase("Others")) {
            edt_other_fifth_action.setVisibility(View.VISIBLE);
            edt_other_fifth_action.setText(Helper.getLocalValue(getActivity(), "fifth_action_other"));
        } else if (Helper.getLocalValue(getActivity(), "Fifth_Actions").equalsIgnoreCase("Call")) {
            txt_fifth_action.setVisibility(View.VISIBLE);
            txt_fifth_action.setText(Helper.getLocalValue(getActivity(), "fifth_action_other"));
        }

        edt_fifth_action_remarks.setText(Helper.getLocalValue(getActivity(), "Fifth_Action_Remarks"));
        if (Helper.getLocalValue(getActivity(), "Fifth_Action_Remarks").equalsIgnoreCase("Others")) {
            edt_other_fifth_action_remarks.setVisibility(View.VISIBLE);
            edt_other_fifth_action_remarks.setText(Helper.getLocalValue(getActivity(), "fifth_action_remarks_other"));
        } else if ((Helper.getLocalValue(getActivity(), "Fifth_Action_Remarks").equalsIgnoreCase("Presentation")) || (Helper.getLocalValue(getActivity(), "Fifth_Action_Remarks").equalsIgnoreCase("Follow Up")) || (Helper.getLocalValue(getActivity(), "Fifth_Action_Remarks").equalsIgnoreCase("Proposal Cancelled")) || (Helper.getLocalValue(getActivity(), "Fifth_Action_Remarks").equalsIgnoreCase("Sale Closed"))) {
            txt_fifth_action_remarks.setVisibility(View.VISIBLE);
            txt_fifth_action_remarks.setText(Helper.getLocalValue(getActivity(), "fifth_action_remarks_other"));
        }

        edt_final_action.setText(Helper.getLocalValue(getActivity(), "Final_Actions"));
        if (Helper.getLocalValue(getActivity(), "Final_Actions").equalsIgnoreCase("Others")) {
            edt_other_final_action.setVisibility(View.VISIBLE);
            edt_other_final_action.setText(Helper.getLocalValue(getActivity(), "final_action_other"));
        } else if (Helper.getLocalValue(getActivity(), "Final_Actions").equalsIgnoreCase("Call")) {
            txt_final_action.setVisibility(View.VISIBLE);
            txt_final_action.setText(Helper.getLocalValue(getActivity(), "final_action_other"));
        }

        edt_final_action_remarks.setText(Helper.getLocalValue(getActivity(), "Final_Action_Remarks"));
        if (Helper.getLocalValue(getActivity(), "Final_Action_Remarks").equalsIgnoreCase("Others")) {
            edt_other_final_action_remarks.setVisibility(View.VISIBLE);
            edt_other_final_action_remarks.setText(Helper.getLocalValue(getActivity(), "final_action_remarks_other"));
        } else if ((Helper.getLocalValue(getActivity(), "Final_Action_Remarks").equalsIgnoreCase("Presentation")) || (Helper.getLocalValue(getActivity(), "Final_Action_Remarks").equalsIgnoreCase("Follow Up")) || (Helper.getLocalValue(getActivity(), "Final_Action_Remarks").equalsIgnoreCase("Proposal Cancelled")) || (Helper.getLocalValue(getActivity(), "Final_Action_Remarks").equalsIgnoreCase("Sale Closed"))) {
            txt_final_action_remarks.setVisibility(View.VISIBLE);
            txt_final_action_remarks.setText(Helper.getLocalValue(getActivity(), "final_action_remarks_other"));
        }


        if (Helper.getLocalValue(getActivity(), "First_Actions").equalsIgnoreCase("")) {
            first_action_txt_input_layout.setVisibility(View.VISIBLE);
        } else {
            first_action_txt_input_layout.setVisibility(View.VISIBLE);
            first_action_remarks_txt_input_layout.setVisibility(View.VISIBLE);
            if (!Helper.getLocalValue(getActivity(), "First_Action_Remarks").equalsIgnoreCase("")) {
                second_action_txt_input_layout.setVisibility(View.VISIBLE);
                if (!Helper.getLocalValue(getActivity(), "Second_Actions").equalsIgnoreCase("")) {
                    second_action_remarks_txt_input_layout.setVisibility(View.VISIBLE);
                    if (!Helper.getLocalValue(getActivity(), "Second_Action_Remarks").equalsIgnoreCase("")) {
                        third_action_txt_input_layout.setVisibility(View.VISIBLE);
                        if (!Helper.getLocalValue(getActivity(), "Third_Actions").equalsIgnoreCase("")) {
                            third_action_remarks_txt_input_layout.setVisibility(View.VISIBLE);
                            if (!Helper.getLocalValue(getActivity(), "Third_Action_Remarks").equalsIgnoreCase("")) {
                                fourth_action_txt_input_layout.setVisibility(View.VISIBLE);
                                if (!Helper.getLocalValue(getActivity(), "Fourth_Actions").equalsIgnoreCase("")) {
                                    fourth_action_remarks_txt_input_layout.setVisibility(View.VISIBLE);
                                    if (!Helper.getLocalValue(getActivity(), "Fouth_Action_Remarks").equalsIgnoreCase("")) {
                                        fifth_action_txt_input_layout.setVisibility(View.VISIBLE);
                                        if (!Helper.getLocalValue(getActivity(), "Fifth_Actions").equalsIgnoreCase("")) {
                                            fifth_action_remarks_txt_input_layout.setVisibility(View.VISIBLE);
                                            if (!Helper.getLocalValue(getActivity(), "Fifth_Action_Remarks").equalsIgnoreCase("")) {
                                                final_action_txt_input_layout.setVisibility(View.VISIBLE);
                                                if (!Helper.getLocalValue(getActivity(), "Final_Actions").equalsIgnoreCase("")) {
                                                    final_action_remarks_txt_input_layout.setVisibility(View.VISIBLE);
                                                    if (!Helper.getLocalValue(getActivity(), "Final_Action_Remarks").equalsIgnoreCase("")) {
                                                        txt_next.setVisibility(View.VISIBLE);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

        }
    }

}
