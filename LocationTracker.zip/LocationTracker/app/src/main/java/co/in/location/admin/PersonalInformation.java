package co.in.location.admin;

import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import co.in.location.GifImageView;
import co.in.location.R;
import co.in.location.Remote.ApiUtils;
import de.hdodenhof.circleimageview.CircleImageView;

public class PersonalInformation extends Fragment {
    View view;
    TextView txt_name, txt_phone, txt_email, txt_add, txt_degignation, txt_department;
    CircleImageView profile_image;
    String Designation, Department, Designation_id, Department_id, user_id, name, email, personal_number, address, image_path;
    AppCompatDialog progressDialog;
    TextView prog_message;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.personal_information, container, false);
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        txt_name = (TextView) view.findViewById(R.id.txt_name);
        txt_email = (TextView) view.findViewById(R.id.txt_email);
        txt_phone = (TextView) view.findViewById(R.id.txt_phone);
        txt_add = (TextView) view.findViewById(R.id.txt_add);
        txt_degignation = (TextView) view.findViewById(R.id.txt_degignation);
        profile_image = (CircleImageView) view.findViewById(R.id.profile_image);
        txt_department = (TextView) view.findViewById(R.id.txt_department);
        progressDialog = new AppCompatDialog(getActivity());
        progressDialog.setCancelable(false);
        progressDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progressDialog.setContentView(R.layout.progress_loading);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        prog_message = progressDialog.findViewById(R.id.tv_progress_message);
        prog_message.setText("Please wait..");
        GifImageView gifImageView = (GifImageView) progressDialog.findViewById(R.id.GifImageView);
        gifImageView.setGifImageResource(R.drawable.loadinggif);
        getUserDetails();


        return view;
    }

    private void getUserDetails() {
        user_id = UserDetailsFragment.user_id;
        name = UserDetailsFragment.name;
        email = UserDetailsFragment.email;
        personal_number = UserDetailsFragment.personal_number;
        address = UserDetailsFragment.address;
        Designation = UserDetailsFragment.Designation;
        Department = UserDetailsFragment.Department;
        Designation_id = UserDetailsFragment.Designation_id;
        Department_id = UserDetailsFragment.Department_id;
        image_path = UserDetailsFragment.image_path;

        txt_name.setText(name);
        txt_email.setText(email);
        txt_phone.setText(personal_number);
        txt_add.setText(address);
        txt_degignation.setText(Designation);
        txt_department.setText(Department);
        if (!UserDetailsFragment.image_path.isEmpty()) {
            Picasso.with(getActivity()).load(ApiUtils.BASE_URL + UserDetailsFragment.image_path).networkPolicy(NetworkPolicy.NO_CACHE).into(profile_image);
        } else {
            Picasso.with(getActivity()).load(R.mipmap.profilepic).into(profile_image);
        }
    }
}
