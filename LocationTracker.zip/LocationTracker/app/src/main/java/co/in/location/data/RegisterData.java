package co.in.location.data;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class RegisterData {

    @SerializedName("id")
    @Expose
    public String userId;
    @SerializedName("admin_id")
    @Expose
    public String admin_id;
    @SerializedName("name")
    @Expose
    public String name;
    @SerializedName("company_names")
    @Expose
    public String company_names;
    @SerializedName("email")
    @Expose
    public String email;
    @SerializedName("phone")
    @Expose
    public String phone;
    @SerializedName("address")
    @Expose
    public String address;
    @SerializedName("designation")
    @Expose
    public String designation;
    @SerializedName("profile_image")
    @Expose
    public String profile_image;
}
