package co.in.location.slider;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import co.in.location.R;

/**
 * Created by ADMIN on 12-Oct-16.
 */
public class Tab_AllFestival extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab_all_festival, container, false);
        final WebView webview = (WebView) view.findViewById(R.id.browser);
        webview.getSettings().setLoadsImagesAutomatically(true);
        webview.getSettings().setJavaScriptEnabled(true);
        webview.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        webview.loadUrl("http://192.168.1.109:8080/AttendanceApp/allfest.html");


        return view;
    }
}
