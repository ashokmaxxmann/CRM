package co.in.location.Remote;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

import co.in.location.data.ListData;

public class UserRoleResponce {
    @SerializedName("status")
    @Expose
    public int statusCode;
    @SerializedName("message")
    @Expose
    public String message;
    @SerializedName("data")
    @Expose
    public List<ListData> listData = new ArrayList<>();
}
